/**
 * YEM360 — one-off cleanup: remove curl-test users created during CSRF fix verification.
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  for (const u of ["testuser1", "testuser2"]) {
    const found = await db.user.findUnique({ where: { username: u } });
    if (found) {
      await db.user.delete({ where: { id: found.id } });
      console.log("deleted:", u);
    } else {
      console.log("not found:", u);
    }
  }
}
main().finally(() => db.$disconnect());
