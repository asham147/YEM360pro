#!/usr/bin/env bash
# YEM360 — database + media backup (سجل الاحتفاظ: آخر 14 نسخة)
# Usage: ./backup-db.sh [BACKUP_DIR]
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BACKUP_DIR="${1:-$PROJECT_DIR/backups}"
mkdir -p "$BACKUP_DIR"
STAMP=$(date +%Y-%m-%d_%H%M)

DB_URL=$(grep -E '^DATABASE_URL=' "$PROJECT_DIR/.env" | cut -d= -f2-)
DB_PATH="${DB_URL#file:}"
[ -f "$DB_PATH" ] || { echo "DB not found: $DB_PATH"; exit 1; }

# atomic snapshot via sqlite3 if available, else direct copy
if command -v sqlite3 >/dev/null 2>&1; then
  sqlite3 "$DB_PATH" ".backup '$BACKUP_DIR/yem360-db-$STAMP.db'"
else
  cp "$DB_PATH" "$BACKUP_DIR/yem360-db-$STAMP.db"
fi

if [ -d "$PROJECT_DIR/uploads" ]; then
  tar -czf "$BACKUP_DIR/yem360-media-$STAMP.tar.gz" -C "$PROJECT_DIR" uploads
fi

# retention: keep last 14
ls -1t "$BACKUP_DIR"/yem360-db-*.db 2>/dev/null | tail -n +15 | xargs -r rm --
ls -1t "$BACKUP_DIR"/yem360-media-*.tar.gz 2>/dev/null | tail -n +15 | xargs -r rm --
echo "✅ backup: $BACKUP_DIR/yem360-db-$STAMP.db (+media)"
