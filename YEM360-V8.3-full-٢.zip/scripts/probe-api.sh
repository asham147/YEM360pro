#!/bin/bash
# YEM360 functional probe — login once, then exercise comments / notifications / reels APIs.
B=http://localhost:3000
J=/tmp/yem-cookies.txt
rm -f $J
echo "── login"
curl -s -c $J -X POST $B/api/auth/login -H 'Content-Type: application/json' \
  -d '{"identifier":"sara","password":"Demo12345"}' | head -c 300; echo

echo "── posts list (first ids)"
POSTS=$(curl -s -b $J "$B/api/posts")
echo "$POSTS" | python3 -c "import sys,json;d=json.load(sys.stdin);print('count:',len(d['posts']));print('\n'.join(p['id']+' | '+(p['content'][:40] or '(no text)')) for p in d['posts'][:5])" 2>&1 | head -8
PID=$(echo "$POSTS" | python3 -c "import sys,json;d=json.load(sys.stdin);print(d['posts'][0]['id'] if d['posts'] else '')")
echo "PID=$PID"

echo "── GET comments on first post"
curl -s -b $J "$B/api/posts/$PID/comments" | head -c 400; echo

echo "── POST comment"
curl -s -b $J -X POST "$B/api/posts/$PID/comments" -H 'Content-Type: application/json' \
  -d '{"text":"اختبار آلي للتعليقات ✅","target":"post"}' | head -c 300; echo

echo "── GET comments after POST"
curl -s -b $J "$B/api/posts/$PID/comments" | python3 -c "import sys,json;d=json.load(sys.stdin);print('comments:',len(d['comments']))" 2>&1

echo "── GET notifications"
curl -s -b $J "$B/api/notifications" | head -c 500; echo

echo "── POST notifications/read"
curl -s -b $J -X POST "$B/api/notifications/read" -H 'Content-Type: application/json' -d '{}' | head -c 200; echo

echo "── GET reels"
curl -s -b $J "$B/api/reels" | python3 -c "
import sys,json
d=json.load(sys.stdin)
rs=d.get('reels',d if isinstance(d,list) else [])
print('reels:',len(rs))
for r in rs[:3]: print(r['id'],'|',(r.get('caption') or r.get('content') or '')[:40],'| video:',(r.get('videoUrl') or r.get('mediaUrl') or '')[:60])
" 2>&1

echo "── session/me"
curl -s -b $J "$B/api/auth/me" | head -c 300; echo
