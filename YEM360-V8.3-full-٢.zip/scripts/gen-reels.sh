#!/bin/bash
# YEM360 — generate 4 vertical demo reels (9s, 720x1280, H.264) into public/reels/.
# Fully local/offline: animated gradients + vignette + latin watermark.
set -e
mkdir -p /home/z/my-project/public/reels
cd /home/z/my-project/public/reels

FONT="/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
ENC="-c:v libx264 -profile:v main -preset veryfast -crf 26 -pix_fmt yuv420p -movflags +faststart -an"

render () { # $1 out  $2 palette  $3 speed
  ffmpeg -hide_banner -loglevel error -y \
    -f lavfi -i "gradients=size=720x1280:speed=${3}:nb_colors=4:${2}:duration=9:rate=24" \
    -vf "vignette=PI/4.2,drawtext=fontfile=${FONT}:text='YEM360':x=(w-text_w)/2:y=h-170:fontsize=64:fontcolor=white@0.85:shadowx=2:shadowy=2:shadowcolor=black@0.5,drawtext=fontfile=${FONT}:text='YOUR DIGITAL WORLD':x=(w-text_w)/2:y=h-96:fontsize=24:fontcolor=#F5B900@0.9,fade=t=in:st=0:d=0.6,fade=t=out:st=8.4:d=0.6" \
    -t 9 $ENC "$1"
  echo "✓ $1"
}

render r1.mp4 "c0=0x030A1B:c1=0xC9A227:c2=0x1265FF:c3=0x0B1735" 0.05
render r2.mp4 "c0=0x030A1B:c1=0x1265FF:c2=0x00BFFF:c3=0x050D23" 0.07
render r3.mp4 "c0=0xE9CE7A:c1=0xC9A227:c2=0x8A6D1F:c3=0x142B55" 0.04
render r4.mp4 "c0=0xEAF2FC:c1=0x65B8FF:c2=0x1765D8:c3=0xF3F7FD" 0.06

for f in r*.mp4; do
  ffprobe -v error -show_entries format=duration,size -of default=noprint_wrappers=1 "$f" | tr '\n' ' '; echo "($f)"
done
