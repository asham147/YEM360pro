/**
 * YEM360 — one-off cleanup: remove the v8demo browser-verification user
 * and its test post. All owned rows cascade from User (onDelete: Cascade).
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const u = await db.user.findUnique({ where: { username: "v8demo" } });
  if (!u) { console.log("no demo user"); return; }
  await db.notification.deleteMany({ where: { actorId: u.id } });
  await db.user.delete({ where: { id: u.id } });
  console.log("deleted demo user:", u.username);
}
main().finally(() => db.$disconnect());
