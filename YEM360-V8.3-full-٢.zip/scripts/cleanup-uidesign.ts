/**
 * YEM360 — one-off cleanup: remove the UI-preview test user.
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const u = await db.user.findUnique({ where: { username: "uidesign" } });
  if (u) { await db.user.delete({ where: { id: u.id } }); console.log("deleted: uidesign"); }
  else console.log("uidesign not found");
}
main().finally(() => db.$disconnect());
