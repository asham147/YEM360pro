"""Fix admin route guards: replace authGuard+roleGuard pair with requireRole."""
import re
import pathlib

FILES = [
    "src/app/api/admin/ads/route.ts",
    "src/app/api/admin/backup/route.ts",
    "src/app/api/admin/banned-words/route.ts",
    "src/app/api/admin/reports/route.ts",
    "src/app/api/admin/stats/route.ts",
    "src/app/api/admin/users/route.ts",
]

PAT = re.compile(
    r"const g = await authGuard\(\);\n"
    r"  const denied = roleGuard\(g\.ctx, g\.resp, (\[[^\]]+\])\);\n"
    r"  if \(denied\) return denied;"
)

ROOT = pathlib.Path("/home/z/my-project")
for rel in FILES:
    p = ROOT / rel
    src = p.read_text()
    src, n = PAT.subn(
        'const g = await requireRole(\\1);\n  if (g.resp) return g.resp;',
        src,
    )
    # fix import line
    if "requireRole" in src:
        src = re.sub(
            r'import \{ authGuard, roleGuard \} from "@/lib/auth";',
            'import { requireRole } from "@/lib/auth";',
            src,
        )
    p.write_text(src)
    print(f"{rel}: {n} guard(s) replaced")
