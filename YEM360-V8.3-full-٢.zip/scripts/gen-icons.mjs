/** Generate PWA PNG icons from public/logo.svg using sharp. */
import sharp from "sharp";
import fs from "fs";
import path from "path";

const ROOT = "/home/z/my-project";
const svgPath = path.join(ROOT, "public/logo.svg");
const outDir = path.join(ROOT, "public/icons");
fs.mkdirSync(outDir, { recursive: true });

const svg = fs.readFileSync(svgPath, "utf8");
// Crisp large render source (vector): replace width/height, keep viewBox
const bigSvg = svg.replace(/width="48" height="48"/, 'width="512" height="512"');

async function iconPng(size, name, { padding = 0, bg = null } = {}) {
  // content size after padding, then paste centered onto canvas
  const inner = size - padding * 2;
  const content = await sharp(Buffer.from(bigSvg))
    .resize(inner, inner)
    .png()
    .toBuffer();
  let img = sharp({
    create: {
      width: size,
      height: size,
      channels: 4,
      background: bg ?? { r: 0, g: 0, b: 0, alpha: 0 },
    },
  });
  img = img.composite([{ input: content, left: padding, top: padding }]);
  await img.png().toFile(path.join(outDir, name));
  console.log("wrote", name, size + "x" + size);
}

await iconPng(192, "icon-192.png");
await iconPng(512, "icon-512.png");
// maskable: 80% safe zone on solid brand navy
await iconPng(512, "maskable-512.png", { padding: 56, bg: { r: 27, g: 42, b: 82, alpha: 1 } });
// apple touch icon (iOS home screen, opaque bg)
await iconPng(180, "apple-touch-icon.png", { padding: 20, bg: { r: 27, g: 42, b: 82, alpha: 1 } });
console.log("done");
