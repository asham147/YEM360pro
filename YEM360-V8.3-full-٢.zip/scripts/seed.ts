/**
 * YEM360 — Seed script (بيانات تجريبية مُعلَّمة).
 * Creates:
 *  - admin account (from SEED_ADMIN_PASSWORD, role=ADMIN, verified)
 *  - demo accounts (sara/omar/lina/yousef/noor) with password Demo12345
 *  - generated media (sharp) so the platform doesn't start empty
 *  - follow graph, posts, comments, likes, stories, product+order, ad, channel
 * Everything created here is DEMO data clearly labeled, as required.
 *
 * Run: bun scripts/seed.ts   (idempotent — skips existing accounts)
 */
import { PrismaClient } from "@prisma/client";
import sharp from "sharp";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import bcrypt from "bcryptjs";

const db = new PrismaClient();
const UPLOAD_DIR = path.join(process.cwd(), "uploads");

function hashPasswordSync(pw: string): string {
  return bcrypt.hashSync(pw, 11);
}

async function saveImage(svg: string, subdir: string): Promise<string> {
  const dir = path.join(UPLOAD_DIR, subdir);
  fs.mkdirSync(dir, { recursive: true });
  const name = `seed_${crypto.randomBytes(6).toString("hex")}_${Date.now()}.webp`;
  const buf = await sharp(Buffer.from(svg)).webp({ quality: 82 }).toBuffer();
  fs.writeFileSync(path.join(dir, name), buf);
  return `/api/media/${subdir}/${name}`;
}

function gradientSVG(w: number, h: number, c1: string, c2: string, label: string, sub = ""): string {
  return `<svg width="${w}" height="${h}" xmlns="http://www.w3.org/2000/svg">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0%" stop-color="${c1}"/><stop offset="100%" stop-color="${c2}"/>
  </linearGradient></defs>
  <rect width="${w}" height="${h}" fill="url(#g)"/>
  <circle cx="${w * 0.82}" cy="${h * 0.18}" r="${Math.min(w, h) * 0.22}" fill="rgba(255,255,255,0.15)"/>
  <circle cx="${w * 0.15}" cy="${h * 0.85}" r="${Math.min(w, h) * 0.28}" fill="rgba(0,0,0,0.12)"/>
  <text x="${w / 2}" y="${h / 2 - 10}" text-anchor="middle" font-family="sans-serif" font-size="${Math.max(22, w / 14)}" font-weight="700" fill="#fff">${label}</text>
  ${sub ? `<text x="${w / 2}" y="${h / 2 + 34}" text-anchor="middle" font-family="sans-serif" font-size="${Math.max(13, w / 30)}" fill="rgba(255,255,255,0.85)">YEM360 · ${sub}</text>` : ""}
</svg>`;
}

function avatarSVG(letter: string, c1: string, c2: string): string {
  return `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
  <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0%" stop-color="${c1}"/><stop offset="100%" stop-color="${c2}"/>
  </linearGradient></defs>
  <rect width="512" height="512" fill="url(#g)"/>
  <text x="256" y="330" text-anchor="middle" font-family="sans-serif" font-size="220" font-weight="700" fill="#fff">${letter}</text>
</svg>`;
}

const DEMO_PASSWORD = process.env.SEED_DEMO_PASSWORD || "Demo12345";
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD || "Yem360-admin1";

interface SeedUser {
  username: string; name: string; bio: string; colors: [string, string];
  role?: string; accountType?: string; category?: string; verified?: boolean;
}

const USERS: SeedUser[] = [
  { username: "admin", name: "إدارة YEM360", bio: "الحساب الرسمي لمنصة YEM360 — عالمك الرقمي في منصة واحدة.", colors: ["#0F766E", "#14B8A6"], role: "ADMIN", verified: true, accountType: "BUSINESS", category: "منصة رسمية" },
  { username: "sara", name: "سارة العمري", bio: "مصممة واجهات ومهتمة بالتقنية والرحلات. اليمن والحياة الرقمية 🌿", colors: ["#B45309", "#F59E0B"], accountType: "CREATOR", category: "تصميم واجهات", verified: true },
  { username: "omar", name: "عمر الحكيمي", bio: "مطوّر ويب — أكتب عن البرمجة وأدوات العمل. صناعة محتوى عربي.", colors: ["#115E59", "#0D9488"], accountType: "PROFESSIONAL", category: "تطوير برمجيات" },
  { username: "lina", name: "لينا الشامي", bio: "رائدة أعمال صغيرة — أبيع منتجات حرفية يدوية من عدن.", colors: ["#7C2D12", "#EA580C"], accountType: "BUSINESS", category: "تجارة إلكترونية" },
  { username: "yousef", name: "يوسف الشباني", bio: "مصور فوتوغرافي — أرصد جمال اليمن من صنعاء إلى سقطرى 📷", colors: ["#3F6212", "#65A30D"] },
  { username: "noor", name: "نور عبدالله", bio: "طالبة هندسة حاسوب — أحب الذكاء الاصطناعي والقراءة.", colors: ["#4C1D95", "#8B5CF6"] },
];

const POSTS: { author: string; text: string; label?: string; colors?: [string, string]; location?: string }[] = [
  { author: "sara", text: "أهلاً بكم في YEM360! أول منصة عربية تجمع كل شيء: منشورات، ريلز، رسائل، سوق… جرّبوا بنفسكم #YEM360 #ترحيب", label: "مرحباً بكم في YEM360", colors: ["#0F766E", "#14B8A6"] },
  { author: "omar", text: "نصيحة اليوم: كلمة المرور القوية + التحقق الثنائي = حساب آمن. فعّلوا 2FA من إعدادات الأمان في المنصة 🔐 #أمن_معلومات #نصائح", label: "فعّل التحقق الثنائي", colors: ["#1E3A5F", "#3B82F6"] },
  { author: "yousef", text: "شروق صعدة هذا الصباح — سحر اليمن لا ينتهي 🌄 #تصوير #اليمن", label: "شروق صعدة", colors: ["#92400E", "#F59E0B"], location: "صعدة، اليمن" },
  { author: "lina", text: "وصلتنا شحنة جديدة من الحرف اليدوية! البخور والعنبر متوفرون الآن في متجري على YEM360 🧺 #سوق #حرف_يدوية", label: "حرف يدوية من عدن", colors: ["#7C2D12", "#EA580C"], location: "عدن، اليمن" },
  { author: "admin", text: "أهلاً بكم في منصة YEM360 — عالمك الرقمي في منصة واحدة. نسعد بتجاربكم وملاحظاتكم لتحسين التجربة #YEM360 #إطلاق", label: "YEM360", colors: ["#0F766E", "#134E4A"] },
  { author: "noor", text: "أول يوم لي على المنصة! الواجهة العربية سلسة والوضع الداكن جميل جداً ✨ #تجربة_مستخدم", label: "تجربة استخدام", colors: ["#4C1D95", "#8B5CF6"] },
  { author: "sara", text: "تصميم شريط التنقل السفلي في الهاتف يجعل الوصول لكل شيء بلمسة واحدة — درس في UX بسيط وفعّال #تصميم #واجهات", label: "UX بسيط وفعّال", colors: ["#155E75", "#06B6D4"] },
];

async function main() {
  console.log("🌱 YEM360 seed — starting (demo data, clearly labeled)");
  const created: Record<string, string> = {};

  // ── users ──
  for (const u of USERS) {
    const exists = await db.user.findUnique({ where: { username: u.username } });
    if (exists) {
      created[u.username] = exists.id;
      console.log(`  · user exists: @${u.username}`);
      continue;
    }
    const avatarUrl = await saveImage(avatarSVG(u.name[0], u.colors[0], u.colors[1]), "avatars");
    const coverUrl = await saveImage(gradientSVG(1440, 480, u.colors[1], u.colors[0], u.name, u.username), "posts");
    const user = await db.user.create({
      data: {
        username: u.username,
        email: `${u.username}@yem360.app`,
        passwordHash: hashPasswordSync(u.username === "admin" ? ADMIN_PASSWORD : DEMO_PASSWORD),
        name: u.name,
        role: u.role ?? "USER",
        accountType: u.accountType ?? "PERSONAL",
        professionalCategory: u.category,
        isVerified: !!u.verified,
        language: "AR",
      },
    });
    await db.profile.create({ data: { userId: user.id, bio: u.bio, avatarUrl, coverUrl, location: u.username === "lina" ? "عدن، اليمن" : u.username === "yousef" ? "صنعاء، اليمن" : "اليمن" } });
    await db.userSetting.create({ data: { userId: user.id } });
    await db.privacySetting.create({ data: { userId: user.id } });
    created[u.username] = user.id;
    console.log(`  ✓ user: @${u.username}${u.role === "ADMIN" ? " (ADMIN)" : ""}`);
  }

  // follow graph
  const followPairs = [
    ["sara", "omar"], ["sara", "yousef"], ["sara", "admin"], ["omar", "sara"], ["omar", "admin"],
    ["lina", "sara"], ["yousef", "sara"], ["yousef", "omar"], ["noor", "sara"], ["noor", "lina"],
    ["omar", "yousef"], ["lina", "admin"], ["noor", "omar"], ["sara", "lina"],
  ];
  for (const [a, b] of followPairs) {
    if (!created[a] || !created[b]) continue;
    await db.follow.upsert({
      where: { followerId_followingId: { followerId: created[a], followingId: created[b] } },
      update: {},
      create: { followerId: created[a], followingId: created[b], status: "ACCEPTED" },
    });
  }
  console.log("  ✓ follow graph");

  // ── posts with media ──
  for (const p of POSTS) {
    const existing = await db.post.findFirst({ where: { authorId: created[p.author], content: { contains: p.text.slice(0, 30) } } });
    if (existing) continue;
    const mediaUrl = p.label ? await saveImage(gradientSVG(1200, 800, p.colors![1], p.colors![0], p.label, "YEM360"), "posts") : null;
    const post = await db.post.create({
      data: {
        authorId: created[p.author],
        content: p.text,
        privacy: "PUBLIC",
        locationName: p.location,
        latitude: p.location ? (p.location.includes("عدن") ? 12.79 : 15.35) : null,
        longitude: p.location ? (p.location.includes("عدن") ? 45.02 : 44.2) : null,
        viewCount: Math.floor(Math.random() * 400) + 40,
      },
    });
    if (mediaUrl) await db.postMedia.create({ data: { postId: post.id, type: "IMAGE", url: mediaUrl, orderIndex: 0 } });
    // hashtags
    const names = [...new Set((p.text.match(/#([\p{L}\p{N}_]{2,40})/gu) || []).map((x) => x.slice(1)))];
    for (const name of names) {
      const tag = await db.hashtag.upsert({ where: { name }, update: { useCount: { increment: 1 }, lastUsedAt: new Date() }, create: { name, useCount: 1, lastUsedAt: new Date() } });
      await db.postHashtag.create({ data: { postId: post.id, hashtagId: tag.id } });
    }
    // likes + comments
    const likers = Object.values(created).filter((id) => id !== created[p.author]);
    for (const liker of likers.slice(0, 1 + Math.floor(Math.random() * likers.length))) {
      await db.like.create({ data: { userId: liker, postId: post.id } }).catch(() => null);
    }
    const commentsBy: Record<string, string[]> = {
      sara: ["تصميم المنصة مذهل فعلاً!", "أتفق تماماً 👏"],
      omar: ["معلومة مفيدة، شكراً لك", "جربت وهذي أفضل طريقة"],
      lina: ["بانتظار المزيد من أعمالك!", "روح إيجابية 🌟"],
      yousef: ["اللقطات جميلة جداً", "متابعينك يحبون هذا"],
      noor: ["أول تعليق لي هنا 😄", "محتوى ملهم"],
      admin: ["شكراً لتفاعلكم مع المنصة ❤"],
    };
    const pool = [...(commentsBy[p.author] || []), ...Object.values(commentsBy).flat()];
    let c = 0;
    for (const uid of likers.slice(0, 2)) {
      const text = pool[(c + pool.length) % pool.length];
      c++;
      if (text) await db.comment.create({ data: { authorId: uid, postId: post.id, text } });
    }
  }
  console.log("  ✓ posts + likes + comments + hashtags");

  // ── stories (24h) ──
  const storyDefs = [
    { author: "sara", label: "يوم جميل ☀", colors: ["#0F766E", "#14B8A6"] as [string, string] },
    { author: "yousef", label: "عدن الليلة 🌙", colors: ["#7C2D12", "#EA580C"] as [string, string] },
    { author: "admin", label: "YEM360 انطلقت 🚀", colors: ["#134E4A", "#0F766E"] as [string, string] },
  ];
  for (const s of storyDefs) {
    const existing = await db.story.findFirst({ where: { userId: created[s.author], expiresAt: { gt: new Date() } } });
    if (existing) continue;
    const url = await saveImage(gradientSVG(1080, 1920, s.colors[1], s.colors[0], s.label, "YEM360"), "stories");
    await db.story.create({
      data: { userId: created[s.author], type: "IMAGE", mediaUrl: url, expiresAt: new Date(Date.now() + 24 * 3600 * 1000) },
    });
  }
  console.log("  ✓ stories");

  // ── products + one order ──
  const products = [
    { seller: "lina", title: "بخور عدني أصلي — عبوة 100غ", description: "بخور عدني معتّق بجودة عالية، رائحة تدوم طويلاً. التوصيل داخل عدن مجاناً، والدفع عند الاستلام.", price: 4500, category: "HANDMADE", stock: 12, label: "بخور عدني", colors: ["#7C2D12", "#EA580C"] as [string, string] },
    { seller: "lina", title: "طقم فناجيل فخار يدوي (6 قطع)", description: "مصنوع يدوياً في ورشتنا بعدن، تصميم يمني أصيل مع تشطيب مقاوم للحرارة.", price: 12000, category: "HANDMADE", stock: 5, label: "فناجيل فخار", colors: ["#92400E", "#F59E0B"] as [string, string] },
    { seller: "omar", title: "استشارة برمجية — جلسة ساعة", description: "جلسة فردية عبر مكالمة صوتية: مراجعة كود، خطة تعلم، أو بناء مشروع. موعد مرن.", price: 8000, category: "SERVICES", stock: 20, label: "استشارة برمجية", colors: ["#115E59", "#0D9488"] as [string, string] },
    { seller: "sara", title: "باقة تصميم شعار + هوية مصغرة", description: "شعار احترافي مع دليل ألوان وخطوط، تسليم خلال 5 أيام عمل بملفات مفتوحة.", price: 25000, category: "SERVICES", stock: 8, label: "هوية بصرية", colors: ["#155E75", "#06B6D4"] as [string, string] },
  ];
  for (const pr of products) {
    const exists = await db.product.findFirst({ where: { sellerId: created[pr.seller], title: pr.title } });
    if (exists) continue;
    const img = await saveImage(gradientSVG(1200, 900, pr.colors[1], pr.colors[0], pr.label, "سوق YEM360"), "products");
    const product = await db.product.create({
      data: { sellerId: created[pr.seller], title: pr.title, description: pr.description, price: pr.price, currency: "YER", category: pr.category, stock: pr.stock },
    });
    await db.productImage.create({ data: { productId: product.id, url: img, orderIndex: 0 } });
  }
  // a demo order (noor buys بخور)
  const bukhor = await db.product.findFirst({ where: { title: { contains: "بخور" } } });
  if (bukhor && !(await db.order.findFirst({ where: { productId: bukhor.id, buyerId: created["noor"] } }))) {
    await db.order.create({
      data: { productId: bukhor.id, buyerId: created["noor"], sellerId: bukhor.sellerId, quantity: 2, totalPrice: bukhor.price * 2, status: "CONFIRMED", address: "المنصورة، عدن", phone: "0770000000", note: "بيانات تجريبية للعرض" },
    });
    await db.product.update({ where: { id: bukhor.id }, data: { stock: { decrement: 2 } } });
  }
  console.log("  ✓ products + demo order");

  // ── broadcast channel ──
  if (!(await db.channel.findUnique({ where: { handle: "yem360_news" } }))) {
    const ch = await db.channel.create({
      data: { name: "أخبار YEM360", handle: "yem360_news", description: "القناة الرسمية لتحديثات المنصة والميزات الجديدة.", ownerId: created["admin"], subscriberCount: 5 },
    });
    for (const u of ["sara", "omar", "lina", "yousef", "noor"]) {
      await db.channelSubscriber.create({ data: { channelId: ch.id, userId: created[u] } }).catch(() => null);
    }
    await db.channelMessage.create({ data: { channelId: ch.id, senderId: created["admin"], text: "أهلاً بكم في قناة أخبار YEM360 — سنعلن هنا عن الميزات الجديدة أول بأول 🎉" } });
    await db.channelMessage.create({ data: { channelId: ch.id, senderId: created["admin"], text: "تحديث جديد: قنوات البث متاحة الآن للجميع — أنشئ قناتك وانشر لمتابعيك بضغطة واحدة." } });
  }
  console.log("  ✓ broadcast channel");

  // ── approved demo ad ──
  if (!(await db.advertisement.findFirst({ where: { title: { contains: "YEM360" } } }))) {
    const adImg = await saveImage(gradientSVG(1200, 630, "#0D9488", "#134E4A", "جرّب YEM360 اليوم", "منصة واحدة لكل عالمك الرقمي"), "ads");
    await db.advertisement.create({
      data: {
        advertiserId: created["admin"],
        title: "جرّب YEM360 اليوم",
        body: "منشورات، قصص، ريلز، رسائل لحظية، سوق وقنوات بث — كل ذلك في منصة عربية واحدة.",
        imageUrl: adImg,
        targetUrl: "https://yem360.app",
        budget: 100000,
        status: "ACTIVE",
        approvedById: created["admin"],
      },
    });
  }
  console.log("  ✓ demo ad (ACTIVE)");

  // ── group chat ──
  if (!(await db.conversation.findFirst({ where: { type: "GROUP", title: "فريق المحتوى" } }))) {
    const conv = await db.conversation.create({ data: { type: "GROUP", title: "فريق المحتوى", createdBy: created["admin"] } });
    await db.conversationParticipant.createMany({
      data: [
        { conversationId: conv.id, userId: created["admin"], role: "OWNER" },
        ...["sara", "omar", "lina", "yousef"].map((u) => ({ conversationId: conv.id, userId: created[u] })),
      ],
    });
    await db.groupChat.create({ data: { conversationId: conv.id, description: "تنسيق محتوى المنصة — بيانات تجريبية" } });
    await db.message.create({ data: { conversationId: conv.id, senderId: created["admin"], text: "أهلاً بالفريق 👋 نناقش هنا خطة محتوى الأسبوع." } });
    await db.message.create({ data: { conversationId: conv.id, senderId: created["sara"], text: "سأجهز بانرات القصص اليوم." } });
    await db.conversation.update({ where: { id: conv.id }, data: { lastMessageAt: new Date() } });
  }
  console.log("  ✓ group chat");

  // ── reels (vertical demo videos served from /public/reels) ──
  if ((await db.reel.count()) === 0) {
    const reelsData: Array<{ by: string; caption: string; video: string; music: string; views: number }> = [
      { by: "sara", caption: "جولة في أزقة صنعاء القديمة 🏙️ #اليمن #صنعاء", video: "/reels/r1.mp4", music: "ألحان اليمن — لوب", views: 1240 },
      { by: "omar", caption: "تصميم واجهة جديدة للمنصة ✨ #تصميم #UX", video: "/reels/r2.mp4", music: "Neon Drive — Loop", views: 860 },
      { by: "lina", caption: "ذهب اليمن على الطراز الحديث 💛 #ذهب #فن", video: "/reels/r3.mp4", music: "Golden Hour — Instrumental", views: 2130 },
      { by: "noor", caption: "صباح أزرق من عدن ☁️ #عدن #صباح", video: "/reels/r4.mp4", music: "Blue Morning — Chill", views: 540 },
    ];
    for (const r of reelsData) {
      if (!created[r.by]) continue;
      await db.reel.create({
        data: { userId: created[r.by], caption: r.caption, videoUrl: r.video, duration: 9, musicName: r.music, viewCount: r.views },
      });
    }
    console.log(`  ✓ ${reelsData.length} demo reels`);
  } else {
    console.log("  · reels exist, skip");
  }

  // ── banned words baseline ──
  await db.bannedWord.upsert({ where: { word: "spam_word_demo" }, update: {}, create: { word: "spam_word_demo" } });

  console.log("\n✅ Seed complete — DEMO DATA ONLY (not real content).");
  console.log("   Admin:  username=admin  password=(SEED_ADMIN_PASSWORD from .env)");
  console.log("   Demos:  sara / omar / lina / yousef / noor   password=Demo12345");
  await db.$disconnect();
}

main().catch(async (e) => {
  console.error("seed failed:", e);
  await db.$disconnect();
  process.exit(1);
});
