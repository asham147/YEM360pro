"""Fix remaining TS errors batch 2: serialize-posts, extras, qr, media, page, explore."""
import pathlib

ROOT = pathlib.Path("/home/z/my-project")


def patch(rel, old, new, count=1):
    p = ROOT / rel
    s = p.read_text()
    assert old in s, f"pattern missing in {rel}"
    assert s.count(old) >= 1
    p.write_text(s.replace(old, new, count))
    print(f"fixed {rel}")


# 1. serialize-posts.ts — add _count to PostWithRelations include type
patch(
    "src/lib/serialize-posts.ts",
    """    likes: { select: { userId: true } };
    saves: { select: { userId: true } };
    reposts: { select: { authorId: true } };""",
    """    likes: { select: { userId: true } };
    saves: { select: { userId: true } };
    reposts: { select: { authorId: true } };
    _count: { select: { likes: true; comments: true; reposts: true } };""",
)

# 2. serialize-posts.ts — add _count to CommentWithRelations include type (top + nested replies)
patch(
    "src/lib/serialize-posts.ts",
    """    author: { include: { profile: true } };
    likes: { select: { userId: true } };
    replies: {
      include: { author: { include: { profile: true } }; likes: { select: { userId: true } } };
      orderBy: { createdAt: "asc" };
    };
  };
}>;""",
    """    author: { include: { profile: true } };
    likes: { select: { userId: true } };
    _count: { select: { likes: true; replies: true } };
    replies: {
      include: {
        author: { include: { profile: true } };
        likes: { select: { userId: true } };
        _count: { select: { likes: true } };
      };
      orderBy: { createdAt: "asc" };
    };
  };
}>;""",
)

# 3. extras.tsx — local UserCheck must accept className
patch(
    "src/components/yem/extras.tsx",
    """function UserCheck({ size }: { size: number }) {
  return <UserPlus size={size} />;
}""",
    """function UserCheck({ size, className }: { size: number; className?: string }) {
  return <UserPlus size={size} className={className} />;
}""",
)

# 4. qr.tsx — import t
patch(
    "src/components/yem/qr.tsx",
    'import { useApp } from "@/lib/store";',
    'import { useApp } from "@/lib/store";\nimport { t } from "@/lib/i18n";',
)

# 5. media.ts — widen out buffer type
patch(
    "src/lib/media.ts",
    "  let out = buf;",
    "  let out: Buffer<ArrayBufferLike> = buf;",
)

# 6. page.tsx — user possibly null
patch(
    "src/app/page.tsx",
    """            key={route.param || user.username}
            username={route.param || user.username}""",
    """            key={route.param || user?.username || ""}
            username={route.param || user?.username || ""}""",
)

# 7. explore.tsx — ProductDTO.images[0] + seller.username
patch(
    "src/components/yem/explore.tsx",
    "{p.image ? <img src={p.image} alt={p.title}",
    "{p.images[0] ? <img src={p.images[0]} alt={p.title}",
)
patch(
    "src/components/yem/explore.tsx",
    "{p.price} {p.currency} · @{p.seller}",
    "{p.price} {p.currency} · @{p.seller.username}",
)

print("done")
