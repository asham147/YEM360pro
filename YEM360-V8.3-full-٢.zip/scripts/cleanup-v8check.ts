/**
 * YEM360 — one-off cleanup: remove the v8check browser-verification user.
 * All owned rows cascade from User (onDelete: Cascade).
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  const u = await db.user.findUnique({ where: { username: "v8check" } });
  if (!u) { console.log("no test user"); return; }
  const id = u.id;
  // non-cascading actor references first
  await db.notification.deleteMany({ where: { actorId: id } });
  await db.securityEvent.deleteMany({ where: { userId: id } }).catch(() => {});
  await db.user.delete({ where: { id } }); // cascades the rest
  console.log("deleted test user:", u.username);
}
main().finally(() => db.$disconnect());
