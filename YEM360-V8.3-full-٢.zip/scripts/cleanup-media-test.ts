/**
 * YEM360 — one-off cleanup: remove media-test user + uploaded test files.
 */
import { PrismaClient } from "@prisma/client";
import fs from "fs/promises";
const db = new PrismaClient();
async function main() {
  const u = await db.user.findUnique({ where: { username: "mediatest" } });
  if (u) {
    const stories = await db.story.findMany({ where: { userId: u.id } });
    const reels = await db.reel.findMany({ where: { userId: u.id } });
    for (const s of stories) if (s.mediaUrl) await fs.rm(`uploads${s.mediaUrl.replace("/api/media", "")}`, { force: true }).catch(() => null);
    for (const r of reels) await fs.rm(`uploads${r.videoUrl.replace("/api/media", "")}`, { force: true }).catch(() => null);
    await db.user.delete({ where: { id: u.id } });
    console.log("deleted user mediatest + files:", stories.length, "stories,", reels.length, "reels");
  } else {
    console.log("mediatest not found");
  }
}
main().finally(() => db.$disconnect());
