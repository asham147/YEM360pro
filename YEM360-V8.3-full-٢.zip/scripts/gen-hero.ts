/**
 * YEM360 — generate hero banner images (night + day) for the home feed.
 */
import ZAI from "z-ai-web-dev-sdk";
import fs from "fs";

const NIGHT_PROMPT =
  "Panoramic view of the Old City of Sanaa Yemen at night, traditional multi-story tower houses with ornate white gypsum window trims glowing warm golden light, deep navy blue night sky with stars and subtle blue nebula, a large glowing blue planet Earth horizon arc in the far distance, city perched on a rocky hill, magical cinematic atmosphere, navy blue and royal gold color palette, photorealistic digital art, no text, no words, no letters, no flags";

const DAY_PROMPT =
  "Panoramic view of the Old City of Sanaa Yemen in daytime, traditional multi-story tower houses with ornate white gypsum window trims, bright blue sky with soft white clouds and a few flying birds, distant mountains, city on a rocky hill with green trees, fresh cheerful atmosphere, sky blue white and gold color palette, photorealistic digital art, no text, no words, no letters, no flags";

async function gen(zai: Awaited<ReturnType<typeof ZAI.create>>, prompt: string, out: string) {
  const res = await zai.images.generations.create({ prompt, size: "1344x768" });
  const b64 = res.data?.[0]?.base64;
  if (!b64) throw new Error("empty image data");
  fs.writeFileSync(out, Buffer.from(b64, "base64"));
  console.log("saved", out, fs.statSync(out).size, "bytes");
}

async function main() {
  const zai = await ZAI.create();
  fs.mkdirSync("public/brand", { recursive: true });
  await gen(zai, NIGHT_PROMPT, "public/brand/hero-night.png");
  await gen(zai, DAY_PROMPT, "public/brand/hero-day.png");
}
main().catch((e) => { console.error(e); process.exit(1); });
