/**
 * YEM360 — one-off cleanup: remove V8 verification test users
 * (browser-registered v8tester + residual smoke/dbg accounts from earlier E2E runs).
 */
import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();

async function main() {
  const targets = await db.user.findMany({
    where: {
      OR: [
        { username: "v8tester" },
        { username: { startsWith: "smoke" } },
        { username: { startsWith: "dbg" } },
      ],
    },
    select: { id: true, username: true },
  });
  for (const u of targets) {
    await db.user.delete({ where: { id: u.id } });
    console.log("deleted:", u.username);
  }
  if (!targets.length) console.log("nothing to clean");
}

main().finally(() => db.$disconnect());
