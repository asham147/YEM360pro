#!/usr/bin/env python3
"""Render YEM360 diagram HTML files to PNG via Playwright (charts skill pipeline)."""
import asyncio, os, sys
from playwright.async_api import async_playwright

JOBS = [
    ("docs/diagrams/architecture.html", "docs/diagrams/architecture.png", 1280),
    ("docs/diagrams/erd.html", "docs/diagrams/erd.png", 1640),
    ("docs/diagrams/dfd.html", "docs/diagrams/dfd.png", 1480),
]

async def render(pw, html_path, out_path, width):
    browser = await pw.chromium.launch(headless=True)
    page = await browser.new_page(viewport={"width": width, "height": 900}, device_scale_factor=2)
    await page.goto(f"file://{os.path.abspath(html_path)}", wait_until="networkidle")
    await page.wait_for_timeout(700)
    el = page.locator("#root")
    bbox = await el.bounding_box()
    if bbox:
        fit_w = max(width, int(bbox["width"] + 60))
        fit_h = int(bbox["height"] + 60)
        await page.set_viewport_size({"width": fit_w, "height": fit_h})
        await page.wait_for_timeout(250)
    await el.screenshot(path=out_path)
    await browser.close()
    kb = os.path.getsize(out_path) / 1024
    print(f"✓ {out_path} ({kb:.0f} KB)")

async def main():
    os.chdir("/home/z/my-project")
    async with async_playwright() as pw:
        for html, png, w in JOBS:
            await render(pw, html, png, w)

asyncio.run(main())
