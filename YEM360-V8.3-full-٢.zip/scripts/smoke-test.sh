#!/usr/bin/env bash
# YEM360 — API smoke tests (المرحلة 11: الاختبارات)
# Critical paths end-to-end against a running instance.
# Each simulated user gets its own client IP (rate limiter buckets are per-IP).
# Usage: bash scripts/smoke-test.sh [BASE_URL]
set -u
BASE="${1:-http://localhost:3000}"
PASS=0; FAIL=0
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

A_IP="10.7.0.21"; B_IP="10.7.0.22"; AD_IP="10.7.0.23"

say()  { printf "%s\n" "$*"; }
ok()   { PASS=$((PASS+1)); say "  ✓ $1"; }
bad()  { FAIL=$((FAIL+1)); say "  ✗ $1"; }
check() { if [ "$2" = "$3" ]; then ok "$1"; else bad "$1 (expected=$2 got=$3)"; fi }

jsonget() { bun -e "const d=await new Response(Bun.stdin.stream()).json(); const p='$1'.split('.'); let v=d; for(const k of p){ if(v==null){v=null;break} v=v[k] } console.log(v===undefined?'':v)" 2>/dev/null; }

# wrappers (cookie jars + stable client IPs)
CA()  { curl -s -b "$TMP/a.txt"   -c "$TMP/a.txt"   -H "X-Forwarded-For: $A_IP" "$@"; }
CB()  { curl -s -b "$TMP/b.txt"   -c "$TMP/b.txt"   -H "X-Forwarded-For: $B_IP" "$@"; }
CAD() { curl -s -b "$TMP/adm.txt" -c "$TMP/adm.txt" -H "X-Forwarded-For: $AD_IP" "$@"; }

say "── YEM360 smoke tests against $BASE ──"

# pre-clean previous smoke users (test isolation only)
bun -e "
const {PrismaClient}=require('/home/z/my-project/node_modules/@prisma/client');
const p=new PrismaClient();
(async()=>{
  const users=await p.user.findMany({where:{username:{startsWith:'smoke'}}});
  for(const u of users){ await p.user.delete({where:{id:u.id}}).catch(()=>null); }
  await p.\$disconnect();
})();" >/dev/null 2>&1
sleep 1

# 1. health
check "health.ok" "true" "$(curl -s "$BASE/api/health" | jsonget ok)"

# 2. register user A
U="smoke$(date +%s)"
R=$(curl -s -c "$TMP/a.txt" -X POST "$BASE/api/auth/register" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $A_IP" \
  -d "{\"name\":\"مختبر آلي\",\"username\":\"$U\",\"email\":\"$U@tst.dev\",\"password\":\"Test12345\"}")
check "register.ok" "true" "$(echo "$R" | jsonget ok)"
check "register.role" "USER" "$(echo "$R" | jsonget user.role)"

# 3. me
check "me.ok" "true" "$(CA "$BASE/api/auth/me" | jsonget ok)"

# 4. weak password rejected
RBAD=$(curl -s -X POST "$BASE/api/auth/register" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $B_IP" \
  -d "{\"name\":\"x\",\"username\":\"xx$U\",\"email\":\"x$U@t.dev\",\"password\":\"123\"}")
check "register.weak-password-rejected" "VALIDATION" "$(echo "$RBAD" | jsonget error)"

# 5. wrong password
LW=$(curl -s -X POST "$BASE/api/auth/login" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $B_IP" \
  -d "{\"identifier\":\"$U\",\"password\":\"wrongpass1\"}")
check "login.wrong-password" "INVALID_CREDENTIALS" "$(echo "$LW" | jsonget error)"

# 6. correct login
L=$(curl -s -c "$TMP/a.txt" -X POST "$BASE/api/auth/login" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $A_IP" \
  -d "{\"identifier\":\"$U\",\"password\":\"Test12345\"}")
check "login.ok" "true" "$(echo "$L" | jsonget ok)"

# 7. CSRF blocked (foreign Origin)
CS=$(curl -s -X POST "$BASE/api/posts" -H "Content-Type: application/json" -H "Origin: https://evil.example" -b "$TMP/a.txt" -H "X-Forwarded-For: $A_IP" -d '{"content":"x"}')
check "csrf.blocked" "CSRF" "$(echo "$CS" | jsonget error)"

# 8. unauthenticated blocked
UA=$(curl -s -X POST "$BASE/api/posts" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $A_IP" -d '{"content":"x"}')
check "auth.required" "UNAUTHENTICATED" "$(echo "$UA" | jsonget error)"

# 9. create post with hashtag
P=$(CA -X POST "$BASE/api/posts" -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d '{"content":"اختبار آلي للمنصة #اختبار_آلي","privacy":"PUBLIC"}')
PID=$(echo "$P" | jsonget post.id)
check "post.create" "true" "$(echo "$P" | jsonget ok)"

# 10. hashtag searchable
S=$(CA "$BASE/api/search?q=%D8%A7%D8%AE%D8%AA%D8%A8%D8%A7%D8%B1")
check "search.hashtag-found" "true" "$(echo "$S" | bun -e "const d=await new Response(Bun.stdin.stream()).json();console.log(d.hashtags.some(h=>h.name==='اختبار_آلي'))" 2>/dev/null)"

# 11. like / unlike
LK=$(CA -X POST "$BASE/api/posts/$PID/like" -H "Origin: $BASE")
check "like.ok" "true" "$(echo "$LK" | jsonget liked)"
UL=$(CA -X DELETE "$BASE/api/posts/$PID/like" -H "Origin: $BASE")
check "unlike.ok" "false" "$(echo "$UL" | jsonget liked)"

# 12. comment
CM=$(CA -X POST "$BASE/api/posts/$PID/comments" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"text":"تعليق آلي"}')
check "comment.create" "true" "$(echo "$CM" | jsonget ok)"

# 13. save + repost
SV=$(CA -X POST "$BASE/api/posts/$PID/save" -H "Origin: $BASE")
check "save.ok" "true" "$(echo "$SV" | jsonget saved)"
RP=$(CA -X POST "$BASE/api/posts/$PID/repost" -H "Origin: $BASE")
check "repost.ok" "true" "$(echo "$RP" | jsonget reposted)"

# 14. feed has own post
FID=$(CA "$BASE/api/posts" | bun -e "const d=await new Response(Bun.stdin.stream()).json();console.log((d.posts||[]).some(p=>p.id==='$PID')?'yes':'no')" 2>/dev/null)
check "feed.has-own-post" "yes" "$FID"

# 15. banned word rejected
BW=$(CA -X POST "$BASE/api/posts" -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d '{"content":"هذا يحتوي spam_word_demo بالداخل"}')
check "moderation.banned-word" "CONTENT_BLOCKED" "$(echo "$BW" | jsonget error)"

# 16. follow sara
FL=$(CA -X POST "$BASE/api/follows/sara" -H "Origin: $BASE")
check "follow.sara" "true" "$(echo "$FL" | jsonget ok)"

# 17. DM to sara
SID=$(CA "$BASE/api/profile/sara" | jsonget user.id)
CNV=$(CA -X POST "$BASE/api/messages/conversations" -H "Content-Type: application/json" -H "Origin: $BASE" -d "{\"type\":\"DIRECT\",\"userId\":\"$SID\"}")
CID2=$(echo "$CNV" | jsonget conversationId)
MSG=$(CA -X POST "$BASE/api/messages/conversations/$CID2" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"text":"رسالة اختبار آلي"}')
check "dm.send" "true" "$(echo "$MSG" | jsonget ok)"

# 18. marketplace: create product (A) + order it (B)
PR=$(CA -X POST "$BASE/api/products" -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d '{"title":"منتج اختبار آلي","description":"وصف المنتج الاختباري الكافي","price":1000,"currency":"YER","stock":3,"category":"GENERAL"}')
PRID=$(echo "$PR" | jsonget id)
check "product.create" "true" "$(echo "$PR" | jsonget ok)"

B="smokeb$(date +%s)"
LB=$(curl -s -c "$TMP/b.txt" -X POST "$BASE/api/auth/register" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $B_IP" \
  -d "{\"name\":\"مشترٍ آلي\",\"username\":\"$B\",\"email\":\"$B@tst.dev\",\"password\":\"Test12345\"}")
check "register.buyer" "true" "$(echo "$LB" | jsonget ok)"
OD=$(CB -X POST "$BASE/api/orders" -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d "{\"productId\":\"$PRID\",\"quantity\":1,\"address\":\"عنوان اختبار\",\"phone\":\"0770000000\"}")
check "order.create" "true" "$(echo "$OD" | jsonget ok)"

# 19. ads feed shows ACTIVE demo ad
ADF=$(CB "$BASE/api/ads/feed")
check "ads.feed-has-active" "true" "$(echo "$ADF" | bun -e "const d=await new Response(Bun.stdin.stream()).json();console.log((d.ads||[]).length>0)" 2>/dev/null)"

# 20. report + admin queue
RP2=$(CB -X POST "$BASE/api/reports" -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d "{\"targetType\":\"POST\",\"targetId\":\"$PID\",\"reason\":\"SPAM\"}")
check "report.create" "true" "$(echo "$RP2" | jsonget ok)"

APW=$(grep SEED_ADMIN_PASSWORD /home/z/my-project/.env | cut -d= -f2 | head -1)
LA=$(curl -s -c "$TMP/adm.txt" -X POST "$BASE/api/auth/login" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $AD_IP" -d "{\"identifier\":\"admin\",\"password\":\"$APW\"}")
check "login.admin" "ADMIN" "$(echo "$LA" | jsonget user.role)"
RQ=$(CAD "$BASE/api/admin/reports?status=PENDING")
check "admin.reports-queue" "true" "$(echo "$RQ" | bun -e "const d=await new Response(Bun.stdin.stream()).json();console.log((d.reports||[]).some(r=>r.targetId==='$PID'))" 2>/dev/null)"

# 21. non-admin blocked from admin API
NOA=$(CA "$BASE/api/admin/stats")
check "admin.guard-user" "FORBIDDEN" "$(echo "$NOA" | jsonget error)"

# 22. story create + list
ST=$(CA -X POST "$BASE/api/stories" -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d '{"type":"TEXT","text":"قصة اختبار آلي","bgColor":"teal"}')
check "story.create" "true" "$(echo "$ST" | jsonget ok)"
STL=$(CA "$BASE/api/stories")
check "stories.list-mine" "true" "$(echo "$STL" | bun -e "const d=await new Response(Bun.stdin.stream()).json();console.log((d.groups||[]).some(g=>g.stories.some(s=>s.text==='قصة اختبار آلي')))" 2>/dev/null)"

# 23. channel create + broadcast
CH=$(CA -X POST "$BASE/api/channels" -H "Content-Type: application/json" -H "Origin: $BASE" \
  -d "{\"name\":\"قناة الاختبار الآلي\",\"handle\":\"smoke$(date +%s)\",\"description\":\"قناة اختبار\"}")
CHID=$(echo "$CH" | jsonget id)
check "channel.create" "true" "$(echo "$CH" | jsonget ok)"
BCM=$(CA -X POST "$BASE/api/channels/$CHID/messages" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"text":"بث اختبار آلي"}')
check "channel.broadcast" "true" "$(echo "$BCM" | jsonget ok)"

# 24. insights guard for personal account
IN=$(CA "$BASE/api/insights")
check "insights.personal-guard" "NOT_PROFESSIONAL" "$(echo "$IN" | jsonget error)"

# 25. rate limiting on login (unique identifier, fresh bucket)
RLIP="10.7.0.99"
for i in $(seq 1 12); do
  curl -s -X POST "$BASE/api/auth/login" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $RLIP" \
    -d '{"identifier":"nosuchuser_rl","password":"wrongpass1"}' >/dev/null
done
RLRESP=$(curl -s -X POST "$BASE/api/auth/login" -H "Content-Type: application/json" -H "Origin: $BASE" -H "X-Forwarded-For: $RLIP" -d '{"identifier":"nosuchuser_rl","password":"wrongpass1"}')
if echo "$RLRESP" | grep -q "RATE_LIMITED"; then ok "ratelimit.login"; else bad "ratelimit.login (no 429)"; fi

# 26. logout
LO=$(CA -X POST "$BASE/api/auth/logout" -H "Origin: $BASE")
check "logout.ok" "true" "$(echo "$LO" | jsonget ok)"

say ""
say "── results: $PASS passed, $FAIL failed ──"
[ $FAIL -eq 0 ] && say "ALL GREEN ✅" || exit 1
