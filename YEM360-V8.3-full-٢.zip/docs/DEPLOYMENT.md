# YEM360 — دليل النشر والتشغيل (Deployment Guide)

## نظرة عامة على البنية عند النشر

```
المستخدمون ──HTTPS──> Caddy (443, شهادة تلقائية)
                        ├── /            → Next.js (منفذ 3000)  [PM2]
                        └── /?XTransformPort=3003 → yem-realtime (Socket.io)
                                    └─ لوحة تحكم داخلية على 3004 (local only)
قاعدة البيانات: db/yem360.db (SQLite) + مجلد uploads/
```

## 1) المتطلبات

- خادم Ubuntu 22.04+ (أي VPS بذاكرة 1GB+)
- Node.js 20+ و Bun: `curl -fsSL https://bun.sh/install | bash`
- Caddy: `sudo apt install caddy` (أو ثنائي رسمي)

## 2) تجهيز المشروع

```bash
git clone <repo> yem360 && cd yem360     # أو فك YEM360-Platform.zip
bun install

# الأسرار — ولّد قيماً جديدة ولا تشاركها
cp .env.example .env
node -e "console.log('JWT_SECRET='+require('crypto').randomBytes(48).toString('hex'))" >> .env
node -e "console.log('APP_SECRET='+require('crypto').randomBytes(32).toString('hex'))" >> .env
node -e "console.log('INTERNAL_SECRET='+require('crypto').randomBytes(32).toString('hex'))" >> .env
# حدّد كلمة مرور المدير الأولي قبل البذر
echo "SEED_ADMIN_PASSWORD=ضع_كلمة_قوية_هنا" >> .env

bunx prisma db push        # إنشاء الجداول
bun scripts/seed.ts        # (اختياري) حساب المدير + بيانات تجريبية موسومة
bun run build
```

## 3) التشغيل مع PM2

```bash
sudo npm i -g pm2
pm2 start "bun run start" --name yem360-web          # Next.js standalone على 3000
pm2 start "bun mini-services/yem-realtime/index.ts" --name yem360-realtime
pm2 save && pm2 startup      # تشغيل تلقائي عند إقلاع الخادم
```

> ملاحظة: `src/instrumentation.ts` يحاول إقلاع خدمة اللحظية تلقائياً إن لم تكن تعمل — تشغيلها كوحدة PM2 مستقلة هو الخيار الأكثر متانة (تأكد من تمرير نفس `.env`).

## 4) بوابة Caddy مع HTTPS تلقائي

ملف `/etc/caddy/Caddyfile`:

```caddy
yem360.example.com {
    @rt query XTransformPort=*
    handle @rt {
        reverse_proxy localhost:{query.XTransformPort}
    }
    handle {
        reverse_proxy localhost:3000
    }
}
```

```bash
sudo systemctl reload caddy   # شهادة Let's Encrypt تلقائياً عند أول طلب
```

ينتج عن ذلك: HTTPS إجباري، وكوكيز الجلسة تصبح `Secure` تلقائياً (وضع الإنتاج)، وتوجيه اتصالات Socket.io عبر نفس النطاق.

## 5) النسخ الاحتياطي المجدول

```bash
# سكربت المشروع الجاهز
chmod +x scripts/backup-db.sh
crontab -e
# نسخة يومية 3 فجراً تحفظ آخر 14 نسخة
0 3 * * * /path/to/yem360/scripts/backup-db.sh /var/backups/yem360 >> /var/log/yem360-backup.log 2>&1
```

نسخة يدوية فورية: من لوحة الإدارة → «تنزيل نسخة احتياطية» (يحمّل ملف SQLite كامل).

## 6) التحديث

```bash
git pull
bun install
bunx prisma db push          # ترحيل المخطط عند تغيّره
bun run build
pm2 restart yem360-web yem360-realtime
```

## 7) متغيرات البيئة (.env)

| المتغير | الوظيفة |
|---|---|
| `DATABASE_URL` | `file:/path/to/db/yem360.db` |
| `JWT_SECRET` | توقيع جلسات JWT (48 بايت عشوائي) |
| `APP_SECRET` | تشفير أسرار 2FA في القاعدة (AES-256-GCM) |
| `INTERNAL_SECRET` | مصادقة دفع الأحداث REST → خدمة اللحظية |
| `SEED_ADMIN_PASSWORD` | كلمة مرور المدير عند تشغيل البذر (غير مطلوبة بعد البذر) |
| `UPLOAD_DIR` · `MAX_IMAGE_MB` · `MAX_VIDEO_MB` | تخزين وحدود الوسائط (اختيارية) |
| `REALTIME_URL` | `http://127.0.0.1:3004/internal/emit` (افتراضي) |

**قاعدة ذهبية:** غيّر كل الأسرار قبل الإطلاق، ولا ترفع `.env` لأي مستودع، وفعّل جدار ح يفتح 80/443 فقط (المنافذ 3000/3003/3004 داخلية عبر Caddy).

## 8) Android وWindows

المنصة تعمل من المتصفح مباشرة دون تثبيت. على Android: من Chrome اختر «إضافة إلى الشاشة الرئيسية» (PWA manifest جاهز في `public/manifest.json`). على Windows: مثبّت الموقع كتطبيق من Edge/Chrome.

## 9) فحص ما بعد النشر

```bash
curl https://yem360.example.com/api/health      # {"ok":true,"realtime":true,...}
bash scripts/smoke-test.sh https://yem360.example.com
```
