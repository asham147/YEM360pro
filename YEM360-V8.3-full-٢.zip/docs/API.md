# YEM360 — مرجع واجهات REST (API Reference)

جميع الردود بصيغة موحّدة: `{ ok: true, ...بيانات }` أو `{ ok: false, error: CODE, message: "..." }`.
المصادقة عبر كوكي جلسة `yem360_session` (httpOnly) — لا حاجة لترويسات يدوية من المتصفح.
طلبات التعديل (POST/PATCH/DELETE) تتطلب ترويسة Origin مطابقة (حماية CSRF) وتخضع لحدود المعدل (429 عند التجاوز).

## المصادقة والحساب
| المسار | الطريقة | الوظيفة |
|---|---|---|
| `/api/auth/register` | POST | تسجيل (name, username فريد, email, password ≥8 بحرف ورقم) |
| `/api/auth/login` | POST | دخول بالبريد أو اسم المستخدم — يعيد `twoFactorRequired+challengeToken` عند تفعيل 2FA |
| `/api/auth/verify-2fa` | POST | إكمال الدخول برمز TOTP |
| `/api/auth/logout` | POST | إبطال الجلسة الحالية |
| `/api/auth/me` | GET | بياناتي + الإعدادات + عدادات غير المقروء |
| `/api/auth/password` | POST | تغيير كلمة المرور (يبطل بقية الجلسات) |
| `/api/auth/sessions` | GET | الجلسات النشطة (جهاز/متصفح/IP) |
| `/api/auth/sessions/:id` | DELETE | إنهاء جلسة بعينها |
| `/api/auth/realtime-token` | GET | رمز الاتصال بالخدمة اللحظية لصاحب الجلسة |
| `/api/auth/check-username?q=` | GET | توفر اسم المستخدم |

## الملف الشخصي والشبكة الاجتماعية
| المسار | الطريقة | الوظيفة |
|---|---|---|
| `/api/profile/:username` | GET | ملف + عدادات + علاقة الزائر (متابعة/صداقة/حظر) |
| `/api/profile` | PATCH | تعديل ملفي (اسم/نبذة/صور/نوع الحساب/فئة الاحتراف) |
| `/api/follows/:username` | POST / DELETE | متابعة (أو طلب لحساب خاص) / إلغاء |
| `/api/follows?username=&type=` | GET | قائمة المتابعين أو المتابَعين |
| `/api/friends` | GET / POST | قائمة الأصدقاء + الطلبات / إرسال طلب صداقة |
| `/api/friends/requests/:id` | POST / DELETE | قبول / رفض أو إزالة |
| `/api/blocks` | GET / POST / DELETE | المحظورون / حظر / رفع الحظر |

## المحتوى
| المسار | الطريقة | الوظيفة |
|---|---|---|
| `/api/posts` | GET / POST | التغذية (cursor) / إنشاء منشور (نص، ≤4 وسائط، خصوصية، موقع، repostOfId) |
| `/api/posts/:id` | GET / PATCH / DELETE | منشور مفرد / تعديل / حذف |
| `/api/posts/:id/like` | POST / DELETE | إعجاب / إلغاء |
| `/api/posts/:id/comments` | GET / POST | التعليقات (مع ردود) / تعليق جديد (parentId للرد) |
| `/api/posts/:id/save` | POST / DELETE | حفظ / إزالة من المحفوظات |
| `/api/posts/:id/repost` | POST / DELETE | إعادة نشر / إلغاؤها |
| `/api/posts/:id/view` | POST | عدّ مشاهدة |
| `/api/comments/:id` | DELETE | حذف تعليق (كاتبها/صاحب المنشور/الإشراف) |
| `/api/comments/:id/like` | POST / DELETE | إعجاب تعليق |
| `/api/stories` | GET / POST | قصص اليوم مجمّعة بالمستخدم / إنشاء قصة (JSON نصي أو multipart لوسائط) |
| `/api/stories/:id` | DELETE | حذف قصة (لصاحبها) |
| `/api/stories/:id/view` | POST | تسجيل مشاهدة |
| `/api/stories/:id/viewers` | GET | قائمة المشاهدين (لصاحب القصة) |
| `/api/reels` | GET / POST | تغذية الريلز (cursor) / نشر ريل (videoUrl, caption…) |
| `/api/reels/:id` | GET / DELETE | ريل مفرد (+عدّ مشاهدة) / حذف |
| `/api/reels/:id/like` · `/comments` | POST/DELETE · GET/POST | تفاعل الريلز |
| `/api/users/:username/posts` · `/reels` | GET | شبكة ملف المستخدم (تحترم الخصوصية) |
| `/api/tags/:name` | GET | صفحة هاشتاغ |
| `/api/notes` | GET / POST / DELETE | ملاحظة 24 ساعة |

## المراسلة والقنوات
| المسار | الطريقة | الوظيفة |
|---|---|---|
| `/api/messages/conversations` | GET / POST | صندوق الوارد بعدّادات غير المقروء / بدء DM أو إنشاء مجموعة |
| `/api/messages/conversations/:id` | GET / POST / DELETE | تاريخ المحادثة (+cursor) / إرسال (نص، صورة، رد) / مغادرة |
| `/api/messages/conversations/:id/read` | POST | تعليم مقروء |
| `/api/messages/conversations/:id/participants` | POST / DELETE | إضافة أعضاء / طرد أو مغادرة (مجموعات) |
| `/api/channels` | GET / POST | قنواتي+الاشتراكات+الاكتشاف / إنشاء قناة (handle فريد) |
| `/api/channels/:id` | GET | القناة + رسائل البث + حالة الاشتراك |
| `/api/channels/:id/subscribe` | POST / DELETE | اشتراك / إلغاء |
| `/api/channels/:id/messages` | POST | بثّ للجميع (مالك فقط) |
| `/api/notifications` | GET | الإشعارات (فلتر: all/likes/comments/follows/unread) |
| `/api/notifications/read` | POST | تعليم مقروء (id أو all) |

## الاكتشاف والأمان
| المسار | الطريقة | الوظيفة |
|---|---|---|
| `/api/search?q=` | GET | بحث: مستخدمون، منشورات، هاشتاغات، منتجات |
| `/api/explore` | GET | ترند منشورات مرجّح + هاشتاغات + مقترحون |
| `/api/map` | GET | منشورات موسومة جغرافياً |
| `/api/settings` | PATCH | إعدادات المستخدم + الخصوصية دفعة واحدة |
| `/api/security/events` | GET | 2FA الحالة + سجل الأحداث الأمنية |
| `/api/security/2fa/setup` | POST | توليد سر TOTP + QR |
| `/api/security/2fa/enable` · `/disable` | POST | تفعيل برمز / تعطيل بكلمة المرور |
| `/api/media/upload` | POST | رفع ملف (kind: post/story/reel/avatar/cover/message/product/ad) |
| `/api/media/:dir/:file` | GET | تقديم الوسائط بترويسات أمان |
| `/api/health` | GET | فحص الخدمة + حالة اللحظية |

## الأعمال والإشراف
| المسار | الطريقة | الوظيفة |
|---|---|---|
| `/api/ads` | GET / POST / PATCH | حملاتي / إنشاء (بانتظار الموافقة) / إيقاف أو تفعيل أو حذف |
| `/api/ads/feed` | GET | إعلانات نشطة مستهدفة للعارض (+تسجيل ظهور) |
| `/api/ads/:id/click` | POST | تسجيل نقرة وإرجاع الهدف |
| `/api/products` | GET / POST | السوق (بحث/تصنيف/mine) / إضافة منتج |
| `/api/products/:id` | GET / PATCH / DELETE | تفاصيل / تعديل / حذف (للبائع) |
| `/api/orders` | GET / POST | طلباتي أو مبيعاتي / إنشاء طلب (خصم مخزون) |
| `/api/orders/:id` | PATCH | تغيير حالة الطلب (انتقالات صالحة فقط) |
| `/api/insights` | GET | إحصائيات الحساب الاحترافي (403 لشخصي) |
| `/api/reports` | POST | بلاغ (targetType + reason) |
| `/api/admin/stats` | GET | لوحة القيادة (مدير/مشرف) |
| `/api/admin/users` | GET / PATCH | بحث مستخدمين / BAN-UNBAN-VERIFY-MAKE_MOD |
| `/api/admin/reports` | GET / PATCH | طابور البلاغات / إجراء: DISMISS-DELETE_CONTENT-BAN_USER |
| `/api/admin/ads` | GET / PATCH | مراجعة الحملات: APPROVE-REJECT-PAUSE-END |
| `/api/admin/banned-words` | GET / POST / DELETE | إدارة الكلمات المحجوبة |
| `/api/admin/backup` | GET | تنزيل نسخة SQLite كاملة (مدير فقط) |

### أكواد الأخطاء الرئيسية
`UNAUTHENTICATED` (401) · `FORBIDDEN` (403) · `CSRF` (403) · `RATE_LIMITED` (429) · `VALIDATION` (422) · `CONTENT_BLOCKED` (422) · `NOT_FOUND` (404) · `PRIVATE` (403) · `SUSPENDED` (403) · `SERVER_ERROR` (500)
