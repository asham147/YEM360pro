"use client";
/**
 * YEM360 — Messages: inbox + chat (DM & groups), realtime via socket.io.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, uploadFile, timeAgo, fmtNumber } from "@/lib/api-client";
import { onSocketEvent, emitSocket } from "@/lib/socket";
import type { ConversationDTO, MessageDTO, PublicUser } from "@/lib/types";
import { AvatarX, EmptyState, Spinner, UserRow, VerifiedIcon } from "./ui";
import { Search, Plus, Send, Users, ArrowRight, ImagePlus, Loader2, LogOut, MapPin } from "lucide-react";

export default function MessagesView({ initialConversation }: { initialConversation?: string }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const [convs, setConvs] = useState<ConversationDTO[]>([]);
  const [activeId, setActiveId] = useState<string | null>(initialConversation ?? null);
  const [loading, setLoading] = useState(true);
  const [newOpen, setNewOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await api.get<{ conversations: ConversationDTO[] }>("/api/messages/conversations");
      setConvs(res.conversations);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const off = onSocketEvent("conversation:updated", () => load());
    return off;
  }, [load]);

  const active = convs.find((c) => c.id === activeId) ?? null;

  return (
    <div className="flex h-[calc(100vh-3.5rem)]">
      {/* conversation list */}
      <div className={`w-full md:w-80 border-e flex flex-col ${activeId ? "hidden md:flex" : "flex"}`}>
        <div className="p-3 border-b flex items-center justify-between">
          <h1 className="font-bold">{t("messages", lang)}</h1>
          <Button size="icon" variant="ghost" onClick={() => setNewOpen(true)} aria-label={t("new_message", lang)}>
            <Plus size={18} />
          </Button>
        </div>
        <div className="flex-1 overflow-y-auto yem-scroll">
          {loading ? (
            <div className="py-10 flex justify-center"><Spinner /></div>
          ) : convs.length === 0 ? (
            <EmptyState icon={<Users size={22} />} title={t("no_conversations", lang)} />
          ) : (
            convs.map((c) => (
              <button
                key={c.id}
                onClick={() => setActiveId(c.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 hover:bg-muted text-start ${activeId === c.id ? "bg-accent" : ""}`}
              >
                <AvatarX user={{ name: c.title || "?", avatarUrl: c.avatarUrl }} size={46} ring={false} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate flex items-center gap-1">
                    {c.title || "—"}
                    {c.type === "GROUP" && <Users size={12} className="text-muted-foreground" />}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {c.lastMessage
                      ? `${c.lastMessage.senderId === me?.id ? (lang === "ar" ? "أنت: " : "You: ") : ""}${c.lastMessage.text || t("share", lang)}`
                      : lang === "ar" ? "لا رسائل بعد" : "No messages"}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="text-[10px] text-muted-foreground">{timeAgo(c.lastMessageAt, lang)}</span>
                  {c.unread > 0 && (
                    <span className="min-w-5 h-5 px-1.5 rounded-full bg-primary text-primary-foreground text-[10px] flex items-center justify-center font-bold">
                      {c.unread > 9 ? "9+" : c.unread}
                    </span>
                  )}
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {/* chat area */}
      <div className={`flex-1 ${activeId ? "flex" : "hidden md:flex"} flex-col`}>
        {active ? (
          <ChatWindow
            conv={active}
            onBack={() => {
              setActiveId(null);
              load();
            }}
            onLeft={() => {
              setActiveId(null);
              load();
            }}
            onRead={() => load()}
          />
        ) : (
          <EmptyState icon={<MessageCircleIcon />} title={t("messages", lang)} sub={t("no_conversations", lang)} />
        )}
      </div>

      <NewConversationDialog
        open={newOpen}
        onOpenChange={setNewOpen}
        onCreated={(id) => {
          setNewOpen(false);
          load();
          setActiveId(id);
        }}
      />
    </div>
  );
}

function MessageCircleIcon() {
  return <Send size={22} />;
}

/* ─────────────── chat window ─────────────── */

function ChatWindow({ conv, onBack, onLeft, onRead }: { conv: ConversationDTO; onBack: () => void; onLeft: () => void; onRead: () => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const [messages, setMessages] = useState<MessageDTO[]>([]);
  const [participants, setParticipants] = useState<{ userId: string; role: string; name: string; username: string; avatarUrl?: string | null; lastReadAt: string | null }[]>([]);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [typingUser, setTypingUser] = useState<string | null>(null);
  const [onlineIds, setOnlineIds] = useState<Record<string, boolean>>({});
  const [membersOpen, setMembersOpen] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);
  const typingTimer = useRef<number | null>(null);

  const load = useCallback(async (before?: string) => {
    try {
      const q = before ? `?cursor=${encodeURIComponent(before)}` : "";
      const res = await api.get<{ messages: MessageDTO[]; hasMore: boolean; nextCursor: string | null; participants: typeof participants }>(
        `/api/messages/conversations/${conv.id}${q}`
      );
      setParticipants(res.participants);
      setHasMore(res.hasMore);
      if (before) {
        setMessages((prev) => [...res.messages, ...prev]);
      } else {
        setMessages(res.messages);
        requestAnimationFrame(() => bottomRef.current?.scrollIntoView({ behavior: "auto" }));
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [conv.id]);

  useEffect(() => {
    setLoading(true);
    load();
    api.post(`/api/messages/conversations/${conv.id}/read`).catch(() => null);

    const offNew = onSocketEvent("message:new", (data) => {
      const msg = data as MessageDTO;
      if (msg.conversationId !== conv.id) return;
      setMessages((prev) => (prev.some((m) => m.id === msg.id) ? prev : [...prev, msg]));
      api.post(`/api/messages/conversations/${conv.id}/read`).catch(() => null);
      requestAnimationFrame(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }));
    });
    const offTyping = onSocketEvent("conversation:typing", (data) => {
      const d = data as { conversationId: string; name: string };
      if (d.conversationId !== conv.id) return;
      setTypingUser(d.name);
      window.setTimeout(() => setTypingUser(null), 2500);
    });

    return () => {
      offNew();
      offTyping();
    };
  }, [conv.id, load]);

  // presence for DM partner
  useEffect(() => {
    if (conv.type !== "DIRECT" || !conv.userId) return;
    emitSocket("presence:query", { userIds: [conv.userId] });
    const off = onSocketEvent("presence:results", (data) => {
      setOnlineIds((prev) => ({ ...prev, ...data as Record<string, boolean> }));
    });
    const offUpd = onSocketEvent("presence:update", (data) => {
      const d = data as { userId: string; online: boolean };
      setOnlineIds((prev) => ({ ...prev, [d.userId]: d.online }));
    });
    return () => {
      off();
      offUpd();
    };
  }, [conv.type, conv.userId]);

  async function send() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      const res = await api.post<{ message: MessageDTO }>(`/api/messages/conversations/${conv.id}`, { text: text.trim() });
      setMessages((prev) => (prev.some((m) => m.id === res.message.id) ? prev : [...prev, res.message]));
      setText("");
      requestAnimationFrame(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }));
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function sendImage(file?: File) {
    if (!file) return;
    setBusy(true);
    try {
      const { media } = await uploadFile(file, "message");
      const res = await api.post<{ message: MessageDTO }>(`/api/messages/conversations/${conv.id}`, {
        mediaUrl: media.url,
        mediaType: media.type,
      });
      setMessages((prev) => (prev.some((m) => m.id === res.message.id) ? prev : [...prev, res.message]));
      requestAnimationFrame(() => bottomRef.current?.scrollIntoView({ behavior: "smooth" }));
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  function handleType() {
    if (typingTimer.current) return;
    emitSocket("conversation:typing", { conversationId: conv.id });
    typingTimer.current = window.setTimeout(() => {
      typingTimer.current = null;
    }, 3000);
  }

  async function leave() {
    try {
      await api.del(`/api/messages/conversations/${conv.id}`);
      toast.success(lang === "ar" ? "تمت المغادرة" : "Left");
      onLeft();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  const other = conv.type === "DIRECT" ? participants.find((p) => p.userId !== me?.id) : null;
  const isOnline = conv.userId ? onlineIds[conv.userId] : false;

  return (
    <div className="flex flex-col h-full">
      <header className="h-14 border-b flex items-center gap-3 px-3">
        <button onClick={onBack} className="md:hidden" aria-label="back"><ArrowRight size={20} className="rtl:hidden" /><ArrowRight size={20} className="hidden rtl:block rotate-180" /></button>
        <button onClick={() => setMembersOpen(true)}>
          <AvatarX user={{ name: conv.title || "?", avatarUrl: conv.avatarUrl }} size={38} />
        </button>
        <div className="flex-1 min-w-0" onClick={() => setMembersOpen(true)}>
          <p className="font-semibold text-sm truncate flex items-center gap-1">
            {conv.title}
            {conv.type === "GROUP" && <span className="text-xs text-muted-foreground">· {conv.membersCount} {t("members_count", lang)}</span>}
            {other && isOnline && <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" title={t("online", lang)} />}
          </p>
          {typingUser ? (
            <p className="text-xs text-primary">{typingUser} {t("typing", lang)}</p>
          ) : (
            other && (
              <p className="text-xs text-muted-foreground">
                {isOnline ? t("online", lang) : `${t("last_seen", lang)} ${timeAgo(other.lastReadAt || conv.lastMessageAt, lang)}`}
              </p>
            )
          )}
        </div>
        <Button variant="ghost" size="icon" onClick={leave} aria-label={t("leave_chat", lang)}>
          <LogOut size={17} />
        </Button>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto yem-scroll px-4 py-3">
        {hasMore && (
          <div className="text-center pb-2">
            <Button variant="ghost" size="sm" onClick={() => messages[0] && load(messages[0].createdAt)}>
              {t("load_more", lang)}
            </Button>
          </div>
        )}
        {loading ? (
          <div className="py-8 flex justify-center"><Spinner /></div>
        ) : messages.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-10">
            {lang === "ar" ? "ابدأ المحادثة بتحية 👋" : "Say hi 👋"}
          </p>
        ) : (
          messages.map((m) => {
            const own = m.senderId === me?.id;
            const p = participants.find((x) => x.userId === m.senderId);
            return (
              <div key={m.id} className={`flex mb-2 ${own ? "justify-end" : "justify-start"}`}>
                {!own && conv.type === "GROUP" && <div className="me-1.5 self-end"><AvatarX user={p ?? { name: m.senderId }} size={26} /></div>}
                <div className={`max-w-[75%] px-3.5 py-2 text-sm ${own ? "bubble-own" : "bubble-other"}`}>
                  {conv.type === "GROUP" && !own && (
                    <p className="text-[11px] font-semibold mb-0.5 opacity-80">{p?.name}</p>
                  )}
                  {m.replyTo?.text && (
                    <p className="text-[11px] opacity-75 border-s-2 border-current/40 ps-2 mb-1 truncate">{m.replyTo.text.slice(0, 60)}</p>
                  )}
                  {m.mediaUrl && m.mediaType === "IMAGE" && <img src={m.mediaUrl} alt="attachment" className="max-h-52 rounded-lg mb-1" />}
                  {m.mediaUrl && m.mediaType === "VIDEO" && <video src={m.mediaUrl} controls className="max-h-52 rounded-lg mb-1" />}
                  {m.text}
                  <span className="block text-[10px] opacity-60 text-end">{timeAgo(m.createdAt, lang)}</span>
                </div>
              </div>
            );
          })
        )}
        <div ref={bottomRef} />
      </div>

      <div className="border-t p-2 flex items-center gap-2">
        <button onClick={() => fileRef.current?.click()} className="text-muted-foreground hover:text-primary p-2" aria-label="attach">
          {busy ? <Loader2 size={19} className="animate-spin" /> : <ImagePlus size={19} />}
        </button>
        <input ref={fileRef} type="file" accept="image/*,video/mp4" className="hidden" onChange={(e) => { sendImage(e.target.files?.[0]); e.target.value = ""; }} />
        <input
          className="flex-1 h-10 rounded-full bg-muted px-4 text-sm outline-none focus:ring-1 focus:ring-ring"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && send()}
          onInput={handleType}
          placeholder={t("type_message", lang)}
          maxLength={4000}
        />
        <Button size="icon" className="h-10 w-10 rounded-full shrink-0" onClick={send} disabled={busy || !text.trim()} aria-label={t("send", lang)}>
          <Send size={17} className="scale-x-[-1]" />
        </Button>
      </div>

      {/* members dialog */}
      <Dialog open={membersOpen} onOpenChange={setMembersOpen}>
        <DialogContent className="max-w-xs max-h-80 overflow-y-auto yem-scroll">
          <DialogHeader>
            <DialogTitle>{conv.type === "GROUP" ? `${t("members_count", lang)} (${conv.membersCount})` : conv.title}</DialogTitle>
          </DialogHeader>
          {participants.map((p) => (
            <div key={p.userId} className="flex items-center gap-3 py-1.5">
              <AvatarX user={{ name: p.name, avatarUrl: p.avatarUrl }} size={34} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{p.name}</p>
                <p className="text-xs text-muted-foreground">@{p.username} {p.role !== "MEMBER" ? `· ${p.role === "OWNER" ? (lang === "ar" ? "مالك" : "owner") : (lang === "ar" ? "مسؤول" : "admin")}` : ""}</p>
              </div>
            </div>
          ))}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────── new conversation dialog ─────────────── */

function NewConversationDialog({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (v: boolean) => void; onCreated: (id: string) => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const [tab, setTab] = useState<"dm" | "group">("dm");
  const [q, setQ] = useState("");
  const [users, setUsers] = useState<PublicUser[]>([]);
  const [selected, setSelected] = useState<Record<string, boolean>>({});
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setTab("dm");
    setQ("");
    setSelected({});
    setTitle("");
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const timer = setTimeout(() => {
      api.get<{ users: PublicUser[] }>(`/api/search?q=${encodeURIComponent(q || "a")}`)
        .then((r) => setUsers(r.users.slice(0, 12)))
        .catch(() => null);
    }, 300);
    return () => clearTimeout(timer);
  }, [q, open]);

  async function startDM(userId: string) {
    try {
      const res = await api.post<{ conversationId: string }>("/api/messages/conversations", { type: "DIRECT", userId });
      onCreated(res.conversationId);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function createGroup() {
    const memberIds = Object.entries(selected).filter(([, v]) => v).map(([k]) => k);
    if (!title.trim() || memberIds.length === 0) return;
    setBusy(true);
    try {
      const res = await api.post<{ conversationId: string }>("/api/messages/conversations", {
        type: "GROUP",
        title: title.trim(),
        memberIds,
      });
      onCreated(res.conversationId);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>{tab === "dm" ? t("new_message", lang) : t("new_group", lang)}</DialogTitle>
        </DialogHeader>
        <div className="flex gap-2 mb-2">
          <Button size="sm" variant={tab === "dm" ? "default" : "outline"} onClick={() => setTab("dm")}>{lang === "ar" ? "محادثة" : "Direct"}</Button>
          <Button size="sm" variant={tab === "group" ? "default" : "outline"} onClick={() => setTab("group")}>{lang === "ar" ? "مجموعة" : "Group"}</Button>
        </div>

        {tab === "group" && (
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder={t("group_name", lang)} maxLength={80} className="mb-2" />
        )}
        <div className="relative mb-2">
          <Search size={15} className="absolute start-3 top-2.5 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search_users_ph", lang)} className="ps-9" />
        </div>
        <div className="flex-1 overflow-y-auto yem-scroll -mx-1 px-1">
          {users.map((u) => (
            <div key={u.id} className="flex items-center gap-2">
              <UserRow
                user={u}
                onClick={() => tab === "dm" && startDM(u.id)}
                action={
                  tab === "group" ? (
                    <Checkbox
                      checked={!!selected[u.id]}
                      onCheckedChange={(v) => setSelected((s) => ({ ...s, [u.id]: !!v }))}
                      aria-label={u.name}
                    />
                  ) : undefined
                }
              />
            </div>
          ))}
          {users.length === 0 && <p className="text-sm text-muted-foreground text-center py-6">{t("no_results", lang)}</p>}
        </div>
        {tab === "group" && (
          <Button onClick={createGroup} disabled={busy || !title.trim()} className="mt-2">
            {busy ? "..." : `${t("create", lang)} (${Object.values(selected).filter(Boolean).length})`}
          </Button>
        )}
      </DialogContent>
    </Dialog>
  );
}
