"use client";
/**
 * YEM360 — shared UI primitives: Avatar, UserRow, EmptyState, MediaGrid,
 * ReportDialog, ImageViewer, ConfirmDialog.
 */
import { useState } from "react";
import Image from "next/image";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { BadgeCheck, MapPin, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, uploadFile } from "@/lib/api-client";
import type { PublicUser } from "@/lib/types";

export function AvatarX({
  user,
  size = 40,
  ring = false,
  verified = false,
}: {
  user?: { username?: string; name?: string; avatarUrl?: string | null } | null;
  size?: number;
  ring?: boolean;
  verified?: boolean;
}) {
  const name = user?.name || user?.username || "؟";
  const initials = name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join("");
  const inner = (
    <Avatar style={{ width: size, height: size }}>
      {user?.avatarUrl ? <AvatarImage src={user.avatarUrl} alt={name} /> : null}
      <AvatarFallback
        className="brand-gradient text-white font-semibold"
        style={{ fontSize: Math.max(11, size / 2.6) }}
      >
        {initials}
      </AvatarFallback>
    </Avatar>
  );
  if (!ring && !verified) return inner;
  return (
    <span className="relative inline-flex shrink-0">
      {ring ? <div className="story-ring">{inner}</div> : inner}
      {verified && (
        <span
          className="absolute bottom-0 end-0 rounded-full bg-card border border-border flex items-center justify-center"
          style={{ width: size * 0.42, height: size * 0.42 }}
          aria-label="verified"
        >
          <BadgeCheck className="text-sky-500 fill-sky-500/15" style={{ width: size * 0.32, height: size * 0.32 }} />
        </span>
      )}
    </span>
  );
}

export function VerifiedIcon({ show }: { show: boolean }) {
  if (!show) return null;
  return <BadgeCheck className="inline w-4 h-4 text-gold shrink-0" aria-label="verified" />;
}

export function EmptyState({ icon, title, sub }: { icon: React.ReactNode; title: string; sub?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center gap-3">
      <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/10 to-gold/15 ring-1 ring-gold/25 flex items-center justify-center text-gold">{icon}</div>
      <p className="font-semibold">{title}</p>
      {sub ? <p className="text-sm text-muted-foreground max-w-xs">{sub}</p> : null}
    </div>
  );
}

export function Spinner({ className = "" }: { className?: string }) {
  return <Loader2 className={`animate-spin text-primary ${className}`} size={20} />;
}

/** 1–4 media grid used by PostCard. */
export function MediaGrid({ media, onOpen }: { media: { type: string; url: string }[]; onOpen?: (url: string) => void }) {
  const n = media.length;
  if (!n) return null;
  const cls =
    n === 1 ? "grid-cols-1 max-h-[420px]" : n === 2 ? "grid-cols-2" : n === 3 ? "grid-cols-2 grid-rows-2" : "grid-cols-2";
  return (
    <div className={`grid ${cls} gap-1 rounded-xl overflow-hidden`}>
      {media.slice(0, 4).map((m, i) => (
        <button
          key={i}
          type="button"
          onClick={() => onOpen?.(m.url)}
          className="relative bg-muted overflow-hidden min-h-[120px]"
        >
          {m.type === "VIDEO" ? (
            <video src={m.url} className="w-full h-full object-cover" preload="metadata" muted playsInline controls={n === 1} />
          ) : (
            <img src={m.url} alt={`media-${i}`} className="w-full h-full object-cover" loading="lazy" />
          )}
        </button>
      ))}
    </div>
  );
}

export function ImageViewer({ url, onClose }: { url: string | null; onClose: () => void }) {
  if (!url) return null;
  return (
    <div className="fixed inset-0 z-[90] bg-black/90 flex items-center justify-center p-4 cursor-zoom-out" onClick={onClose}>
      <img src={url} alt="preview" className="max-w-full max-h-full object-contain rounded-lg" />
      <button className="absolute top-4 end-4 text-white/80 hover:text-white text-sm" onClick={onClose}>
        ✕
      </button>
    </div>
  );
}

export function ConfirmDialog({
  open,
  onOpenChange,
  title,
  description,
  onConfirm,
  destructive = true,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  description?: string;
  onConfirm: () => void;
  destructive?: boolean;
}) {
  const lang = useApp((s) => s.lang);
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xs">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        {description ? <p className="text-sm text-muted-foreground">{description}</p> : null}
        <div className="flex gap-2 justify-end">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            {t("cancel", lang)}
          </Button>
          <Button
            variant={destructive ? "destructive" : "default"}
            onClick={() => {
              onOpenChange(false);
              onConfirm();
            }}
          >
            {t("confirm", lang)}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

const REASONS = ["SPAM", "HARASSMENT", "HATE_SPEECH", "VIOLENCE", "NUDITY", "MISINFORMATION", "OTHER"];

export function ReportDialog({
  open,
  onOpenChange,
  targetType,
  targetId,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  targetType: string;
  targetId: string;
}) {
  const lang = useApp((s) => s.lang);
  const [reason, setReason] = useState("SPAM");
  const [details, setDetails] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    try {
      await api.post("/api/reports", { targetType, targetId, reason, details: details || undefined });
      toast.success(t("report_sent", lang));
      onOpenChange(false);
      setDetails("");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>{t("report_title", lang)}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <p className="text-sm mb-1.5">{t("report_reason", lang)}</p>
            <Select value={reason} onValueChange={setReason}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {REASONS.map((r) => (
                  <SelectItem key={r} value={r}>{t(`reason_${r}`, lang)}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Textarea
            value={details}
            onChange={(e) => setDetails(e.target.value)}
            placeholder={t("report_details", lang)}
            rows={2}
            maxLength={500}
          />
          <Button onClick={submit} disabled={busy} className="w-full">
            {busy ? <Spinner className="w-4 h-4" /> : t("submit_report", lang)}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** User list row with a primary action (follow/friend/message). */
export function UserRow({
  user,
  action,
  subtitle,
  onClick,
}: {
  user: PublicUser;
  action?: React.ReactNode;
  subtitle?: React.ReactNode;
  onClick?: () => void;
}) {
  return (
    <div className="flex items-center gap-3 py-2.5 px-1">
      <button onClick={onClick} className="shrink-0"><AvatarX user={user} size={44} /></button>
      <button onClick={onClick} className="flex-1 min-w-0 text-start">
        <p className="font-semibold text-sm truncate flex items-center gap-1">
          {user.name} <VerifiedIcon show={user.isVerified} />
        </p>
        <p className="text-xs text-muted-foreground truncate">
          @{user.username}
          {subtitle ? <> · {subtitle}</> : null}
        </p>
      </button>
      {action}
    </div>
  );
}

/** Single image picker row (avatar / cover / product images...). */
export function ImagePickButton({
  kind,
  onUploaded,
  label,
  accept = "image/*",
  className = "",
}: {
  kind: string;
  onUploaded: (url: string) => void;
  label: string;
  accept?: string;
  className?: string;
}) {
  const lang = useApp((s) => s.lang);
  const [busy, setBusy] = useState(false);
  const [ref, setRef] = useState<HTMLInputElement | null>(null);

  async function handle(file?: File) {
    if (!file) return;
    setBusy(true);
    try {
      const { media } = await uploadFile(file, kind);
      onUploaded(media.url);
    } catch (e) {
      toast.error((e as Error).message || t("error_generic", lang));
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <Button type="button" variant="outline" size="sm" className={className} onClick={() => ref?.click()} disabled={busy}>
        {busy ? <Spinner className="w-4 h-4" /> : null}
        {label}
      </Button>
      <input
        ref={setRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={(e) => {
          handle(e.target.files?.[0]);
          e.target.value = "";
        }}
      />
    </>
  );
}

export function StatusBadge({ status, lang }: { status: string; lang: "ar" | "en" }) {
  const variant =
    status === "ACTIVE" || status === "ACCEPTED" || status === "DELIVERED" || status === "AVAILABLE"
      ? "default"
      : status === "PENDING"
        ? "secondary"
        : status === "REJECTED" || status === "CANCELLED" || status === "SUSPENDED"
          ? "destructive"
          : "outline";
  return <Badge variant={variant}>{t(`status_${status}`, lang)}</Badge>;
}
