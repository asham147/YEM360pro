"use client";
/**
 * YEM360 — client providers: theme (next-themes) + session bootstrap + socket + dir sync.
 */
import { useEffect } from "react";
import { ThemeProvider } from "next-themes";
import { Toaster } from "sonner";
import { useApp } from "@/lib/store";
import { api } from "@/lib/api-client";
import { connectSocket, onSocketEvent, disconnectSocket } from "@/lib/socket";
import type { MeResponse } from "@/lib/types";

export function Providers({ children }: { children: React.ReactNode }) {
  const { loaded, setSession, setLang, setCounts, lang, user, setSocketReady } = useApp();

  // restore language + sync direction
  useEffect(() => {
    let saved: string | null = null;
    try {
      saved = localStorage.getItem("yem360_lang");
    } catch {}
    setLang(saved === "en" ? "en" : "ar");
  }, [setLang]);

  // bootstrap session
  useEffect(() => {
    let alive = true;
    api.get<MeResponse>("/api/auth/me")
      .then((d) => {
        if (!alive) return;
        setSession({ user: d.user, settings: d.settings ?? null, privacy: d.privacy ?? null, counts: d.counts ?? { unreadNotifications: 0, unreadMessages: 0 } });
      })
      .catch(() => {
        if (!alive) return;
        setSession({ user: null, settings: null, privacy: null });
      });
    return () => {
      alive = false;
    };
  }, [setSession]);

  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
      <SessionSocket />
      {loaded ? children : (
        <div className="min-h-screen flex flex-col items-center justify-center gap-5 relative">
          <div className="yem-aurora" aria-hidden />
          <div className="relative">
            <div className="absolute inset-0 -m-3 rounded-full border border-gold/30 soft-pulse" aria-hidden />
            <LogoMark className="w-16 h-16 logo-aura" />
          </div>
          <p className="text-muted-foreground text-sm">{lang === "ar" ? "نجهّز عالمك الرقمي..." : "Preparing your digital world..."}</p>
          <div className="w-36 h-1 rounded-full bg-muted overflow-hidden shimmer" aria-hidden />
        </div>
      )}
      <Toaster position="top-center" richColors dir={lang === "ar" ? "rtl" : "ltr"} />
    </ThemeProvider>
  );
}

/** Session bootstrap + realtime wiring (needs to sit inside ThemeProvider). */
function SessionSocket() {
  const { user, setSocketReady, setCounts } = useApp();

  useEffect(() => {
    if (!user) {
      disconnectSocket();
      setSocketReady(false);
      return;
    }
    // The auth cookie is httpOnly; obtain a socket token via dedicated endpoint.
    fetch("/api/auth/realtime-token", { credentials: "include" })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (!d?.token) return;
        const s = connectSocket(d.token);
        s.on("auth:ok", () => setSocketReady(true));
        s.on("notification:new", (data: unknown) => {
          const { notification } = data as { notification: { isRead: boolean } };
          if (notification && !notification.isRead) {
            useApp.getState().setCounts({ unreadNotifications: useApp.getState().counts.unreadNotifications + 1 });
          }
        });
        onSocketEvent("message:new", () => {
          useApp.getState().setCounts({ unreadMessages: useApp.getState().counts.unreadMessages + 1 });
        });
      })
      .catch(() => null);
    // refresh badge counters periodically as a safety net
    const iv = setInterval(() => {
      api.get<MeResponse>("/api/auth/me").then((d) => setCounts(d.counts ?? { unreadNotifications: 0, unreadMessages: 0 })).catch(() => null);
    }, 45000);
    return () => {
      clearInterval(iv);
    };
  }, [user, setSocketReady, setCounts]);

  return null;
}

export function LogoMark({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 48 48" fill="none" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="yem-g" x1="4" y1="4" x2="44" y2="44">
          <stop offset="0%" stopColor="#1B2A52" />
          <stop offset="55%" stopColor="#27407E" />
          <stop offset="100%" stopColor="#C9A227" />
        </linearGradient>
        <linearGradient id="yem-core" x1="12" y1="12" x2="36" y2="36">
          <stop offset="0%" stopColor="#1B2A52" />
          <stop offset="100%" stopColor="#34497F" />
        </linearGradient>
        <linearGradient id="yem-check" x1="18" y1="20" x2="30" y2="30">
          <stop offset="0%" stopColor="#E9CE7A" />
          <stop offset="100%" stopColor="#C9A227" />
        </linearGradient>
      </defs>
      <g className="logo-ring-rot">
        <circle cx="24" cy="24" r="20" stroke="url(#yem-g)" strokeWidth="3.5" strokeDasharray="95 31" strokeLinecap="round" />
      </g>
      <circle cx="24" cy="24" r="12" fill="url(#yem-core)" />
      <path d="M18.5 20.5 24 30l5.5-9.5" stroke="url(#yem-check)" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    </svg>
  );
}
