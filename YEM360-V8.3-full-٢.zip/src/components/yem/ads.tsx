"use client";
/**
 * YEM360 — Advertiser campaigns + ads creation.
 */
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, fmtNumber } from "@/lib/api-client";
import type { AdDTO } from "@/lib/types";
import { EmptyState, Spinner, StatusBadge, ImagePickButton } from "./ui";
import { Megaphone, Plus, MousePointerClick, Eye, Loader2, Trash2, Pause, Play } from "lucide-react";

export default function AdsView() {
  const lang = useApp((s) => s.lang);
  const [ads, setAds] = useState<AdDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await api.get<{ ads: AdDTO[] }>("/api/ads");
      setAds(res.ads);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function action(ad: AdDTO, act: "PAUSE" | "ACTIVATE" | "DELETE") {
    try {
      await api.patch("/api/ads", { id: ad.id, action: act });
      load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-3 py-4">
      <div className="flex items-center justify-between mb-3">
        <h1 className="text-xl font-bold flex items-center gap-2"><Megaphone size={20} className="text-primary" /> {t("ads_campaigns", lang)}</h1>
        <Button size="sm" onClick={() => setCreateOpen(true)}><Plus size={15} /> {t("create_ad", lang)}</Button>
      </div>
      <p className="text-xs text-muted-foreground mb-4">{t("ads_hint", lang)}</p>

      {loading ? (
        <div className="py-12 flex justify-center"><Spinner /></div>
      ) : ads.length === 0 ? (
        <EmptyState icon={<Megaphone size={22} />} title={t("ads_campaigns", lang)} sub={t("ads_hint", lang)} />
      ) : (
        <div className="space-y-3">
          {ads.map((ad) => (
            <div key={ad.id} className="v8-card p-4">
              <div className="flex items-start gap-3">
                {ad.imageUrl ? (
                  <img src={ad.imageUrl} alt={ad.title} className="w-20 h-20 rounded-xl object-cover shrink-0" />
                ) : (
                  <div className="w-20 h-20 rounded-xl brand-gradient shrink-0 flex items-center justify-center text-white"><Megaphone size={24} /></div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-sm">{ad.title}</p>
                    <StatusBadge status={ad.status || "PENDING"} lang={lang} />
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2-custom">{ad.body}</p>
                  <div className="flex gap-3 mt-2 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Eye size={12} /> {fmtNumber(ad.impressionCount || 0)} {t("impressions", lang)}</span>
                    <span className="flex items-center gap-1"><MousePointerClick size={12} /> {fmtNumber(ad.clickCount || 0)} {t("clicks", lang)}</span>
                    <span>{t("ctr", lang)}: {ad.ctr ?? 0}%</span>
                    {ad.budget ? <span>{t("ad_budget", lang)}: {fmtNumber(ad.budget)}</span> : null}
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-3">
                {(ad.status === "ACTIVE") && (
                  <Button size="sm" variant="outline" onClick={() => action(ad, "PAUSE")}><Pause size={13} /> {t("status_PAUSED", lang)}</Button>
                )}
                {(ad.status === "PAUSED") && (
                  <Button size="sm" variant="outline" onClick={() => action(ad, "ACTIVATE")}><Play size={13} /> {t("status_ACTIVE", lang)}</Button>
                )}
                <Button size="sm" variant="destructive" onClick={() => action(ad, "DELETE")}><Trash2 size={13} /> {t("delete", lang)}</Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <AdCreator open={createOpen} onOpenChange={setCreateOpen} onCreated={load} />
    </div>
  );
}

function AdCreator({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (v: boolean) => void; onCreated: () => void }) {
  const lang = useApp((s) => s.lang);
  const [form, setForm] = useState({ title: "", body: "", targetUrl: "", budget: "", targetGender: "ALL", targetMinAge: "", targetMaxAge: "" });
  const [imageUrl, setImageUrl] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    try {
      await api.post("/api/ads", {
        title: form.title,
        body: form.body,
        targetUrl: form.targetUrl,
        imageUrl: imageUrl || undefined,
        budget: Number(form.budget) || 0,
        targetGender: form.targetGender,
        targetMinAge: form.targetMinAge ? Number(form.targetMinAge) : undefined,
        targetMaxAge: form.targetMaxAge ? Number(form.targetMaxAge) : undefined,
      });
      toast.success(lang === "ar" ? "أُرسلت الحملة للمراجعة" : "Campaign submitted for review");
      setForm({ title: "", body: "", targetUrl: "", budget: "", targetGender: "ALL", targetMinAge: "", targetMaxAge: "" });
      setImageUrl("");
      onOpenChange(false);
      onCreated();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto yem-scroll">
        <DialogHeader><DialogTitle>{t("create_ad", lang)}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder={t("ad_title", lang)} maxLength={80} />
          <Textarea value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} placeholder={t("ad_body", lang)} rows={2} maxLength={300} />
          <Input dir="ltr" value={form.targetUrl} onChange={(e) => setForm({ ...form, targetUrl: e.target.value })} placeholder={t("ad_url", lang)} maxLength={300} />
          <Input type="number" min={0} value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} placeholder={t("ad_budget", lang)} />
          <div className="grid grid-cols-3 gap-2">
            <Select value={form.targetGender} onValueChange={(v) => setForm({ ...form, targetGender: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">{t("everyone", lang)}</SelectItem>
                <SelectItem value="MALE">{lang === "ar" ? "ذكور" : "Male"}</SelectItem>
                <SelectItem value="FEMALE">{lang === "ar" ? "إناث" : "Female"}</SelectItem>
              </SelectContent>
            </Select>
            <Input type="number" min={13} value={form.targetMinAge} onChange={(e) => setForm({ ...form, targetMinAge: e.target.value })} placeholder="13+" />
            <Input type="number" min={13} value={form.targetMaxAge} onChange={(e) => setForm({ ...form, targetMaxAge: e.target.value })} placeholder="65" />
          </div>
          <div className="flex items-center gap-2">
            {imageUrl && <img src={imageUrl} alt="ad" className="w-14 h-14 rounded-lg object-cover" />}
            <ImagePickButton kind="ad" label={t("add_photos", lang)} onUploaded={setImageUrl} />
          </div>
          <Button onClick={submit} disabled={busy || !form.title || !form.body || !form.targetUrl} className="w-full">
            {busy ? <Loader2 size={15} className="animate-spin" /> : t("create_ad", lang)}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
