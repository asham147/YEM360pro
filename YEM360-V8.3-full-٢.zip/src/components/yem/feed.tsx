"use client";
/**
 * YEM360 — Feed: hero banner, composer, post card, comments, sponsored ads, pagination.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, uploadFile, timeAgo, fmtNumber } from "@/lib/api-client";
import { absoluteUrl, shareLink } from "@/lib/share";
import type { PostDTO, CommentDTO, AdDTO } from "@/lib/types";
import { AvatarX, MediaGrid, Spinner, EmptyState, ImageViewer, ReportDialog, ConfirmDialog, UserRow } from "./ui";
import { HeroBanner } from "./hero-banner";
import {
  Heart, MessageCircle, Repeat2, Bookmark, MoreHorizontal, MapPin, Globe, UsersRound, Lock, Share2,
  ImagePlus, Loader2, Send, Trash2, Pencil, Flag, Link2, BookmarkX, Megaphone, ExternalLink, Repeat,
  Feather, Sparkles, Crown, BadgeCheck, Smile,
} from "lucide-react";
import type { ViewRoute } from "@/lib/types";

/* ─────────────── footer ornament (spec §5 "المساحة السفلية") ─────────────── */

export function FeedOrnament() {
  return (
    <div className="feed-ornament" aria-hidden>
      <span className="orn-line" />
      <svg width="44" height="18" viewBox="0 0 44 18" className="orn-glyph">
        {/* geometric blue+gold motif: interlocking diamonds */}
        <g fill="none" strokeWidth="1.6">
          <rect x="4" y="4" width="10" height="10" transform="rotate(45 9 9)" fill="var(--gold)" opacity="0.9" stroke="none" />
          <rect x="17" y="4" width="10" height="10" transform="rotate(45 22 9)" stroke="currentColor" />
          <rect x="30" y="4" width="10" height="10" transform="rotate(45 35 9)" fill="var(--primary)" opacity="0.85" stroke="none" />
        </g>
      </svg>
      <span className="orn-line" />
    </div>
  );
}

/* ─────────────── content renderer: hashtags / mentions ─────────────── */

function ContentText({ content, onTag, onUser }: { content: string; onTag: (name: string) => void; onUser: (username: string) => void }) {
  const parts = content.split(/(#[\p{L}\p{N}_]{2,40}|@[a-zA-Z0-9_]{3,20})/gu);
  return (
    <p className="whitespace-pre-wrap break-words text-[15px] leading-relaxed">
      {parts.map((part, i) => {
        if (part.startsWith("#") && part.length > 1) {
          return (
            <span key={i} className="hashtag" onClick={() => onTag(part.slice(1))}>
              {part}
            </span>
          );
        }
        if (part.startsWith("@") && part.length > 1) {
          return (
            <span key={i} className="hashtag" onClick={() => onUser(part.slice(1))}>
              {part}
            </span>
          );
        }
        return <span key={i}>{part}</span>;
      })}
    </p>
  );
}

/* ─────────────── comments ─────────────── */

function CommentItem({
  c,
  postId,
  target,
  onAdded,
}: {
  c: CommentDTO;
  postId: string;
  target: "post" | "reel";
  onAdded: () => void;
}) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const navigate = useApp((s) => s.navigate);
  const [replyOpen, setReplyOpen] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [liked, setLiked] = useState(c.likedByMe);
  const [likes, setLikes] = useState(c.likeCount);
  const isStaff = me?.role === "ADMIN" || me?.role === "MODERATOR";
  const canDelete = c.author.id === me?.id || isStaff;

  async function toggleLike() {
    try {
      const res = liked
        ? await api.del<{ likeCount: number }>(`/api/comments/${c.id}/like`)
        : await api.post<{ likeCount: number }>(`/api/comments/${c.id}/like`);
      setLiked(!liked);
      setLikes(res.likeCount);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function sendReply() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      // reel replies must hit the reels comments endpoint, not posts
      const path = target === "post" ? `/api/posts/${postId}/comments` : `/api/reels/${postId}/comments`;
      await api.post(path, { text: text.trim(), parentId: c.id, target });
      setText("");
      setReplyOpen(false);
      onAdded();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    try {
      await api.del(`/api/comments/${c.id}`);
      onAdded();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div className="flex gap-2.5 py-2">
      <button onClick={() => navigate({ name: "profile", param: c.author.username })}>
        <AvatarX user={c.author} size={34} />
      </button>
      <div className="flex-1 min-w-0">
        <div className="bg-muted rounded-2xl rounded-ss-md px-3.5 py-2.5 inline-block max-w-full">
          <p className="text-sm font-semibold flex items-center gap-1">
            {c.author.name}
            <span className="text-xs text-muted-foreground font-normal">@{c.author.username}</span>
          </p>
          <ContentText content={c.text} onTag={(n) => navigate({ name: "tag", param: n })} onUser={(u) => navigate({ name: "profile", param: u })} />
        </div>
        <div className="flex items-center gap-3 mt-1 px-1 text-xs text-muted-foreground">
          <span>{timeAgo(c.createdAt, lang)}</span>
          <button onClick={toggleLike} className={`flex items-center gap-1 hover:text-primary ${liked ? "text-primary" : ""}`}>
            <Heart size={12} className={liked ? "fill-primary" : ""} /> {likes > 0 ? likes : ""}
          </button>
          <button onClick={() => setReplyOpen(!replyOpen)}>{t("comment", lang)}</button>
          {canDelete && (
            <button onClick={remove} className="hover:text-destructive">
              <Trash2 size={12} />
            </button>
          )}
        </div>

        {replyOpen && (
          <div className="flex gap-2 mt-2">
            <input
              className="flex-1 h-8 text-sm rounded-full bg-muted px-3 outline-none focus:ring-1 focus:ring-ring"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={t("reply_ph", lang)}
              maxLength={2000}
            />
            <Button size="icon" className="h-8 w-8" onClick={sendReply} disabled={busy}>
              {busy ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
            </Button>
          </div>
        )}

        {c.replies.length > 0 && (
          <div className="ms-6 mt-1">
            {c.replies.map((r) => (
              <CommentItem key={r.id} c={r} postId={postId} target={target} onAdded={onAdded} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function CommentsSection({
  postId,
  target = "post",
  onCountChange,
}: {
  postId: string;
  target?: "post" | "reel";
  onCountChange?: (n: number) => void;
}) {
  const lang = useApp((s) => s.lang);
  const [comments, setComments] = useState<CommentDTO[]>([]);
  const [loading, setLoading] = useState(false);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const path = target === "post" ? `/api/posts/${postId}/comments` : `/api/reels/${postId}/comments`;
      const res = await api.get<{ comments: CommentDTO[] }>(path);
      setComments(res.comments);
      const total = res.comments.reduce((acc, c) => acc + 1 + c.replies.length, 0);
      onCountChange?.(total);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [postId, target, onCountChange]);

  useEffect(() => {
    load();
  }, [load]);

  async function send() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      const path = target === "post" ? `/api/posts/${postId}/comments` : `/api/reels/${postId}/comments`;
      await api.post(path, { text: text.trim(), target });
      setText("");
      await load();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="border-t pt-2 mt-2">
      {loading && comments.length === 0 ? (
        <p className="text-xs text-muted-foreground py-3 text-center">{t("loading", lang)}</p>
      ) : null}
      {comments.map((c) => (
        <CommentItem key={c.id} c={c} postId={postId} target={target} onAdded={load} />
      ))}
      <div className="flex items-center gap-2 py-2 sticky bottom-0 bg-background">
        <input
          className="flex-1 h-9 rounded-full bg-muted px-4 text-sm outline-none focus:ring-1 focus:ring-ring"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder={t("add_comment_ph", lang)}
          maxLength={2000}
          onKeyDown={(e) => e.key === "Enter" && send()}
        />
        <Button size="icon" className="h-9 w-9 shrink-0" onClick={send} disabled={busy || !text.trim()}>
          {busy ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
        </Button>
      </div>
    </div>
  );
}

/* ─────────────── post card ─────────────── */

export function PostCard({ post, onDeleted }: { post: PostDTO; onDeleted?: (id: string) => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const navigate = useApp((s) => s.navigate);
  const [liked, setLiked] = useState(post.likedByMe);
  const [likeCount, setLikeCount] = useState(post.likeCount);
  const [saved, setSaved] = useState(post.savedByMe);
  const [reposted, setReposted] = useState(post.repostedByMe);
  const [repostCount, setRepostCount] = useState(post.repostCount);
  const [showComments, setShowComments] = useState(false);
  const [commentCount, setCommentCount] = useState(post.commentCount);
  const [reportOpen, setReportOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [viewImage, setViewImage] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState(post.content);
  const [busy, setBusy] = useState(false);

  const isOwn = post.author.id === me?.id;
  const isStaff = me?.role === "ADMIN" || me?.role === "MODERATOR";

  const privacyIcon =
    post.privacy === "PUBLIC" ? <Globe size={13} /> : post.privacy === "FOLLOWERS" ? <UsersRound size={13} /> : <Lock size={13} />;

  async function toggleLike() {
    setLiked(!liked);
    setLikeCount((c) => c + (liked ? -1 : 1));
    try {
      const res = liked
        ? await api.del<{ likeCount: number }>(`/api/posts/${post.id}/like`)
        : await api.post<{ likeCount: number }>(`/api/posts/${post.id}/like`);
      setLikeCount(res.likeCount);
    } catch (e) {
      setLiked(post.likedByMe);
      setLikeCount(post.likeCount);
      toast.error((e as Error).message);
    }
  }

  /** share the post via native sheet; falls back to copying a link. */
  async function sharePost() {
    const url = target.media.length > 0
      ? absoluteUrl(target.media[0].url)
      : absoluteUrl("/");
    const excerpt = target.content ? (target.content.length > 180 ? target.content.slice(0, 180) + "…" : target.content) : undefined;
    try {
      await shareLink({
        title: `@${target.author.username} · YEM360`,
        text: excerpt,
        url,
      }, lang);
    } catch (e) {
      if ((e as DOMException)?.name !== "AbortError") toast.error((e as Error).message);
    }
  }

  async function toggleSave() {
    try {
      if (saved) {
        await api.del(`/api/posts/${post.id}/save`);
        setSaved(false);
        toast(lang === "ar" ? "تمت الإزالة من المحفوظات" : "Removed from saved");
      } else {
        await api.post(`/api/posts/${post.id}/save`);
        setSaved(true);
        toast.success(lang === "ar" ? "تم الحفظ" : "Saved");
      }
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function toggleRepost() {
    try {
      if (reposted) {
        await api.del(`/api/posts/${post.id}/repost`);
        setReposted(false);
        setRepostCount((c) => c - 1);
      } else {
        await api.post(`/api/posts/${post.id}/repost`);
        setReposted(true);
        setRepostCount((c) => c + 1);
        toast.success(lang === "ar" ? "أعدت نشر المنشور" : "Reposted");
      }
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function removePost() {
    try {
      await api.del(`/api/posts/${post.id}`);
      toast.success(lang === "ar" ? "تم حذف المنشور" : "Post deleted");
      onDeleted?.(post.id);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function saveEdit() {
    setBusy(true);
    try {
      await api.patch(`/api/posts/${post.id}`, { content: editText, privacy: post.privacy });
      post.content = editText;
      setEditing(false);
      toast.success(lang === "ar" ? "تم التحديث" : "Updated");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  const inner = post.repostOf;
  const target = inner ?? post;

  return (
    <article className="neon-card neon-card-gold p-4 mb-3">
      {/* repost attribution */}
      {inner && (
        <p className="text-xs text-muted-foreground flex items-center gap-1.5 mb-2">
          <Repeat size={12} />
          <button className="font-semibold text-foreground hover:underline" onClick={() => navigate({ name: "profile", param: post.author.username })}>
            {post.author.name}
          </button>
          {t("reposted", lang)}
        </p>
      )}

      <header className="flex items-center gap-3">
        <button onClick={() => navigate({ name: "profile", param: target.author.username })}>
          <AvatarX user={target.author} size={42} verified={target.author.isVerified} />
        </button>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm flex items-center gap-1 flex-wrap">
            <button className="hover:underline" onClick={() => navigate({ name: "profile", param: target.author.username })}>
              {target.author.name}
            </button>
            {target.author.isVerified && <BadgeCheck size={14} className="text-sky-500 fill-sky-500/15" aria-label="verified" />}
            {target.author.accountType !== "PERSONAL" && (
              <span className="text-[10px] bg-primary/10 text-primary rounded-full px-1.5 py-0.5">{t("pro_account", lang)}</span>
            )}
          </p>
          <p className="text-xs text-muted-foreground flex items-center gap-1.5 flex-wrap">
            @{target.author.username} · {timeAgo(target.createdAt, lang)} · {privacyIcon}
            {target.viewCount > 0 && (
              <span className="inline-flex items-center gap-1">· {fmtNumber(target.viewCount)} {t("views", lang)}</span>
            )}
          </p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="more">
              <MoreHorizontal size={18} />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuItem onClick={toggleSave}>
              {saved ? <BookmarkX size={15} /> : <Bookmark size={15} />}
              {saved ? t("saved", lang) : t("save", lang)}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={toggleRepost}>
              <Repeat2 size={15} /> {reposted ? (lang === "ar" ? "إلغاء إعادة النشر" : "Undo repost") : t("repost", lang)}
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={() => {
                navigator.clipboard?.writeText(`${window.location.origin}/?post=${post.id}`).catch(() => null);
                toast.success(t("link_copied", lang));
              }}
            >
              <Link2 size={15} /> {t("copy_link", lang)}
            </DropdownMenuItem>
            {isOwn && !inner && (
              <DropdownMenuItem onClick={() => setEditing(true)}>
                <Pencil size={15} /> {t("edit_post", lang)}
              </DropdownMenuItem>
            )}
            {(isOwn || isStaff) && (
              <DropdownMenuItem className="text-destructive" onClick={() => setDeleteOpen(true)}>
                <Trash2 size={15} /> {t("delete_post", lang)}
              </DropdownMenuItem>
            )}
            {!isOwn && (
              <DropdownMenuItem onClick={() => setReportOpen(true)}>
                <Flag size={15} /> {t("report", lang)}
              </DropdownMenuItem>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </header>

      {editing ? (
        <div className="mt-3 space-y-2">
          <Textarea value={editText} onChange={(e) => setEditText(e.target.value)} rows={3} maxLength={5000} />
          <div className="flex gap-2 justify-end">
            <Button variant="ghost" size="sm" onClick={() => setEditing(false)}>{t("cancel", lang)}</Button>
            <Button size="sm" onClick={saveEdit} disabled={busy}>{busy ? "..." : t("save_changes", lang)}</Button>
          </div>
        </div>
      ) : (
        target.content && (
          <div className="mt-2.5">
            <ContentText
              content={target.content}
              onTag={(n) => navigate({ name: "tag", param: n })}
              onUser={(u) => navigate({ name: "profile", param: u })}
            />
          </div>
        )
      )}

      {target.media.length > 0 && (
        <div className="mt-3">
          <MediaGrid media={target.media} onOpen={setViewImage} />
        </div>
      )}

      {target.locationName && (
        <p className="mt-2 text-xs text-muted-foreground flex items-center gap-1">
          <MapPin size={12} /> {target.locationName}
        </p>
      )}

      {/* actions — 4 luminous pills (spec §5-ثالثاً: إعجاب · إعادة نشر · تعليق · مشاركة) */}
      <div className="flex items-center justify-between gap-1.5 mt-3 pt-2.5 border-t border-border/60">
        <button onClick={toggleLike} className={`pill-soft ${liked ? "!text-destructive !border-destructive/45 !bg-destructive/10" : ""}`}>
          <Heart size={15} className={liked ? "fill-destructive" : ""} />
          <span className="hidden sm:inline">{t("like", lang)}</span>
          {likeCount > 0 && <span className="text-[10px] font-bold tabular-nums">{fmtNumber(likeCount)}</span>}
        </button>
        <button onClick={toggleRepost} className={`pill-soft ${reposted ? "!text-gold !border-gold/45 !bg-gold/10" : ""}`}>
          <Repeat2 size={15} />
          <span className="hidden sm:inline">{t("repost", lang)}</span>
          {repostCount > 0 && <span className="text-[10px] font-bold tabular-nums">{fmtNumber(repostCount)}</span>}
        </button>
        <button onClick={() => setShowComments(!showComments)} className="pill-soft">
          <MessageCircle size={15} />
          <span className="hidden sm:inline">{t("comment", lang)}</span>
          {commentCount > 0 && <span className="text-[10px] font-bold tabular-nums">{fmtNumber(commentCount)}</span>}
        </button>
        <button onClick={sharePost} className="pill-soft">
          <Share2 size={15} />
          <span className="hidden sm:inline">{t("share", lang)}</span>
        </button>
      </div>

      {showComments && <CommentsSection postId={target.id} onCountChange={setCommentCount} />}

      <ImageViewer url={viewImage} onClose={() => setViewImage(null)} />
      <ReportDialog open={reportOpen} onOpenChange={setReportOpen} targetType="POST" targetId={post.id} />
      <ConfirmDialog
        open={deleteOpen}
        onOpenChange={setDeleteOpen}
        title={t("delete_confirm", lang)}
        onConfirm={removePost}
      />
    </article>
  );
}

/* ─────────────── sponsored ad card ─────────────── */

export function AdCard({ ad, onImpressionDone }: { ad: AdDTO; onImpressionDone?: () => void }) {
  const lang = useApp((s) => s.lang);
  async function click() {
    try {
      const res = await api.post<{ targetUrl: string }>(`/api/ads/${ad.id}/click`);
      window.open(res.targetUrl, "_blank", "noopener");
    } catch {
      window.open(ad.targetUrl, "_blank", "noopener");
    }
  }
  return (
    <article className="neon-card p-4 mb-3">
      <p className="text-xs text-muted-foreground flex items-center gap-1.5 mb-2">
        <Megaphone size={13} /> {t("sponsored", lang)}
      </p>
      <div className="flex items-start gap-3">
        {ad.imageUrl ? (
          <img src={ad.imageUrl} alt={ad.title} className="w-24 h-24 rounded-xl object-cover shrink-0" />
        ) : (
          <div className="w-24 h-24 rounded-xl brand-gradient shrink-0 flex items-center justify-center text-white"><Megaphone size={28} /></div>
        )}
        <div className="min-w-0 flex-1">
          <p className="font-semibold text-sm">{ad.title}</p>
          <p className="text-sm text-muted-foreground line-clamp-2-custom">{ad.body}</p>
          <Button size="sm" className="mt-2 gap-1.5" onClick={click}>
            {t("learn_more", lang)} <ExternalLink size={13} />
          </Button>
        </div>
      </div>
    </article>
  );
}

/* ─────────────── composer ─────────────── */

export function Composer({ onPosted }: { onPosted: (p: PostDTO) => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const [content, setContent] = useState("");
  const [media, setMedia] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);
  const [privacy, setPrivacy] = useState("PUBLIC");
  const [locName, setLocName] = useState("");
  const [showLoc, setShowLoc] = useState(false);
  const [showEmoji, setShowEmoji] = useState(false);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement | null>(null);

  // spec §4: mood/emoji tool — quick chips appended to the composer text
  const MOOD_EMOJIS = ["😀", "😂", "🥳", "😍", "🤩", "😎", "🤔", "😴", "👍", "🙌", "👏", "🔥", "❤️", "💛", "💙", "✨", "🎉", "🌅", "☕", "📍", "🎮", "📚", "🎧", "💡"];

  function appendEmoji(e: string) {
    setContent((prev) => (prev + (prev && !prev.endsWith(" ") ? " " : "") + e + " ").slice(0, 5000));
  }

  async function pickFiles(files: FileList | null) {
    if (!files?.length) return;
    setUploading(true);
    try {
      for (const f of Array.from(files).slice(0, 4 - media.length)) {
        const { media: m } = await uploadFile(f, "post");
        setMedia((prev) => [...prev, m.url]);
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setUploading(false);
    }
  }

  function useMyLocation() {
    if (!navigator.geolocation) {
      toast.error(lang === "ar" ? "الموقع غير مدعوم" : "Geolocation unsupported");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocName((prev) => prev || `${pos.coords.latitude.toFixed(3)}, ${pos.coords.longitude.toFixed(3)}`);
        toast.success(lang === "ar" ? "تم تحديد الموقع" : "Location set");
      },
      () => toast.error(lang === "ar" ? "تعذر تحديد الموقع" : "Could not get location"),
      { timeout: 8000 }
    );
  }

  async function submit() {
    if (!content.trim() && media.length === 0) return;
    setBusy(true);
    try {
      const res = await api.post<{ post: PostDTO }>("/api/posts", {
        content: content.trim(),
        privacy,
        mediaUrls: media,
        locationName: locName || undefined,
      });
      setContent("");
      setMedia([]);
      setLocName("");
      setShowLoc(false);
      setShowEmoji(false);
      onPosted(res.post);
      toast.success(lang === "ar" ? "تم النشر ✔" : "Posted ✔");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="neon-card p-4 mb-3">
      <div className="relative flex gap-3">
        {/* decorative quill + sparkles (V8.1) */}
        <div className="absolute end-2 bottom-9 pointer-events-none select-none" aria-hidden>
          <Feather size={42} className="-rotate-[24deg] text-[#6EA8FF]/45 dark:text-[#8FB7FF]/40 drop-shadow-[0_0_10px_oklch(0.65_0.14_255/0.35)]" />
          <Sparkles size={16} className="absolute -bottom-1 -start-2.5 text-gold/70" />
        </div>
        <span className="relative shrink-0">
          <AvatarX user={me} size={42} verified={me?.isVerified} />
          <Crown size={16} aria-hidden className="absolute -top-2.5 -end-1.5 rotate-12 fill-gold text-gold drop-shadow-[0_1px_4px_oklch(0.75_0.13_88/0.5)]" />
        </span>
        <div className="flex-1 min-w-0">
          {/* inner writing surface — slightly different tone than the card (spec §4) */}
          <div className="relative rounded-2xl bg-muted/70 dark:bg-[#101F43]/80 px-3.5 py-2.5">
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder={t("compose_ph", lang)}
              rows={2}
              maxLength={5000}
              className="border-0 bg-transparent p-0 focus-visible:ring-0 resize-none relative z-10"
            />
            {showEmoji && <div className="fixed inset-0 z-20" onClick={() => setShowEmoji(false)} aria-hidden />}
            {showEmoji && (
              <div className="absolute z-30 bottom-full mb-2 start-2 rounded-2xl border border-border bg-popover shadow-xl p-2 grid grid-cols-8 gap-1 w-[280px]">
                {MOOD_EMOJIS.map((e) => (
                  <button
                    key={e}
                    onClick={() => appendEmoji(e)}
                    className="w-8 h-8 rounded-lg text-lg hover:bg-muted active:scale-90 transition-all flex items-center justify-center"
                    aria-label={`emoji ${e}`}
                  >
                    {e}
                  </button>
                ))}
              </div>
            )}
          </div>
          {media.length > 0 && (
            <div className="grid grid-cols-4 gap-1.5 mt-2">
              {media.map((url) => (
                <div key={url} className="relative aspect-square rounded-lg overflow-hidden bg-muted">
                  <img src={url} alt="upload" className="w-full h-full object-cover" />
                  <button
                    className="absolute top-1 end-1 bg-black/60 text-white rounded-full w-5 h-5 text-xs"
                    onClick={() => setMedia((prev) => prev.filter((u) => u !== url))}
                    aria-label="remove"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          )}
          {showLoc && (
            <div className="flex gap-2 mt-2">
              <input
                className="flex-1 h-8 rounded-full bg-muted px-3 text-sm outline-none"
                value={locName}
                onChange={(e) => setLocName(e.target.value)}
                placeholder={t("location_name_ph", lang)}
                maxLength={120}
              />
              <Button size="sm" variant="outline" onClick={useMyLocation}>{t("use_my_location", lang)}</Button>
            </div>
          )}
          <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-border/60">
            <button className="pill-soft" onClick={() => fileRef.current?.click()} disabled={uploading}>
              {uploading ? <Loader2 size={15} className="animate-spin" /> : <ImagePlus size={15} />}
              <span className="hidden sm:inline">{t("add_photos", lang)}</span>
            </button>
            <input ref={fileRef} type="file" accept="image/*,video/mp4,video/webm" multiple className="hidden" onChange={(e) => { pickFiles(e.target.files); e.target.value = ""; }} />
            <button className="pill-soft" onClick={() => setShowLoc(!showLoc)}>
              <MapPin size={15} />
              <span className="hidden sm:inline">{t("add_location", lang)}</span>
            </button>
            <button
              className={`pill-soft ${showEmoji ? "!text-gold !border-gold/45 !bg-gold/10" : ""}`}
              onClick={() => setShowEmoji(!showEmoji)}
              aria-label={lang === "ar" ? "المشاعر" : "Mood"}
            >
              <Smile size={15} />
              <span className="hidden sm:inline">{lang === "ar" ? "المشاعر" : "Mood"}</span>
            </button>
            <div className="flex-1" />
            <Select value={privacy} onValueChange={setPrivacy}>
              <SelectTrigger className="h-8 w-[104px] text-xs rounded-full border-border/80"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="PUBLIC">{t("privacy_public", lang)}</SelectItem>
                <SelectItem value="FOLLOWERS">{t("privacy_followers", lang)}</SelectItem>
                <SelectItem value="PRIVATE">{t("privacy_private", lang)}</SelectItem>
              </SelectContent>
            </Select>
            <Button
              size="sm"
              onClick={submit}
              disabled={busy || (!content.trim() && media.length === 0)}
              className="rounded-full gap-1.5 px-4 brand-gradient border-0 text-white shadow-lg shadow-primary/30 hover:opacity-90 btn-shine"
            >
              {busy ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
              {t("post", lang)}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─────────────── feed ─────────────── */

type FeedItem = { kind: "post"; post: PostDTO } | { kind: "ad"; ad: AdDTO };

export default function Feed({ refreshKey, onCreateStory, stories }: { refreshKey?: number; onCreateStory?: () => void; stories?: React.ReactNode }) {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const [items, setItems] = useState<FeedItem[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [more, setMore] = useState(true);
  const [ads, setAds] = useState<AdDTO[]>([]);
  const posts = items.filter((i) => i.kind === "post") as { kind: "post"; post: PostDTO }[];

  const load = useCallback(async (reset = false) => {
    setLoading(true);
    try {
      const q = reset ? "" : cursor ? `?cursor=${encodeURIComponent(cursor)}` : "";
      const res = await api.get<{ posts: PostDTO[]; nextCursor: string | null }>(`/api/posts${q}`);
      setCursor(res.nextCursor);
      setMore(!!res.nextCursor);
      if (reset) {
        const withAds: FeedItem[] = [];
        res.posts.forEach((p, i) => {
          withAds.push({ kind: "post", post: p });
          if ((i + 1) % 5 === 0 && ads[i % Math.max(ads.length, 1)]) {
            withAds.push({ kind: "ad", ad: ads[i % ads.length] });
          }
        });
        setItems(withAds);
      } else {
        setItems((prev) => [...prev, ...res.posts.map((p) => ({ kind: "post" as const, post: p }))]);
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [cursor, ads]);

  useEffect(() => {
    api.get<{ ads: AdDTO[] }>("/api/ads/feed").then((r) => setAds(r.ads)).catch(() => null);
    load(true);
  }, [refreshKey]);

  function onPosted(p: PostDTO) {
    setItems((prev) => [{ kind: "post", post: p }, ...prev]);
  }

  function onDeleted(id: string) {
    setItems((prev) => prev.filter((i) => i.kind !== "post" || i.post.id !== id));
  }

  return (
    <div className="mx-auto max-w-xl px-3 py-4">
      <HeroBanner onCreateStory={onCreateStory} />
      {stories}
      <Composer onPosted={onPosted} />
      {loading && items.length === 0 ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="v8-card p-4 shimmer">
              <div className="flex gap-3">
                <div className="w-10 h-10 rounded-full bg-muted" />
                <div className="flex-1 space-y-2">
                  <div className="h-3 w-32 bg-muted rounded" />
                  <div className="h-3 w-full bg-muted rounded" />
                  <div className="h-3 w-2/3 bg-muted rounded" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={<Globe size={22} />} title={t("empty_feed_title", lang)} sub={t("empty_feed_sub", lang)} />
      ) : (
        <>
          {items.map((item) =>
            item.kind === "post" ? (
              <PostCard key={item.post.id} post={item.post} onDeleted={onDeleted} />
            ) : (
              <AdCard key={`ad-${item.ad.id}`} ad={item.ad} />
            )
          )}
          {more && (
            <div className="text-center py-3">
              <Button variant="outline" onClick={() => load(false)} disabled={loading}>
                {loading ? <Spinner className="w-4 h-4" /> : t("load_more", lang)}
              </Button>
            </div>
          )}
          <FeedOrnament />
        </>
      )}
    </div>
  );
}
