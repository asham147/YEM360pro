"use client";
/**
 * YEM360 — App shell (V8 "الإصدار المذهل"): responsive navigation
 * with the navy & royal-gold identity.
 * - Ambient aurora backdrop (navy/gold light drifts)
 * - ≥ lg: glass sidebar (start side) + scroll-aware top bar
 * - < lg: top bar + floating glass bottom nav (Home / Reels / Messages / Profile)
 *   with a sliding gold active indicator
 * - Top end corner: search pill · notifications (bell-ring) · theme/lang · create
 */
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api } from "@/lib/api-client";
import { APP_VERSION } from "@/lib/version";
import { LogoMark } from "./providers";
import { AvatarX } from "./ui";
import { disconnectSocket } from "@/lib/socket";
import {
  Home, Compass, Clapperboard, MessageCircle, Bell, User, Settings, Store,
  Radio, Map, ShieldCheck, BarChart3, Megaphone, Search, LogOut, Plus,
  Moon, Sun, ChevronDown, Menu, X,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import type { ViewName } from "@/lib/types";

type BadgeKey = "unreadNotifications" | "unreadMessages";

const NAV: { name: ViewName; ar: string; en: string; icon: React.ElementType; badge?: BadgeKey }[] = [
  { name: "home", ar: "الرئيسية", en: "Home", icon: Home },
  { name: "explore", ar: "الاستكشاف", en: "Explore", icon: Compass },
  { name: "reels", ar: "ريلز", en: "Reels", icon: Clapperboard },
  { name: "messages", ar: "الرسائل", en: "Messages", icon: MessageCircle, badge: "unreadMessages" },
  { name: "notifications", ar: "الإشعارات", en: "Notifications", icon: Bell, badge: "unreadNotifications" },
  { name: "market", ar: "السوق", en: "Market", icon: Store },
  { name: "channels", ar: "قنوات البث", en: "Channels", icon: Radio },
  { name: "map", ar: "الخريطة", en: "Map", icon: Map },
];

/** mobile bottom nav — exactly 4 items per the YEM360 navigation spec. */
const MOBILE_NAV: { name: ViewName; ar: string; en: string; icon: React.ElementType; badge?: BadgeKey }[] = [
  { name: "home", ar: "الرئيسية", en: "Home", icon: Home },
  { name: "reels", ar: "ريلز", en: "Reels", icon: Clapperboard },
  { name: "messages", ar: "الرسائل", en: "Messages", icon: MessageCircle, badge: "unreadMessages" },
  { name: "profile", ar: "ملفي", en: "Profile", icon: User },
];

/** smooth color cross-fade around a theme switch (spec §8 "انتقال لوني سلس"). */
function swapTheme(setTheme: (t: string) => void, next: "light" | "dark") {
  const root = document.documentElement;
  root.classList.add("theme-anim");
  setTheme(next);
  window.setTimeout(() => root.classList.remove("theme-anim"), 520);
}

export function ThemeLangControls({ compact: _compact = false }: { compact?: boolean }) {
  const { theme: currentTheme, setTheme } = useTheme();
  const lang = useApp((s) => s.lang);
  const dark = currentTheme === "dark";

  // language lives in the header bar as an "AR ∨" pill; this control is the
  // segmented day/night switcher of the top strip (V8.2 mockups)
  return (
    <div className="theme-seg" role="group" aria-label="theme">
      <button className={dark ? "on" : ""} onClick={() => swapTheme(setTheme, "dark")} aria-pressed={dark}>
        <Moon size={13} />
        <span className="hidden sm:inline">{t("theme_night", lang)}</span>
      </button>
      <button className={!dark ? "on" : ""} onClick={() => swapTheme(setTheme, "light")} aria-pressed={!dark}>
        <Sun size={13} />
        <span className="hidden sm:inline">{t("theme_day", lang)}</span>
      </button>
    </div>
  );
}

/** quick sun/moon toggle for the main header bar (spec §2 level-2 "أيقونة الشمس"). */
function ThemeQuickToggle() {
  const { theme: currentTheme, setTheme } = useTheme();
  const dark = currentTheme === "dark";
  return (
    <button
      onClick={() => swapTheme(setTheme, dark ? "light" : "dark")}
      className="icon-btn shrink-0"
      aria-label={dark ? "light mode" : "dark mode"}
      title={dark ? "الوضع النهاري" : "الوضع الليلي"}
    >
      {dark ? <Sun size={17} className="text-gold" /> : <Moon size={17} />}
    </button>
  );
}

export default function AppShell({ children, onCreate }: { children: React.ReactNode; onCreate: (kind: "post" | "story" | "reel" | "product" | "ad" | "channel") => void }) {
  const lang = useApp((s) => s.lang);
  const setLang = useApp((s) => s.setLang);
  const user = useApp((s) => s.user);
  const counts = useApp((s) => s.counts);
  const route = useApp((s) => s.route);
  const navigate = useApp((s) => s.navigate);
  const sidebarOpen = useApp((s) => s.sidebarOpen);
  const setSidebar = useApp((s) => s.setSidebar);
  const setSession = useApp((s) => s.setSession);
  const isStaff = user?.role === "ADMIN" || user?.role === "MODERATOR";
  const isPro = user?.accountType !== "PERSONAL";

  // ── V8: scroll-aware top bar elevation ──
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // ── V8: bell swings whenever the unread count changes (remount replays the ring animation) ──

  useEffect(() => {
    // Escape closes the mobile drawer
    if (!sidebarOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setSidebar(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [sidebarOpen, setSidebar]);

  async function logout() {
    try {
      await api.post("/api/auth/logout");
    } catch {}
    disconnectSocket();
    setSession({ user: null, settings: null, privacy: null, counts: { unreadNotifications: 0, unreadMessages: 0 } });
    useApp.setState({ route: { name: "home" }, routeHistory: [] });
    toast.success(lang === "ar" ? "تم تسجيل الخروج" : "Logged out");
  }

  const badgeOf = (b?: BadgeKey) => (b && counts[b] > 0 ? counts[b] : 0);

  const isMyProfileActive = route.name === "profile" && (!route.param || route.param === user?.username);

  // ── V8: sliding gold indicator for the mobile bottom nav ──
  const activeMobileName: ViewName = isMyProfileActive ? "profile" : route.name;
  const activeMobileIdx = MOBILE_NAV.findIndex((i) => i.name === activeMobileName);
  const navRefs = useRef<(HTMLButtonElement | null)[]>([]);
  const [ind, setInd] = useState({ x: 0, w: 0, ready: false });

  const measureInd = useCallback(() => {
    const idx = activeMobileIdx >= 0 ? activeMobileIdx : 0;
    const el = navRefs.current[idx];
    if (el) setInd({ x: el.offsetLeft, w: el.offsetWidth, ready: true });
  }, [activeMobileIdx]);

  useLayoutEffect(() => {
    measureInd();
  }, [measureInd, lang]);

  useEffect(() => {
    window.addEventListener("resize", measureInd);
    return () => window.removeEventListener("resize", measureInd);
  }, [measureInd]);

  const SidebarContent = (
    <>
      <button onClick={() => navigate({ name: "home" })} className="flex items-center gap-2.5 px-2 py-1 w-full">
        <LogoMark className="w-9 h-9 logo-aura" />
        <div className="text-start flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <p className="font-extrabold text-lg leading-none gold-text gold-shimmer-text">YEM360</p>
            <span className="v8-chip">{APP_VERSION}</span>
          </div>
          <p className="text-[10px] text-muted-foreground truncate">{t("tagline", lang)}</p>
        </div>
      </button>

      <nav className="flex flex-col gap-0.5 mt-4 flex-1">
        {NAV.map((item) => {
          const Icon = item.icon;
          const active = route.name === item.name;
          const badge = badgeOf(item.badge);
          return (
            <button
              key={item.name}
              onClick={() => navigate({ name: item.name })}
              className={`relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-all ${
                active
                  ? "bg-gold/10 text-gold border border-gold/25 font-semibold"
                  : "text-foreground/75 hover:bg-muted hover:text-foreground border border-transparent"
              }`}
            >
              <span className="relative">
                <Icon size={20} className={active ? "fill-current nav-glow" : ""} />
                {badge > 0 && (
                  <span className="badge-pop badge-pulse absolute -top-1.5 -end-1.5 min-w-4 h-4 px-1 rounded-full bg-destructive text-white text-[10px] flex items-center justify-center">
                    {badge > 9 ? "9+" : badge}
                  </span>
                )}
              </span>
              {lang === "ar" ? item.ar : item.en}
            </button>
          );
        })}

        {isStaff && (
          <button
            onClick={() => navigate({ name: "admin" })}
            className={`relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
              route.name === "admin" ? "bg-gold/10 text-gold border border-gold/25" : "text-foreground/75 hover:bg-muted hover:text-foreground border border-transparent"
            }`}
          >
            <ShieldCheck size={20} className={route.name === "admin" ? "nav-glow" : ""} /> {t("admin", lang)}
          </button>
        )}
        {isPro && (
          <button
            onClick={() => navigate({ name: "insights" })}
            className={`relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
              route.name === "insights" ? "bg-gold/10 text-gold border border-gold/25" : "text-foreground/75 hover:bg-muted hover:text-foreground border border-transparent"
            }`}
          >
            <BarChart3 size={20} className={route.name === "insights" ? "nav-glow" : ""} /> {t("insights", lang)}
          </button>
        )}
        <button
          onClick={() => navigate({ name: "ads" })}
          className={`relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
            route.name === "ads" ? "bg-gold/10 text-gold border border-gold/25" : "text-foreground/75 hover:bg-muted hover:text-foreground border border-transparent"
          }`}
        >
          <Megaphone size={20} className={route.name === "ads" ? "nav-glow" : ""} /> {t("ads_campaigns", lang)}
        </button>
        <button
          onClick={() => navigate({ name: "settings" })}
          className={`relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all ${
            route.name === "settings" ? "bg-gold/10 text-gold border border-gold/25" : "text-foreground/75 hover:bg-muted hover:text-foreground border border-transparent"
          }`}
        >
          <Settings size={20} className={route.name === "settings" ? "nav-glow" : ""} /> {t("settings", lang)}
        </button>
      </nav>

      <div className="mt-2">
        <Button onClick={() => onCreate("post")} className="w-full gap-2 brand-gradient border-0 text-white hover:opacity-90 shadow-lg shadow-primary/20 btn-shine">
          <Plus size={16} /> {t("create", lang)}
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-3 w-full rounded-xl p-2 mt-2 hover:bg-muted text-start transition-colors">
              <AvatarX user={user} size={38} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{user?.name}</p>
                <p className="text-xs text-muted-foreground truncate">@{user?.username}</p>
              </div>
              <ChevronDown size={16} className="text-muted-foreground" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuLabel>{user?.name}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate({ name: "profile", param: user?.username })}>
              <User size={15} /> {t("profile", lang)}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate({ name: "settings" })}>
              <Settings size={15} /> {t("settings", lang)}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={logout} className="text-destructive">
              <LogOut size={15} /> {t("logout", lang)}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </>
  );

  return (
    <div className="min-h-screen flex flex-col">
      {/* V8 ambient backdrop (sits above the body canvas, below content) */}
      <div className="yem-aurora" aria-hidden />

      {/* top area — thin status strip (theme switcher + platform label) above the main bar */}
      <header className={`sticky top-0 z-40 header-glass backdrop-blur-xl gold-hairline transition-shadow ${scrolled ? "topbar-scrolled" : ""}`}>
        <div className="mx-auto max-w-6xl px-3">
          {/* status strip (V8.2 mockups) */}
          <div className="h-8 flex items-center justify-between gap-2">
            <ThemeLangControls />
            <span className="text-[10px] font-semibold text-muted-foreground flex items-center gap-1.5 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 soft-pulse" aria-hidden />
              {lang === "ar" ? "منصة YEM360 الرقمية" : "YEM360 Digital Platform"}
            </span>
          </div>
          <div className="h-14 flex items-center gap-1.5">
            {/* create — start side + language pill (V8.2 mockup order) */}
            <button
              onClick={() => onCreate("post")}
              className="w-10 h-10 rounded-full brand-gradient text-white flex items-center justify-center plus-glow hover:opacity-90 active:scale-90 transition-all shrink-0"
              aria-label={t("create", lang)}
            >
              <Plus size={20} />
            </button>
            <button
              className="h-9 px-2.5 rounded-full border border-border bg-card/60 flex items-center gap-1 text-xs font-extrabold shrink-0 hover:border-gold/45 hover:text-gold transition-colors"
              onClick={() => setLang(lang === "ar" ? "en" : "ar")}
              aria-label="language"
            >
              {lang === "ar" ? "AR" : "EN"}
              <ChevronDown size={12} className="text-muted-foreground" />
            </button>

            <div className="flex-1" />

            {/* end corner: bell · sun/moon · search · wordmark · menu (spec §2 order) */}
            <button
              onClick={() => navigate({ name: "notifications" })}
              className="icon-btn relative shrink-0"
              aria-label={t("notifications", lang)}
            >
              <Bell key={counts.unreadNotifications} size={17} className="bell-ring" />
              {counts.unreadNotifications > 0 && (
                <span className="badge-pop badge-pulse absolute -top-1 -end-1 min-w-4 h-4 px-1 rounded-full bg-destructive text-white text-[10px] flex items-center justify-center">
                  {counts.unreadNotifications > 9 ? "9+" : counts.unreadNotifications}
                </span>
              )}
            </button>
            <ThemeQuickToggle />
            <button
              onClick={() => navigate({ name: "search" })}
              className="icon-btn lg:!w-auto lg:!px-3.5 lg:!gap-2 shrink-0"
              aria-label={t("search", lang)}
            >
              <Search size={17} className="shrink-0" />
              <span className="hidden lg:inline text-sm font-medium">{t("search_pill", lang)}</span>
            </button>
            {/* prominent wordmark with gold swoosh + tagline */}
            <button
              onClick={() => navigate({ name: "home" })}
              aria-label="YEM360 home"
              className="flex flex-col items-center leading-none px-1 shrink-0"
            >
              <span className="font-black italic text-lg sm:text-2xl tracking-tight gold-text gold-shimmer-text logo-aura">YEM360</span>
              <svg viewBox="0 0 100 6" className="w-16 sm:w-24 h-1.5" aria-hidden>
                <path d="M6 4 Q 50 -3 94 3" fill="none" stroke="#C9A227" strokeWidth="2.2" strokeLinecap="round" opacity="0.85" />
              </svg>
              <span className="hidden sm:block text-[7px] sm:text-[8px] tracking-[0.18em] font-bold text-muted-foreground uppercase mt-0.5">Your Digital World</span>
            </button>
            <button className="icon-btn lg:hidden! shrink-0" onClick={() => setSidebar(!sidebarOpen)} aria-label="menu">
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-1">
        {/* sidebar (desktop) */}
        <aside className="hidden lg:flex flex-col w-64 shrink-0 border-e px-4 py-4 sticky top-[5.25rem] h-[calc(100vh-5.25rem)] overflow-y-auto yem-scroll">
          {SidebarContent}
        </aside>

        {/* sidebar (mobile drawer) */}
        {sidebarOpen && (
          <div className="fixed inset-0 z-50 lg:hidden" onClick={() => setSidebar(false)}>
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
            <aside
              className="absolute top-0 bottom-0 start-0 w-72 bg-card border-e p-4 flex flex-col overflow-y-auto yem-scroll shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <button className="self-end p-1 mb-1" onClick={() => setSidebar(false)} aria-label="close">
                <X size={20} />
              </button>
              {SidebarContent}
            </aside>
          </div>
        )}

        {/* main content */}
        <main className="flex-1 min-w-0 pb-28 lg:pb-4">{children}</main>
      </div>

      {/* floating glass bottom nav (mobile) — Home · Reels · Messages · Profile */}
      <nav className="lg:hidden fixed z-40 inset-x-2 bottom-[calc(0.5rem+env(safe-area-inset-bottom,0px))] bottom-nav rounded-2xl" aria-label="primary">
        <div className="relative grid grid-cols-4 h-16">
          {/* sliding gold indicator (V8) */}
          {ind.ready && activeMobileIdx >= 0 && (
            <span className="nav-indicator" style={{ left: ind.x, width: ind.w }} aria-hidden />
          )}
          {MOBILE_NAV.map((item, idx) => {
            const Icon = item.icon;
            const active = item.name === "profile" ? isMyProfileActive : route.name === item.name;
            const badge = badgeOf(item.badge);
            return (
              <button
                key={item.name}
                ref={(el) => { navRefs.current[idx] = el; }}
                onClick={() => navigate(item.name === "profile" ? { name: "profile", param: user?.username } : { name: item.name })}
                className={`relative z-10 flex flex-col items-center justify-center gap-0.5 transition-transform active:scale-90 ${
                  active ? "nav-active-fg" : "text-muted-foreground"
                }`}
                aria-label={lang === "ar" ? item.ar : item.en}
                aria-current={active ? "page" : undefined}
              >
                <span className="relative flex items-center justify-center">
                  <Icon size={22} className={`transition-transform duration-300 ${active ? "fill-current -translate-y-0.5 scale-110" : ""}`} />
                  {badge > 0 && (
                    <span className="badge-pop badge-pulse absolute -top-1.5 -end-2 min-w-4 h-4 px-1 rounded-full bg-destructive text-white text-[10px] flex items-center justify-center">
                      {badge > 9 ? "9+" : badge}
                    </span>
                  )}
                </span>
                <span className={`text-[10px] ${active ? "font-bold" : ""}`}>{lang === "ar" ? item.ar : item.en}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
