"use client";
/**
 * YEM360 — Reels: vertical snap feed with autoplay, like (double-tap burst),
 * comments, follow, view counting and an upload sheet with live progress.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, fmtNumber, timeAgo, uploadFileWithProgress, validateMediaFile } from "@/lib/api-client";
import type { ReelDTO, CommentDTO } from "@/lib/types";
import { AvatarX, EmptyState, Spinner, VerifiedIcon } from "./ui";
import { CommentsSection } from "./feed";
import { Heart, MessageCircle, Music2, Volume2, VolumeX, Plus, Upload, Eye, Loader2, Play, Pause, Download, Share2 } from "lucide-react";
import { absoluteUrl, downloadMedia, shareLink } from "@/lib/share";

/** reels already counted as viewed in this browser session (dedupe). */
const viewedThisSession = new Set<string>();

export default function ReelsView({ onCreate }: { onCreate: () => void }) {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const [reels, setReels] = useState<ReelDTO[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [more, setMore] = useState(true);
  const [muted, setMuted] = useState(true);
  const [commentsFor, setCommentsFor] = useState<ReelDTO | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async (reset = false) => {
    setLoading(true);
    try {
      const q = reset || !cursor ? "" : `?cursor=${encodeURIComponent(cursor)}`;
      const res = await api.get<{ reels: ReelDTO[]; nextCursor: string | null }>(`/api/reels${q}`);
      setCursor(res.nextCursor);
      setMore(!!res.nextCursor);
      if (reset) setReels(res.reels);
      else setReels((prev) => [...prev, ...res.reels]);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [cursor]);

  useEffect(() => {
    load(true);
  }, []);

  /** +1 view for a reel (called after the server confirms a counted view). */
  const bumpView = useCallback((id: string) => {
    setReels((prev) => prev.map((r) => (r.id === id ? { ...r, viewCount: r.viewCount + 1 } : r)));
  }, []);

  return (
    <div className="relative bg-black min-h-[calc(100vh-3.5rem)]">
      <div className="absolute top-3 end-3 z-20 flex gap-2">
        <button onClick={() => setMuted(!muted)} className="w-9 h-9 rounded-full bg-black/50 text-white flex items-center justify-center" aria-label="mute">
          {muted ? <VolumeX size={17} /> : <Volume2 size={17} />}
        </button>
        <button onClick={() => setUploadOpen(true)} className="w-9 h-9 rounded-full bg-black/50 text-white flex items-center justify-center" aria-label={t("reels", lang)}>
          <Plus size={17} />
        </button>
      </div>

      {loading && reels.length === 0 ? (
        <div className="h-[70vh] flex items-center justify-center"><Spinner /></div>
      ) : reels.length === 0 ? (
        <div className="h-[70vh] flex items-center justify-center bg-background">
          <EmptyState icon={<Eye size={22} />} title={t("reels", lang)} sub={lang === "ar" ? "لا ريلز بعد — انشر أول فيديو قصير" : "No reels yet — share the first short video"} />
        </div>
      ) : (
        <div
          ref={containerRef}
          className="reels-snap h-[calc(100vh-3.5rem)] overflow-y-auto yem-scroll snap-y"
          onScroll={(e) => {
            const el = e.currentTarget;
            if (el.scrollHeight - el.scrollTop - el.clientHeight < 400 && more && !loading) load(false);
          }}
        >
          {reels.map((reel) => (
            <ReelCard
              key={reel.id}
              reel={reel}
              muted={muted}
              onComments={() => setCommentsFor(reel)}
              onProfile={() => navigate({ name: "profile", param: reel.author.username })}
              onView={bumpView}
            />
          ))}
        </div>
      )}

      {/* comments sheet */}
      <Sheet open={!!commentsFor} onOpenChange={(v) => !v && setCommentsFor(null)}>
        <SheetContent side="bottom" className="h-[70vh] rounded-t-2xl max-w-xl mx-auto">
          <SheetHeader>
            <SheetTitle>{t("comment", lang)} · {fmtNumber(commentsFor?.commentCount ?? 0)}</SheetTitle>
          </SheetHeader>
          {commentsFor && (
            <CommentsSection postId={commentsFor.id} target="reel" />
          )}
        </SheetContent>
      </Sheet>

      <ReelUpload open={uploadOpen} onOpenChange={setUploadOpen} onCreated={() => load(true)} />
    </div>
  );
}

function ReelCard({
  reel,
  muted,
  onComments,
  onProfile,
  onView,
}: {
  reel: ReelDTO;
  muted: boolean;
  onComments: () => void;
  onProfile: () => void;
  onView: (id: string) => void;
}) {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [liked, setLiked] = useState(reel.likedByMe);
  const [likeCount, setLikeCount] = useState(reel.likeCount);
  const [burst, setBurst] = useState(0); // heart animation retrigger key
  const [flash, setFlash] = useState<"play" | "pause" | null>(null);
  const countedRef = useRef(false);
  const onViewRef = useRef(onView);
  onViewRef.current = onView;
  const tapTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // keep local state in sync when the parent refreshes the list
  useEffect(() => setLiked(reel.likedByMe), [reel.likedByMe]);
  useEffect(() => setLikeCount(reel.likeCount), [reel.likeCount]);
  useEffect(() => () => { if (tapTimer.current) clearTimeout(tapTimer.current); }, []);

  /** count one view per reel per session, only when actually visible. */
  const countViewOnce = useCallback(() => {
    if (countedRef.current) return;
    countedRef.current = true;
    api.post(`/api/reels/${reel.id}/view`)
      .then(() => onViewRef.current(reel.id))
      .catch(() => null);
  }, [reel.id]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            v.play().catch(() => null);
            countViewOnce();
          } else {
            v.pause();
          }
        });
      },
      { threshold: 0.6 }
    );
    obs.observe(v);
    return () => obs.disconnect();
  }, [countViewOnce]);

  useEffect(() => {
    if (videoRef.current) videoRef.current.muted = muted;
  }, [muted]);

  /** share the reel via native sheet; falls back to copying the video link. */
  async function shareReel() {
    try {
      await shareLink({
        title: `@${reel.author.username} · YEM360`,
        text: reel.caption || undefined,
        url: absoluteUrl(reel.videoUrl),
      }, lang);
    } catch (e) {
      if ((e as DOMException)?.name !== "AbortError") toast.error((e as Error).message);
    }
  }

  async function toggleLike(withBurst = false) {
    const wasLiked = liked;
    const next = !wasLiked;
    setLiked(next); // optimistic
    setLikeCount((c) => c + (next ? 1 : -1));
    if (withBurst && next) setBurst((b) => b + 1);
    try {
      const res = next
        ? await api.post<{ likeCount: number }>(`/api/reels/${reel.id}/like`)
        : await api.del<{ likeCount: number }>(`/api/reels/${reel.id}/like`);
      setLikeCount(res.likeCount);
    } catch (e) {
      setLiked(wasLiked); // rollback
      setLikeCount((c) => c + (next ? -1 : 1));
      toast.error((e as Error).message);
    }
  }

  /** single tap = play/pause flash, double tap = like + heart burst. */
  function handleVideoClick() {
    const v = videoRef.current;
    if (!v) return;
    if (tapTimer.current) {
      clearTimeout(tapTimer.current);
      tapTimer.current = null;
      if (!liked) void toggleLike(true);
      else {
        setBurst((b) => b + 1); // already liked → show heart anyway
      }
      return;
    }
    tapTimer.current = setTimeout(() => {
      tapTimer.current = null;
      if (v.paused) {
        v.play().catch(() => null);
        setFlash("play");
      } else {
        v.pause();
        setFlash("pause");
      }
      setTimeout(() => setFlash(null), 600);
    }, 240);
  }

  return (
    <div className="h-full relative flex items-center justify-center bg-black">
      <video
        ref={videoRef}
        src={reel.videoUrl}
        className="max-h-full max-w-full object-contain"
        loop
        muted={muted}
        playsInline
        preload="metadata"
        onClick={handleVideoClick}
      />
      {flash && (
        <span className="icon-flash pointer-events-none absolute text-white/90" aria-hidden>
          {flash === "play" ? <Play size={64} className="fill-white/90" /> : <Pause size={64} className="fill-white/90" />}
        </span>
      )}
      {burst > 0 && (
        <Heart
          key={burst}
          size={110}
          className="heart-burst pointer-events-none absolute fill-destructive text-destructive"
          style={{ left: "50%", top: "50%", marginLeft: -55, marginTop: -55 }}
          aria-hidden
        />
      )}
      {/* overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-black/30 pointer-events-none" />
      <div className="absolute bottom-6 start-4 end-20 text-white pointer-events-none">
        <button className="pointer-events-auto flex items-center gap-2 mb-2" onClick={onProfile}>
          <AvatarX user={reel.author} size={38} />
          <span className="font-semibold text-sm flex items-center gap-1">
            @{reel.author.username} <VerifiedIcon show={reel.author.isVerified} />
          </span>
        </button>
        {reel.caption && <p className="text-sm whitespace-pre-wrap line-clamp-2-custom opacity-95">{reel.caption}</p>}
        {reel.musicName && (
          <p className="text-xs mt-1.5 flex items-center gap-1 opacity-80"><Music2 size={12} /> {reel.musicName}</p>
        )}
        <p className="text-[11px] mt-1 opacity-70 flex items-center gap-1"><Eye size={11} /> {fmtNumber(reel.viewCount)} {t("views", lang)} · {timeAgo(reel.createdAt, lang)}</p>
      </div>
      {/* actions */}
      <div className="absolute bottom-6 end-3 flex flex-col gap-4 items-center text-white">
        <button onClick={() => toggleLike()} className="flex flex-col items-center gap-1" aria-label="like">
          <Heart size={26} className={`transition-transform active:scale-125 ${liked ? "fill-destructive text-destructive" : ""}`} />
          <span className="text-xs">{fmtNumber(likeCount)}</span>
        </button>
        <button onClick={onComments} className="flex flex-col items-center gap-1" aria-label="comments">
          <MessageCircle size={26} />
          <span className="text-xs">{fmtNumber(reel.commentCount)}</span>
        </button>
        <button onClick={() => downloadMedia(reel.videoUrl, lang)} className="flex flex-col items-center gap-1" aria-label={t("download", lang)}>
          <Download size={26} />
          <span className="text-xs">{t("download", lang)}</span>
        </button>
        <button onClick={shareReel} className="flex flex-col items-center gap-1" aria-label={t("share", lang)}>
          <Share2 size={26} />
          <span className="text-xs">{t("share", lang)}</span>
        </button>
        <button onClick={onProfile} className="mt-2" aria-label="profile">
          <AvatarX user={reel.author} size={34} />
        </button>
      </div>
    </div>
  );
}

function ReelUpload({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (v: boolean) => void; onCreated: () => void }) {
  const lang = useApp((s) => s.lang);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [caption, setCaption] = useState("");
  const [music, setMusic] = useState("");
  const [duration, setDuration] = useState<number | undefined>();
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  // revoke blob URLs to avoid memory leaks
  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);

  function pick(f: File | null) {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setPreviewUrl(null);
    setDuration(undefined);
    if (!f) { setFile(null); return; }
    const err = validateMediaFile(f, lang);
    if (err) {
      toast.error(err);
      setFile(null);
      if (fileRef.current) fileRef.current.value = "";
      return;
    }
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
    const v = document.createElement("video");
    v.preload = "metadata";
    v.onloadedmetadata = () => {
      setDuration(Math.round(v.duration));
      if (v.duration > 90) {
        toast.warning(lang === "ar" ? "الفيديو أطول من 90 ثانية، يُفضل مقاطع قصيرة" : "Video is longer than 90s — short clips work best");
      }
    };
    v.src = URL.createObjectURL(f);
  }

  async function submit() {
    if (!file || busy) return;
    setBusy(true);
    setProgress(0);
    try {
      const { media } = await uploadFileWithProgress(file, "reel", setProgress);
      await api.post("/api/reels", { videoUrl: media.url, caption: caption || undefined, musicName: music || undefined, duration });
      toast.success(lang === "ar" ? "تم نشر الريل بنجاح" : "Reel published");
      pick(null);
      setCaption("");
      setMusic("");
      onOpenChange(false);
      onCreated();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
      setProgress(null);
    }
  }

  const pct = progress ?? 0;

  return (
    <Sheet open={open} onOpenChange={(v) => { if (!busy) onOpenChange(v); }}>
      <SheetContent side="bottom" className="h-auto rounded-t-2xl max-w-xl mx-auto">
        <SheetHeader><SheetTitle>{lang === "ar" ? "ريل جديد" : "New reel"}</SheetTitle></SheetHeader>
        <div className="space-y-3 pb-6">
          <button
            onClick={() => fileRef.current?.click()}
            disabled={busy}
            className="w-full h-40 rounded-2xl bg-muted flex flex-col items-center justify-center gap-2 text-muted-foreground overflow-hidden"
          >
            {previewUrl && file ? (
              <>
                <video src={previewUrl} className="h-full rounded-2xl" muted playsInline />
                <span className="text-xs px-2 truncate w-full text-center">
                  {file.name} · {(file.size / 1024 / 1024).toFixed(1)}MB{duration ? ` · ${duration}s` : ""}
                </span>
              </>
            ) : (
              <>
                <Upload size={26} />
                <span className="text-sm">{lang === "ar" ? "اختر فيديو MP4 أو WEBM (حتى 60MB)" : "Pick MP4/WEBM video (up to 60MB)"}</span>
              </>
            )}
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="video/mp4,video/webm"
            className="hidden"
            onChange={(e) => pick(e.target.files?.[0] ?? null)}
          />
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder={lang === "ar" ? "وصف الريل... #هاشتاغ" : "Caption... #hashtag"}
            rows={2}
            maxLength={2000}
            disabled={busy}
            className="w-full rounded-xl border bg-transparent p-3 text-sm outline-none focus:ring-1 focus:ring-ring"
          />
          <input
            value={music}
            onChange={(e) => setMusic(e.target.value)}
            placeholder={lang === "ar" ? "اسم المقطع الصوتي (اختياري)" : "Music name (optional)"}
            maxLength={100}
            disabled={busy}
            className="w-full h-9 rounded-xl border bg-transparent px-3 text-sm outline-none focus:ring-1 focus:ring-ring"
          />
          {busy && progress !== null && (
            <div className="space-y-1">
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <div className="h-full bg-primary upload-progress rounded-full" style={{ width: `${pct}%` }} />
              </div>
              <p className="text-xs text-muted-foreground text-center">
                {lang === "ar" ? `جاري الرفع... ${pct}%` : `Uploading... ${pct}%`}
              </p>
            </div>
          )}
          <Button onClick={submit} disabled={busy || !file} className="w-full">
            {busy ? (
              <span className="flex items-center gap-2"><Loader2 size={16} className="animate-spin" /> {pct}%</span>
            ) : (
              lang === "ar" ? "نشر الريل" : "Publish reel"
            )}
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
