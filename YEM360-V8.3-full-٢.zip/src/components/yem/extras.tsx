"use client";
/**
 * YEM360 — Notifications view + Insights (pro analytics with charts) + Map.
 */
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, timeAgo, fmtNumber } from "@/lib/api-client";
import type { NotificationDTO, PublicUser } from "@/lib/types";
import { AvatarX, EmptyState, Spinner, UserRow } from "./ui";
import {
  Heart, MessageCircle, UserPlus, AtSign, Bell, CheckCheck, Store, Radio, Package, Users, Eye, TrendingUp,
} from "lucide-react";

/* ─────────────── notifications ─────────────── */

const NOTIF_ICON: Record<string, React.ReactNode> = {
  LIKE: <Heart size={15} className="fill-destructive text-destructive" />,
  COMMENT: <MessageCircle size={15} className="text-primary" />,
  COMMENT_REPLY: <MessageCircle size={15} className="text-primary" />,
  MENTION: <AtSign size={15} className="text-primary" />,
  FOLLOW: <UserPlus size={15} className="text-primary" />,
  FRIEND_REQUEST: <UserPlus size={15} className="text-primary" />,
  FRIEND_ACCEPT: <UserCheck size={15} className="text-primary" />,
  MESSAGE: <MessageCircle size={15} className="text-emerald-500" />,
  ORDER: <Package size={15} className="text-amber-500" />,
  CHANNEL_POST: <Radio size={15} className="text-primary" />,
  PRODUCT_SOLD: <Store size={15} className="text-amber-500" />,
  SYSTEM: <Bell size={15} />,
};

function UserCheck({ size, className }: { size: number; className?: string }) {
  return <UserPlus size={size} className={className} />;
}

export function NotificationsView({ refreshKey }: { refreshKey?: number }) {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const setCounts = useApp((s) => s.setCounts);
  const [filter, setFilter] = useState("all");
  const [items, setItems] = useState<NotificationDTO[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.get<{ notifications: NotificationDTO[]; unread: number }>(`/api/notifications?type=${filter}`);
      setItems(res.notifications);
      setCounts({ unreadNotifications: res.unread });
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [filter, setCounts]);

  useEffect(() => {
    load();
  }, [load, refreshKey]);

  async function markAll() {
    try {
      await api.post("/api/notifications/read", { all: true });
      setCounts({ unreadNotifications: 0 });
      load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div className="mx-auto max-w-xl px-3 py-4">
      <div className="flex items-center justify-between mb-3">
        <h1 className="text-xl font-bold">{t("notifications", lang)}</h1>
        <Button size="sm" variant="ghost" onClick={markAll}><CheckCheck size={15} /> {t("mark_all_read", lang)}</Button>
      </div>
      <Tabs value={filter} onValueChange={setFilter}>
        <TabsList className="w-full">
          <TabsTrigger value="all" className="flex-1">{t("all", lang)}</TabsTrigger>
          <TabsTrigger value="likes" className="flex-1">{t("like", lang)}</TabsTrigger>
          <TabsTrigger value="comments" className="flex-1">{t("comment", lang)}</TabsTrigger>
          <TabsTrigger value="follows" className="flex-1">{t("following", lang)}</TabsTrigger>
        </TabsList>
        <TabsContent value={filter} className="mt-3">
          {loading ? (
            <div className="py-12 flex justify-center"><Spinner /></div>
          ) : items.length === 0 ? (
            <EmptyState icon={<Bell size={22} />} title={t("no_notifications", lang)} />
          ) : (
            items.map((n) => (
              <button
                key={n.id}
                onClick={() => {
                  // message notifications open the conversation directly; others → actor profile
                  if (n.entityType === "CONVERSATION" && n.entityId) {
                    navigate({ name: "messages", param: n.entityId });
                  } else if (n.actor) {
                    navigate({ name: "profile", param: n.actor.username });
                  }
                  if (!n.isRead) {
                    api.post("/api/notifications/read", { id: n.id }).catch(() => null);
                  }
                }}
                className={`w-full flex items-center gap-3 p-3 rounded-xl text-start hover:bg-muted ${!n.isRead ? "bg-primary/5" : ""}`}
              >
                {n.actor ? <AvatarX user={n.actor} size={40} /> : <span className="w-10 h-10 rounded-full bg-muted flex items-center justify-center"><Bell size={16} /></span>}
                <div className="flex-1 min-w-0">
                  <p className="text-sm">
                    <b>{n.actor?.name || ""}</b> {n.text}
                  </p>
                  <p className="text-xs text-muted-foreground">{timeAgo(n.createdAt, lang)}</p>
                </div>
                <span className="shrink-0">{NOTIF_ICON[n.type] || <Bell size={15} />}</span>
              </button>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

/* ─────────────── insights ─────────────── */

interface InsightsData {
  totals: { postViews: number; reelViews: number; likes28: number; comments28: number; followers: number; following: number; posts: number; reels: number };
  daily: { date: string; label: string; followers: number; likes: number }[];
  topPosts: { id: string; content: string; likeCount: number; viewCount: number; media: { url: string; type: string }[] }[];
}

export function InsightsView() {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const [data, setData] = useState<InsightsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.get<InsightsData>("/api/insights")
      .then(setData)
      .catch((e) => setError((e as Error).message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="py-16 flex justify-center"><Spinner /></div>;
  if (error || !data) {
    return (
      <div className="mx-auto max-w-xl px-3 py-8">
        <EmptyState icon={<TrendingUp size={22} />} title={t("insights", lang)} sub={error || t("error_generic", lang)} />
        <div className="text-center">
          <Button variant="outline" onClick={() => navigate({ name: "profile", param: useApp.getState().user?.username || "" })}>
            {t("switch_to_pro", lang)} — {t("edit_profile", lang)}
          </Button>
        </div>
      </div>
    );
  }

  const maxDaily = Math.max(...data.daily.map((d) => Math.max(d.followers, d.likes)), 1);

  return (
    <div className="mx-auto max-w-2xl px-3 py-4">
      <h1 className="text-xl font-bold mb-4">{t("insights", lang)}</h1>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        <KPI label={t("followers_count", lang)} value={data.totals.followers} />
        <KPI label={`${t("views", lang)} (${t("posts_tab", lang)})`} value={data.totals.postViews} />
        <KPI label={`${t("views", lang)} (${t("reels_tab", lang)})`} value={data.totals.reelViews} />
        <KPI label={`${t("like", lang)} (28d)`} value={data.totals.likes28} />
      </div>

      <div className="v8-card p-4 mb-4">
        <p className="font-semibold text-sm mb-3 flex items-center gap-1.5"><Users size={15} className="text-primary" /> {lang === "ar" ? "النمو خلال 14 يوماً" : "Growth — last 14 days"}</p>
        <div className="flex items-end gap-1 h-36">
          {data.daily.map((d) => (
            <div key={d.date} className="flex-1 flex flex-col justify-end items-center gap-0.5" title={`${d.label}: ${d.followers}+ / ${d.likes}♥`}>
              <div className="w-full bg-primary/70 rounded-t" style={{ height: `${(d.followers / maxDaily) * 100}%`, minHeight: d.followers ? 4 : 0 }} />
              <div className="w-full bg-amber-500/60 rounded-t" style={{ height: `${(d.likes / maxDaily) * 100}%`, minHeight: d.likes ? 4 : 0 }} />
              <span className="text-[8px] text-muted-foreground">{d.label.split(" ")[0]}</span>
            </div>
          ))}
        </div>
        <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-primary/70 inline-block" /> {t("followers_count", lang)}</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-amber-500/60 inline-block" /> {t("like", lang)}</span>
        </div>
      </div>

      <div className="v8-card p-4">
        <p className="font-semibold text-sm mb-3 flex items-center gap-1.5"><Eye size={15} className="text-primary" /> {lang === "ar" ? "أفضل المنشورات" : "Top posts"}</p>
        <div className="space-y-2">
          {data.topPosts.map((p) => (
            <div key={p.id} className="flex items-center gap-3">
              {p.media[0] ? (
                <img src={p.media[0].url} alt="post" className="w-11 h-11 rounded-lg object-cover" />
              ) : (
                <span className="w-11 h-11 rounded-lg bg-muted flex items-center justify-center text-muted-foreground"><Eye size={16} /></span>
              )}
              <p className="flex-1 text-sm truncate">{p.content || (p.media[0] ? "📷" : "—")}</p>
              <span className="text-xs text-muted-foreground flex items-center gap-1"><Eye size={12} /> {fmtNumber(p.viewCount)}</span>
              <span className="text-xs text-muted-foreground flex items-center gap-1"><Heart size={12} /> {fmtNumber(p.likeCount)}</span>
            </div>
          ))}
          {data.topPosts.length === 0 && <p className="text-sm text-muted-foreground">—</p>}
        </div>
      </div>
    </div>
  );
}

function KPI({ label, value }: { label: string; value: number }) {
  return (
    <div className="v8-card p-4">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-2xl font-bold mt-1">{fmtNumber(value)}</p>
    </div>
  );
}

/* ─────────────── map ─────────────── */

interface MapPost {
  id: string;
  content: string;
  locationName?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  author: { name: string; username: string; avatarUrl?: string | null };
  media: { url: string; type: string }[];
}

export function MapView() {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const [posts, setPosts] = useState<MapPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<MapPost | null>(null);
  const [mapError, setMapError] = useState(false);

  useEffect(() => {
    api.get<{ posts: MapPost[] }>("/api/map")
      .then((r) => setPosts(r.posts.filter((p) => p.latitude && p.longitude)))
      .catch((e) => toast.error((e as Error).message))
      .finally(() => setLoading(false));
  }, []);

  // approximate Yemen bounds; fall back to world bounds
  const lat = posts.length ? posts[0].latitude! : 15.3;
  const lng = posts.length ? posts[0].longitude! : 44.1;

  return (
    <div className="mx-auto max-w-3xl px-3 py-4">
      <h1 className="text-xl font-bold mb-2 flex items-center gap-2">
        <Eye size={20} className="text-primary" /> {t("map", lang)}
      </h1>
      <p className="text-xs text-muted-foreground mb-3">{t("map_hint", lang)}</p>

      {loading ? (
        <div className="py-16 flex justify-center"><Spinner /></div>
      ) : posts.length === 0 ? (
        <EmptyState icon={<Eye size={22} />} title={t("no_locations", lang)} sub={lang === "ar" ? "أضف موقعاً لمنشورك من محرر المنشورات" : "Add a location from the composer"} />
      ) : (
        <>
          <div className="rounded-2xl overflow-hidden border h-80 bg-muted relative">
            <iframe
              title="YEM360 map"
              className="w-full h-full"
              src={`https://www.openstreetmap.org/export/embed.html?bbox=${lng - 2}%2C${lat - 2}%2C${lng + 2}%2C${lat + 2}&layer=mapnik&marker=${lat}%2C${lng}`}
              loading="lazy"
              onError={() => setMapError(true)}
            />
          </div>
          {mapError && <p className="text-xs text-destructive mt-2">{lang === "ar" ? "تعذر تحميل الخريطة — تحقق من الاتصال" : "Map failed to load — check connection"}</p>}
          <div className="mt-4 space-y-2">
            {posts.map((p) => (
              <button key={p.id} onClick={() => setSelected(p)} className="w-full bg-card border rounded-xl p-3 text-start hover:bg-muted">
                <div className="flex items-center gap-2">
                  <AvatarX user={p.author} size={30} />
                  <span className="text-sm font-semibold">{p.author.name}</span>
                  <span className="text-xs text-muted-foreground flex items-center gap-1"><Eye size={11} /> {p.locationName}</span>
                </div>
                <p className="text-xs text-muted-foreground truncate mt-1">{p.content || "📷"}</p>
              </button>
            ))}
          </div>
        </>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setSelected(null)}>
          <div className="bg-card rounded-2xl p-4 max-w-sm w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2 mb-2">
              <AvatarX user={selected.author} size={34} />
              <div>
                <p className="text-sm font-semibold">{selected.author.name}</p>
                <p className="text-xs text-muted-foreground">@{selected.author.username} · {selected.locationName}</p>
              </div>
            </div>
            {selected.media[0] && <img src={selected.media[0].url} alt="post" className="rounded-xl max-h-56 w-full object-cover mb-2" />}
            <p className="text-sm">{selected.content}</p>
          </div>
        </div>
      )}
      <div className="h-6" />
    </div>
  );
}

/* small helper to satisfy icons used above */
export function UserCheckIcon({ size }: { size: number }) {
  return <Users size={size} />;
}
