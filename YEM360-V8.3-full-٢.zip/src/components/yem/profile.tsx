"use client";
/**
 * YEM360 — Profile: header, tabs (posts/reels/saved/friends), follow lists,
 * edit profile, professional switch, relationship actions.
 */
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, fmtNumber } from "@/lib/api-client";
import type { ProfileDTO, PostDTO, ReelDTO, PublicUser } from "@/lib/types";
import { PostCard } from "./feed";
import { AvatarX, EmptyState, Spinner, UserRow, ReportDialog, VerifiedIcon, ImagePickButton } from "./ui";
import { NoteComposer, StoriesBar } from "./stories";
import {
  Grid3X3, Clapperboard, Bookmark, Users, Settings, MoreHorizontal, UserMinus, Flag,
  MessageCircle, BarChart3, UserPlus, BadgeCheck, Store, Link2, MapPin,
} from "lucide-react";

export default function ProfileView({ username, onEditProfile }: { username: string; onEditProfile?: () => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const navigate = useApp((s) => s.navigate);
  const [data, setData] = useState<ProfileDTO | null>(null);
  const [posts, setPosts] = useState<PostDTO[]>([]);
  const [reels, setReels] = useState<ReelDTO[]>([]);
  const [savedPosts, setSavedPosts] = useState<PostDTO[]>([]);
  const [friends, setFriends] = useState<PublicUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [reportOpen, setReportOpen] = useState(false);
  const [listDialog, setListDialog] = useState<"followers" | "following" | null>(null);
  const [listUsers, setListUsers] = useState<PublicUser[]>([]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const profile = await api.get<ProfileDTO>(`/api/profile/${username}`);
      setData(profile);
      if (profile.relationship.canSeeContent) {
        const [p, r] = await Promise.all([
          api.get<{ posts: PostDTO[] }>(`/api/users/${username}/posts`),
          api.get<{ reels: ReelDTO[] }>(`/api/users/${username}/reels`),
        ]);
        setPosts(p.posts);
        setReels(r.reels);
        if (profile.relationship.isSelf) {
          const s = await api.get<{ posts: PostDTO[] }>("/api/posts");
          const saved = await api.get<{ posts: PostDTO[] }>(`/api/follows?type=followers&username=${username}`);
          void saved;
          setSavedPosts(p.posts.filter((x) => x.savedByMe).length ? p.posts.filter((x) => x.savedByMe) : []);
        }
        if (profile.relationship.isSelf) {
          const f = await api.get<{ friends: { user: PublicUser }[] }>("/api/friends");
          setFriends(f.friends.map((x) => x.user));
        }
      }
    } catch (e) {
      toast.error((e as Error).message);
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [username]);

  useEffect(() => {
    load();
  }, [load]);

  async function loadList(type: "followers" | "following") {
    try {
      const res = await api.get<{ users: PublicUser[] }>(`/api/follows?username=${encodeURIComponent(username)}&type=${type}`);
      setListUsers(res.users);
      setListDialog(type);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function toggleFollow() {
    if (!data) return;
    const rel = data.relationship;
    try {
      if (rel.isFollowing || rel.isPending) {
        await api.del(`/api/follows/${username}`);
        await load();
      } else {
        const res = await api.post<{ status: string }>(`/api/follows/${username}`);
        toast.success(res.status === "PENDING" ? t("requested", lang) : t("following", lang));
        await load();
      }
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function friendAction(action: "add" | "accept" | "reject") {
    if (!data) return;
    try {
      if (action === "add") {
        await api.post("/api/friends", { userId: data.user.id });
        toast.success(t("add_friend", lang));
      } else if (action === "accept" && data.relationship.friendshipId) {
        await api.post(`/api/friends/requests/${data.relationship.friendshipId}`);
      } else if (data.relationship.friendshipId) {
        await api.del(`/api/friends/requests/${data.relationship.friendshipId}`);
      }
      await load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function startChat() {
    if (!data) return;
    try {
      const res = await api.post<{ conversationId: string }>("/api/messages/conversations", { type: "DIRECT", userId: data.user.id });
      navigate({ name: "messages", param: res.conversationId });
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function toggleBlock() {
    if (!data) return;
    try {
      if (data.relationship.isBlockedByMe) {
        await api.del(`/api/blocks?userId=${data.user.id}`);
        toast.success(t("unblock", lang));
      } else {
        await api.post("/api/blocks", { userId: data.user.id });
        toast.success(t("block", lang));
      }
      await load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  if (loading && !data) return <div className="py-20 flex justify-center"><Spinner /></div>;
  if (!data) return <EmptyState icon={<UserMinus size={22} />} title={t("error_generic", lang)} />;

  const rel = data.relationship;
  const isSelf = rel.isSelf;

  return (
    <div className="mx-auto max-w-2xl px-3 py-4">
      {/* header */}
      <div className="relative">
        <div className="h-32 rounded-2xl bg-muted overflow-hidden">
          {data.user.coverUrl ? (
            <img src={data.user.coverUrl} alt="cover" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full brand-gradient" />
          )}
        </div>
        <div className="px-4">
          <div className="flex items-end justify-between -mt-9">
            <div className="rounded-full border-4 border-background">
              <AvatarX user={data.user} size={84} />
            </div>
            <div className="flex gap-2 pb-1">
              {isSelf ? (
                <>
                  <Button size="sm" variant="outline" onClick={() => onEditProfile?.()}>{t("edit_profile", lang)}</Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button size="icon" variant="outline"><MoreHorizontal size={16} /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => navigate({ name: "settings" })}><Settings size={14} /> {t("settings", lang)}</DropdownMenuItem>
                      {me?.accountType === "PERSONAL" ? (
                        <DropdownMenuItem onClick={async () => {
                          await api.patch("/api/profile", { accountType: "PROFESSIONAL" });
                          toast.success(t("switch_to_pro", lang));
                          await load();
                        }}><Store size={14} /> {t("switch_to_pro", lang)}</DropdownMenuItem>
                      ) : (
                        <DropdownMenuItem onClick={async () => {
                          await api.patch("/api/profile", { accountType: "PERSONAL" });
                          toast.success(t("switch_to_personal", lang));
                          await load();
                        }}><UserMinus size={14} /> {t("switch_to_personal", lang)}</DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              ) : (
                <>
                  {!rel.isBlockedByMe && (
                    <Button size="sm" variant={rel.isFollowing ? "outline" : "default"} onClick={toggleFollow}>
                      {rel.isPending ? t("requested", lang) : rel.isFollowing ? t("following", lang) : t("follow", lang)}
                    </Button>
                  )}
                  <Button size="sm" variant="outline" onClick={startChat} disabled={rel.isBlockedByMe}>
                    <MessageCircle size={14} />
                  </Button>
                  {rel.friendshipStatus === null && (
                    <Button size="icon" variant="outline" onClick={() => friendAction("add")} aria-label={t("add_friend", lang)}>
                      <UserPlus size={14} />
                    </Button>
                  )}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button size="icon" variant="outline"><MoreHorizontal size={16} /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      {rel.friendshipStatus === "PENDING" && rel.friendshipRole === "ADDRESSEE" && (
                        <DropdownMenuItem onClick={() => friendAction("accept")}>{t("accept", lang)}</DropdownMenuItem>
                      )}
                      {rel.friendshipStatus && (
                        <DropdownMenuItem onClick={() => friendAction("reject")}>{lang === "ar" ? "إزالة الصداقة" : "Remove friend"}</DropdownMenuItem>
                      )}
                      <DropdownMenuItem onClick={toggleBlock}>
                        {rel.isBlockedByMe ? t("unblock", lang) : t("block", lang)}
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setReportOpen(true)}><Flag size={14} /> {t("report", lang)}</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </>
              )}
            </div>
          </div>

          <div className="mt-2">
            <h1 className="text-lg font-bold flex items-center gap-1.5 flex-wrap">
              {data.user.name}
              <VerifiedIcon show={data.user.isVerified} />
              {data.user.accountType !== "PERSONAL" && (
                <span className="text-[10px] bg-primary/10 text-primary rounded-full px-2 py-0.5 font-medium">
                  {t("pro_account", lang)}{data.user.professionalCategory ? ` · ${data.user.professionalCategory}` : ""}
                </span>
              )}
            </h1>
            <p className="text-sm text-muted-foreground">@{data.user.username}</p>
            {data.note && (
              <div className="mt-2 inline-block bg-primary/10 text-primary rounded-2xl rounded-ss-sm px-3 py-1.5 text-sm max-w-xs">
                {data.note}
              </div>
            )}
            {data.user.bio && <p className="text-sm mt-2 whitespace-pre-wrap">{data.user.bio}</p>}
            <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-muted-foreground">
              {data.user.location && <span className="flex items-center gap-1"><MapPin size={12} /> {data.user.location}</span>}
              {data.user.website && (
                <a href={data.user.website.startsWith("http") ? data.user.website : `https://${data.user.website}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-primary hover:underline">
                  <Link2 size={12} /> {data.user.website}
                </a>
              )}
            </div>
            <div className="flex gap-5 mt-3 text-sm">
              <span><b>{fmtNumber(data.counts.posts)}</b> <span className="text-muted-foreground">{t("posts_tab", lang)}</span></span>
              <button onClick={() => loadList("followers")} className="hover:underline">
                <b>{fmtNumber(data.counts.followers)}</b> <span className="text-muted-foreground">{t("followers_count", lang)}</span>
              </button>
              <button onClick={() => loadList("following")} className="hover:underline">
                <b>{fmtNumber(data.counts.following)}</b> <span className="text-muted-foreground">{t("following_count", lang)}</span>
              </button>
              {isSelf && (
                <span><b>{fmtNumber(data.counts.friends)}</b> <span className="text-muted-foreground">{t("friends", lang)}</span></span>
              )}
            </div>
          </div>
        </div>
      </div>

      {!rel.canSeeContent ? (
        <EmptyState icon={<Lock />} title={t("private_account_hint", lang)} sub={t("private_account_sub", lang)} />
      ) : (
        <Tabs defaultValue="posts" className="mt-5">
          <TabsList className={`w-full ${isSelf ? "" : ""}`}>
            <TabsTrigger value="posts" className="flex-1"><Grid3X3 size={15} /></TabsTrigger>
            <TabsTrigger value="reels" className="flex-1"><Clapperboard size={15} /></TabsTrigger>
            {isSelf && <TabsTrigger value="saved" className="flex-1"><Bookmark size={15} /></TabsTrigger>}
            {isSelf && <TabsTrigger value="friends" className="flex-1"><Users size={15} /></TabsTrigger>}
          </TabsList>
          <TabsContent value="posts" className="mt-3">
            {posts.length === 0 ? (
              <EmptyState icon={<Grid3X3 size={22} />} title={t("empty_feed_title", lang)} />
            ) : (
              <div className="grid grid-cols-3 gap-1.5">
                {posts.map((p) => {
                  const m = p.media[0];
                  return (
                    <div key={p.id} className="relative aspect-square rounded-lg overflow-hidden bg-muted">
                      {m ? (
                        m.type === "VIDEO" ? <video src={m.url} className="w-full h-full object-cover" preload="metadata" muted /> :
                        <img src={m.url} alt="post" className="w-full h-full object-cover" loading="lazy" />
                      ) : (
                        <span className="p-2 text-[11px] text-muted-foreground line-clamp-2-custom block">{p.content}</span>
                      )}
                      <span className="absolute bottom-1 start-1 text-[10px] text-white drop-shadow">♥ {fmtNumber(p.likeCount)}</span>
                    </div>
                  );
                })}
              </div>
            )}
          </TabsContent>
          <TabsContent value="reels" className="mt-3">
            {reels.length === 0 ? (
              <EmptyState icon={<Clapperboard size={22} />} title={t("reels", lang)} />
            ) : (
              <div className="grid grid-cols-3 gap-1.5">
                {reels.map((r) => (
                  <div key={r.id} className="relative aspect-[9/14] rounded-lg overflow-hidden bg-muted">
                    <video src={r.videoUrl} className="w-full h-full object-cover" preload="metadata" muted />
                    <span className="absolute bottom-1 start-1 text-[10px] text-white drop-shadow">♥ {fmtNumber(r.likeCount)}</span>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
          {isSelf && (
            <TabsContent value="saved" className="mt-3">
              {savedPosts.length === 0 ? (
                <EmptyState icon={<Bookmark size={22} />} title={t("saved_tab", lang)} sub={lang === "ar" ? "احفظ منشورات للرجوع إليها لاحقاً" : "Save posts to revisit later"} />
              ) : (
                savedPosts.map((p) => <PostCard key={p.id} post={p} />)
              )}
            </TabsContent>
          )}
          {isSelf && (
            <TabsContent value="friends" className="mt-3">
              {friends.length === 0 ? (
                <EmptyState icon={<Users size={22} />} title={t("no_friends_yet", lang)} />
              ) : (
                friends.map((u) => (
                  <UserRow key={u.id} user={u} onClick={() => navigate({ name: "profile", param: u.username })} />
                ))
              )}
            </TabsContent>
          )}
        </Tabs>
      )}

      <ReportDialog open={reportOpen} onOpenChange={setReportOpen} targetType="USER" targetId={data.user.id} />

      <Dialog open={!!listDialog} onOpenChange={(v) => !v && setListDialog(null)}>
        <DialogContent className="max-w-xs max-h-80 overflow-y-auto yem-scroll">
          <DialogHeader>
            <DialogTitle>{listDialog === "followers" ? t("followers_count", lang) : t("following_count", lang)}</DialogTitle>
          </DialogHeader>
          {listUsers.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">{t("no_results", lang)}</p>
          ) : (
            listUsers.map((u) => (
              <UserRow key={u.id} user={u} onClick={() => { setListDialog(null); navigate({ name: "profile", param: u.username }); }} />
            ))
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Lock() {
  return <span className="text-xl">🔒</span>;
}

/* ─────────────── edit profile dialog ─────────────── */

export function EditProfileDialog({ open, onOpenChange, onSaved }: { open: boolean; onOpenChange: (v: boolean) => void; onSaved?: () => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const setSession = useApp((s) => s.setSession);
  const [name, setName] = useState(me?.name || "");
  const [bio, setBio] = useState(me?.bio || "");
  const [location, setLocation] = useState(me?.location || "");
  const [website, setWebsite] = useState(me?.website || "");
  const [avatar, setAvatar] = useState(me?.avatarUrl || "");
  const [cover, setCover] = useState(me?.coverUrl || "");
  const [category, setCategory] = useState("");
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true);
    try {
      const res = await api.patch<{ user: PublicUser }>("/api/profile", {
        name, bio, location, website,
        avatarUrl: avatar || null,
        coverUrl: cover || null,
        accountType: me?.accountType,
        professionalCategory: category || null,
      });
      setSession({ user: { ...me!, ...res.user } });
      toast.success(t("save_changes", lang));
      onOpenChange(false);
      onSaved?.();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto yem-scroll">
        <DialogHeader><DialogTitle>{t("edit_profile", lang)}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <AvatarX user={{ name, avatarUrl: avatar }} size={56} />
            <ImagePickButton kind="avatar" label={t("avatar", lang)} onUploaded={setAvatar} />
            <ImagePickButton kind="cover" label={t("cover", lang)} onUploaded={setCover} />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">{t("full_name", lang)}</label>
            <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={50} />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-medium">{t("bio", lang)}</label>
            <Textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder={t("bio_ph", lang)} rows={3} maxLength={500} />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">{t("location", lang)}</label>
              <Input value={location} onChange={(e) => setLocation(e.target.value)} maxLength={120} />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">{t("website", lang)}</label>
              <Input dir="ltr" value={website} onChange={(e) => setWebsite(e.target.value)} maxLength={200} />
            </div>
          </div>
          {me?.accountType !== "PERSONAL" && (
            <div className="space-y-1.5">
              <label className="text-sm font-medium">{t("pro_category_ph", lang)}</label>
              <Input value={category} onChange={(e) => setCategory(e.target.value)} maxLength={60} />
            </div>
          )}
          <Button onClick={save} disabled={busy} className="w-full">{busy ? "..." : t("save_changes", lang)}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
