"use client";
/**
 * YEM360 — Explore (trending + suggested) / Search / Hashtag page.
 */
import { useCallback, useEffect, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, fmtNumber } from "@/lib/api-client";
import type { PostDTO, PublicUser, ProductDTO } from "@/lib/types";
import { PostCard, AdCard } from "./feed";
import { UserRow, EmptyState, Spinner, AvatarX, VerifiedIcon } from "./ui";
import { TrendingUp, Search as SearchIcon, Hash, Package, Users } from "lucide-react";
import type { AdDTO } from "@/lib/types";

/* ─────────────── explore ─────────────── */

export default function ExploreView() {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const [posts, setPosts] = useState<PostDTO[]>([]);
  const [hashtags, setHashtags] = useState<{ name: string; useCount: number }[]>([]);
  const [users, setUsers] = useState<PublicUser[]>([]);
  const [ads, setAds] = useState<AdDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [followState, setFollowState] = useState<Record<string, string | null>>({});

  useEffect(() => {
    Promise.all([
      api.get<{ trendingPosts: PostDTO[]; trendingHashtags: { name: string; useCount: number }[]; suggestedUsers: PublicUser[] }>("/api/explore"),
      api.get<{ ads: AdDTO[] }>("/api/ads/feed").catch(() => ({ ads: [] as AdDTO[] })),
    ])
      .then(([exp, adRes]) => {
        setPosts(exp.trendingPosts);
        setHashtags(exp.trendingHashtags);
        setUsers(exp.suggestedUsers);
        setFollowState(Object.fromEntries(exp.suggestedUsers.map((u) => [u.id, u.relationshipStatus ?? null])));
        setAds(adRes.ads);
      })
      .catch((e) => toast.error((e as Error).message))
      .finally(() => setLoading(false));
  }, []);

  async function followUser(u: PublicUser) {
    const current = followState[u.id] ?? null;
    try {
      if (current === "ACCEPTED" || current === "PENDING") {
        await api.del(`/api/follows/${u.username}`);
        setFollowState((s) => ({ ...s, [u.id]: null }));
      } else {
        const res = await api.post<{ status: string }>(`/api/follows/${u.username}`);
        setFollowState((s) => ({ ...s, [u.id]: res.status }));
        toast.success(res.status === "PENDING" ? t("requested", lang) : t("following", lang));
      }
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  if (loading) {
    return <div className="py-16 flex justify-center"><Spinner /></div>;
  }

  const hasMedia = (p: PostDTO) => p.media.length > 0 || p.repostOf?.media.length;

  return (
    <div className="mx-auto max-w-2xl px-3 py-4">
      {/* search box */}
      <button
        onClick={() => navigate({ name: "search" })}
        className="w-full flex items-center gap-2 h-10 rounded-full bg-muted px-4 text-sm text-muted-foreground mb-5 hover:bg-accent"
      >
        <SearchIcon size={16} /> {t("search_ph", lang)}
      </button>

      {/* trending hashtags */}
      {hashtags.length > 0 && (
        <div className="mb-5">
          <p className="font-semibold text-sm mb-2 flex items-center gap-1.5"><TrendingUp size={16} className="text-primary" /> {t("trending", lang)}</p>
          <div className="flex gap-2 flex-wrap">
            {hashtags.map((h) => (
              <button key={h.name} onClick={() => navigate({ name: "tag", param: h.name })} className="text-sm rounded-full bg-primary/10 text-primary px-3 py-1.5 hover:bg-primary/15">
                #{h.name} <span className="text-xs opacity-70">{fmtNumber(h.useCount)}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* suggested users */}
      {users.length > 0 && (
        <div className="mb-5 v8-card p-3">
          <p className="font-semibold text-sm mb-1 flex items-center gap-1.5"><Users size={16} className="text-primary" /> {t("suggested_users", lang)}</p>
          {users.map((u) => (
            <UserRow
              key={u.id}
              user={u}
              subtitle={u.followerCount ? `${fmtNumber(u.followerCount)} ${t("followers_count", lang)}` : undefined}
              onClick={() => navigate({ name: "profile", param: u.username })}
              action={
                <Button size="sm" variant={followState[u.id] ? "outline" : "default"} onClick={() => followUser(u)}>
                  {followState[u.id] === "PENDING" ? t("requested", lang) : followState[u.id] ? t("following", lang) : t("follow", lang)}
                </Button>
              }
            />
          ))}
        </div>
      )}

      {/* trending posts grid */}
      <p className="font-semibold text-sm mb-2">{t("for_you", lang)}</p>
      {posts.length === 0 ? (
        <EmptyState icon={<TrendingUp size={22} />} title={t("empty_feed_title", lang)} sub={t("empty_feed_sub", lang)} />
      ) : (
        <div className="grid grid-cols-3 gap-1">
          {posts.map((p) => {
            const m = p.media[0] || p.repostOf?.media[0];
            return (
              <button
                key={p.id}
                onClick={() => (m ? window.open(m.url, "_blank") : null)}
                className="relative aspect-square rounded-lg overflow-hidden bg-muted"
                title={p.content.slice(0, 80)}
              >
                {m ? (
                  m.type === "VIDEO" ? (
                    <video src={m.url} className="w-full h-full object-cover" preload="metadata" muted />
                  ) : (
                    <img src={m.url} alt={p.content.slice(0, 40) || "post"} className="w-full h-full object-cover" loading="lazy" />
                  )
                ) : (
                  <span className="p-2 text-[11px] text-muted-foreground line-clamp-2-custom block">{p.content}</span>
                )}
                <span className="absolute bottom-1 start-1 text-[10px] text-white drop-shadow flex items-center gap-1">
                  <AvatarX user={p.author} size={14} /> {p.author.username}
                </span>
                {hasMedia(p) ? <span className="absolute top-1 end-1 bg-black/40 rounded p-0.5 text-white text-[9px]">▶</span> : null}
              </button>
            );
          })}
        </div>
      )}

      {ads.length > 0 && (
        <div className="mt-5">
          {ads.map((ad) => <AdCard key={ad.id} ad={ad} />)}
        </div>
      )}
    </div>
  );
}

/* ─────────────── search ─────────────── */

export function SearchView() {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const [q, setQ] = useState("");
  const [users, setUsers] = useState<PublicUser[]>([]);
  const [posts, setPosts] = useState<PostDTO[]>([]);
  const [tags, setTags] = useState<{ name: string; useCount: number }[]>([]);
  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [loading, setLoading] = useState(false);
  const [followState, setFollowState] = useState<Record<string, string | null>>({});

  const doSearch = useCallback(async (query: string) => {
    if (!query.trim()) {
      setUsers([]); setPosts([]); setTags([]); setProducts([]);
      return;
    }
    setLoading(true);
    try {
      const res = await api.get<{ users: PublicUser[]; posts: PostDTO[]; hashtags: { name: string; useCount: number }[]; products: ProductDTO[] }>(
        `/api/search?q=${encodeURIComponent(query.trim())}`
      );
      setUsers(res.users);
      setPosts(res.posts);
      setTags(res.hashtags);
      setProducts(res.products);
      setFollowState(Object.fromEntries(res.users.map((u) => [u.id, u.relationshipStatus ?? null])));
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => doSearch(q), 350);
    return () => clearTimeout(timer);
  }, [q, doSearch]);

  async function followUser(u: PublicUser) {
    const current = followState[u.id] ?? null;
    try {
      if (current === "ACCEPTED" || current === "PENDING") {
        await api.del(`/api/follows/${u.username}`);
        setFollowState((s) => ({ ...s, [u.id]: null }));
      } else {
        const res = await api.post<{ status: string }>(`/api/follows/${u.username}`);
        setFollowState((s) => ({ ...s, [u.id]: res.status }));
      }
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-3 py-4">
      <div className="sticky top-14 bg-background z-10 pb-3">
        <div className="relative">
          <SearchIcon size={16} className="absolute start-3 top-3 text-muted-foreground" />
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("search_ph", lang)}
            className="ps-9 rounded-full h-10"
            autoFocus
          />
        </div>
      </div>

      {loading ? (
        <div className="py-12 flex justify-center"><Spinner /></div>
      ) : !q.trim() ? (
        <EmptyState icon={<SearchIcon size={22} />} title={t("search", lang)} sub={t("search_ph", lang)} />
      ) : (
        <Tabs defaultValue="people">
          <TabsList className="w-full">
            <TabsTrigger value="people" className="flex-1">{t("people", lang)} {users.length ? `(${users.length})` : ""}</TabsTrigger>
            <TabsTrigger value="posts" className="flex-1">{t("posts_tab", lang)} {posts.length ? `(${posts.length})` : ""}</TabsTrigger>
            <TabsTrigger value="tags" className="flex-1">{t("tags", lang)} {tags.length ? `(${tags.length})` : ""}</TabsTrigger>
            <TabsTrigger value="products" className="flex-1">{t("products_tab", lang)} {products.length ? `(${products.length})` : ""}</TabsTrigger>
          </TabsList>
          <TabsContent value="people" className="mt-3">
            {users.length === 0 ? <p className="text-sm text-muted-foreground py-6 text-center">{t("no_results", lang)}</p> : users.map((u) => (
              <UserRow
                key={u.id}
                user={u}
                subtitle={u.followerCount ? `${fmtNumber(u.followerCount)} ${t("followers_count", lang)}` : undefined}
                onClick={() => navigate({ name: "profile", param: u.username })}
                action={
                  <Button size="sm" variant={followState[u.id] ? "outline" : "default"} onClick={() => followUser(u)}>
                    {followState[u.id] === "PENDING" ? t("requested", lang) : followState[u.id] ? t("following", lang) : t("follow", lang)}
                  </Button>
                }
              />
            ))}
          </TabsContent>
          <TabsContent value="posts" className="mt-3">
            {posts.length === 0 ? <p className="text-sm text-muted-foreground py-6 text-center">{t("no_results", lang)}</p> : posts.map((p) => <PostCard key={p.id} post={p} />)}
          </TabsContent>
          <TabsContent value="tags" className="mt-3">
            {tags.length === 0 ? <p className="text-sm text-muted-foreground py-6 text-center">{t("no_results", lang)}</p> : tags.map((h) => (
              <button key={h.name} onClick={() => navigate({ name: "tag", param: h.name })} className="flex items-center gap-3 w-full py-3 px-1 hover:bg-muted rounded-xl">
                <span className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center"><Hash size={18} /></span>
                <span className="text-start">
                  <span className="block font-semibold text-sm">#{h.name}</span>
                  <span className="text-xs text-muted-foreground">{fmtNumber(h.useCount)} {t("posts_tab", lang)}</span>
                </span>
              </button>
            ))}
          </TabsContent>
          <TabsContent value="products" className="mt-3">
            {products.length === 0 ? <p className="text-sm text-muted-foreground py-6 text-center">{t("no_results", lang)}</p> : products.map((p) => (
              <button key={p.id} onClick={() => navigate({ name: "market" })} className="flex items-center gap-3 w-full py-2.5 px-1 hover:bg-muted rounded-xl">
                {p.images[0] ? <img src={p.images[0]} alt={p.title} className="w-11 h-11 rounded-lg object-cover" /> : <span className="w-11 h-11 rounded-lg bg-muted flex items-center justify-center"><Package size={18} /></span>}
                <span className="text-start flex-1 min-w-0">
                  <span className="block font-semibold text-sm truncate">{p.title}</span>
                  <span className="text-xs text-muted-foreground">{p.price} {p.currency} · @{p.seller.username}</span>
                </span>
              </button>
            ))}
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}

/* ─────────────── hashtag page ─────────────── */

export function TagView({ tag }: { tag: string }) {
  const lang = useApp((s) => s.lang);
  const [posts, setPosts] = useState<PostDTO[]>([]);
  const [info, setInfo] = useState<{ name: string; useCount: number } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const res = await api.get<{ tag: { name: string; useCount: number }; posts: PostDTO[] }>(`/api/tags/${encodeURIComponent(tag)}`);
        setPosts(res.posts);
        setInfo(res.tag);
      } catch (e) {
        toast.error((e as Error).message);
      } finally {
        setLoading(false);
      }
    })();
  }, [tag]);

  if (loading) return <div className="py-16 flex justify-center"><Spinner /></div>;

  return (
    <div className="mx-auto max-w-xl px-3 py-4">
      <div className="flex items-center gap-4 mb-5">
        <span className="w-16 h-16 rounded-full bg-primary/10 text-primary flex items-center justify-center"><Hash size={28} /></span>
        <div>
          <h1 className="text-xl font-bold">#{info?.name ?? tag}</h1>
          <p className="text-sm text-muted-foreground">{fmtNumber(info?.useCount ?? 0)} {t("posts_tab", lang)}</p>
        </div>
      </div>
      {posts.length === 0 ? (
        <EmptyState icon={<Hash size={22} />} title={t("no_results", lang)} />
      ) : (
        posts.map((p) => <PostCard key={p.id} post={p} />)
      )}
    </div>
  );
}
