"use client";
/**
 * YEM360 — PWA glue: service worker registration + "Install app" button.
 *
 * Renders a floating install button only when the browser fires
 * `beforeinstallprompt` (Chromium/Android/Windows). Once installed or when
 * already running standalone, the button disappears automatically.
 */
import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";

interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function PWA() {
  const lang = useApp((s) => s.lang);
  const [deferred, setDeferred] = useState<InstallPromptEvent | null>(null);
  const [standalone, setStandalone] = useState(false);

  useEffect(() => {
    // register service worker (production-quiet: ignore errors)
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => null);
    }

    setStandalone(
      window.matchMedia?.("(display-mode: standalone)").matches ||
        // iOS Safari standalone
        (navigator as Navigator & { standalone?: boolean }).standalone === true
    );

    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as InstallPromptEvent);
    };
    const onInstalled = () => {
      setDeferred(null);
      setStandalone(true);
      toast.success(t("installed", lang));
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, [lang]);

  if (!deferred || standalone) return null;

  async function install() {
    if (!deferred) return;
    try {
      await deferred.prompt();
      const { outcome } = await deferred.userChoice;
      if (outcome === "accepted") toast.success(t("installed", lang));
    } catch {
      // dismissed or failed — just hide the button
    }
    setDeferred(null);
  }

  return (
    <button
      onClick={install}
      title={t("install_hint", lang)}
      className="fixed bottom-16 start-4 z-50 flex items-center gap-2 rounded-full brand-gradient text-white text-sm font-semibold px-4 py-2.5 shadow-xl shadow-primary/30 hover:opacity-95 transition"
    >
      <Download size={16} />
      {t("install_app", lang)}
    </button>
  );
}
