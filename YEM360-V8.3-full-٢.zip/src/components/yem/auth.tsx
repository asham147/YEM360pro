"use client";
/**
 * YEM360 — Auth: login / register / 2FA challenge.
 * All flows call real endpoints; errors are surfaced via toasts.
 */
import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useApp } from "@/lib/store";
import { t, type Lang } from "@/lib/i18n";
import { api, ApiError } from "@/lib/api-client";
import { LogoMark } from "./providers";
import { APP_VERSION, APP_VERSION_LABEL } from "@/lib/version";
import { publicUserToStore } from "./auth-helpers";
import { toast } from "sonner";
import { Eye, EyeOff } from "lucide-react";

type Mode = "login" | "register" | "2fa";

export default function AuthView() {
  const lang = useApp((s) => s.lang);
  const setSession = useApp((s) => s.setSession);
  const [mode, setMode] = useState<Mode>("login");
  const [busy, setBusy] = useState(false);
  const [showPw, setShowPw] = useState(false);

  const [loginForm, setLoginForm] = useState({ identifier: "", password: "" });
  const [regForm, setRegForm] = useState({ name: "", username: "", email: "", password: "" });
  const [challengeToken, setChallengeToken] = useState("");
  const [code, setCode] = useState("");

  const pwScore = useMemo(() => {
    const p = regForm.password;
    if (!p) return 0;
    let s = 0;
    if (p.length >= 8) s++;
    if (p.length >= 12) s++;
    if (/[0-9]/.test(p) && /[a-zA-Z]/.test(p)) s++;
    if (/[^a-zA-Z0-9]/.test(p)) s++;
    return Math.min(s, 3);
  }, [regForm.password]);

  function done(user: PublicLike) {
    const mapped = publicUserToStore(user);
    setSession({ user: mapped, settings: null, privacy: null, counts: { unreadNotifications: 0, unreadMessages: 0 } });
  }

  async function handleLogin() {
    setBusy(true);
    try {
      const res = await api.post<{ user?: PublicLike; twoFactorRequired?: boolean; challengeToken?: string }>(
        "/api/auth/login",
        loginForm
      );
      if (res.twoFactorRequired && res.challengeToken) {
        setChallengeToken(res.challengeToken);
        setMode("2fa");
        return;
      }
      if (res.user) done(res.user);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function handleRegister() {
    setBusy(true);
    try {
      const res = await api.post<{ user: PublicLike }>("/api/auth/register", regForm);
      done(res.user);
      toast.success(lang === "ar" ? `أهلاً بك في YEM360 يا ${regForm.name}!` : `Welcome to YEM360, ${regForm.name}!`);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function handle2fa() {
    setBusy(true);
    try {
      const res = await api.post<{ user: PublicLike }>("/api/auth/verify-2fa", { challengeToken, code });
      done(res.user);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* brand panel */}
      <div className="brand-gradient text-white lg:flex-1 flex flex-col items-center justify-center gap-6 p-10 relative overflow-hidden">
        <div className="absolute -top-24 -end-24 w-72 h-72 rounded-full bg-gold/15 blur-3xl" aria-hidden />
        <div className="absolute -bottom-28 -start-20 w-80 h-80 rounded-full bg-gold/10 blur-3xl" aria-hidden />
        <div className="absolute top-1/3 start-1/4 w-56 h-56 rounded-full bg-white/8 blur-3xl" aria-hidden />
        <div className="absolute inset-0 yem-grid-pattern" aria-hidden />
        <LogoMark className="w-20 h-20 logo-aura relative" />
        <div className="text-center relative">
          <div className="flex items-center justify-center gap-2">
            <h1 className="text-4xl font-extrabold tracking-tight gold-text gold-shimmer-text">YEM360</h1>
            <span className="v8-chip !border-white/40 !bg-white/10 !text-white/90">{APP_VERSION}</span>
          </div>
          <p className="mt-2 text-white/85">{t("tagline", lang)}</p>
          <p className="mt-1 text-[11px] text-white/55">{APP_VERSION_LABEL}</p>
        </div>
        <div className="hidden lg:flex flex-col gap-3 mt-6 text-sm text-white/80 max-w-sm relative">
          {(lang === "ar"
            ? ["منشورات وقصص وريلز", "رسائل ومجموعات لحظية", "قنوات بث وملاحظات", "سوق وإعلانات واحصائيات", "أمان: تحقق ثنائي وجلسات وتشفير"]
            : ["Posts, stories & reels", "Realtime chats & groups", "Broadcast channels & notes", "Market, ads & insights", "Security: 2FA, sessions, encryption"]
          ).map((f) => (
            <p key={f} className="flex items-center gap-2"><span className="w-1.5 h-1.5 rounded-full bg-gold inline-block" />{f}</p>
          ))}
        </div>
        <p className="text-xs text-white/60 mt-8 relative">© 2026 YEM360</p>
      </div>

      {/* forms panel */}
      <div className="lg:w-[460px] flex items-center justify-center p-6 relative">
        <div className="yem-aurora !opacity-40" aria-hidden />
        <div className="w-full max-w-sm space-y-5 relative">
          {mode !== "2fa" && (
            <div className="text-center space-y-1">
              <h2 className="text-2xl font-bold">{mode === "login" ? t("welcome_back", lang) : t("register_sub", lang)}</h2>
              <p className="text-sm text-muted-foreground">
                {mode === "login" ? t("login_sub", lang) : t("register", lang)}
              </p>
            </div>
          )}

          {mode === "login" && (
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                handleLogin();
              }}
            >
              <div className="space-y-1.5">
                <Label htmlFor="identifier">{t("identifier_ph", lang)}</Label>
                <Input id="identifier" autoComplete="username" value={loginForm.identifier} onChange={(e) => setLoginForm({ ...loginForm, identifier: e.target.value })} required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="password">{t("password", lang)}</Label>
                <div className="relative">
                  <Input id="password" type={showPw ? "text" : "password"} autoComplete="current-password" value={loginForm.password} onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })} required />
                  <button type="button" aria-label="toggle password" className="absolute end-2 top-2 text-muted-foreground" onClick={() => setShowPw(!showPw)}>
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
              <Button type="submit" className="w-full brand-gradient border-0 text-white btn-shine" disabled={busy}>
                {busy ? "..." : t("login", lang)}
              </Button>
              <p className="text-sm text-center text-muted-foreground">
                <button type="button" className="text-primary hover:underline font-medium" onClick={() => setMode("register")}>
                  {t("no_account", lang)}
                </button>
              </p>
            </form>
          )}

          {mode === "register" && (
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                handleRegister();
              }}
            >
              <div className="space-y-1.5">
                <Label htmlFor="name">{t("full_name", lang)}</Label>
                <Input id="name" value={regForm.name} onChange={(e) => setRegForm({ ...regForm, name: e.target.value })} required maxLength={50} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="username">{t("username", lang)}</Label>
                <Input id="username" dir="ltr" value={regForm.username} onChange={(e) => setRegForm({ ...regForm, username: e.target.value.replace(/[^a-zA-Z0-9_]/g, "") })} required minLength={3} maxLength={20} placeholder="my_username" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="email">{t("email", lang)}</Label>
                <Input id="email" type="email" dir="ltr" value={regForm.email} onChange={(e) => setRegForm({ ...regForm, email: e.target.value })} required />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="rpassword">{t("password", lang)}</Label>
                <Input id="rpassword" type="password" dir="ltr" value={regForm.password} onChange={(e) => setRegForm({ ...regForm, password: e.target.value })} required minLength={8} />
                {regForm.password && (
                  <div className="flex items-center gap-2">
                    <div className="flex gap-1 flex-1">
                      {[0, 1, 2].map((i) => (
                        <span key={i} className={`h-1 flex-1 rounded-full ${pwScore > i ? (pwScore === 3 ? "bg-emerald-500" : pwScore === 2 ? "bg-amber-500" : "bg-red-400") : "bg-muted"}`} />
                      ))}
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {pwScore === 3 ? t("strong", lang) : pwScore === 2 ? t("medium", lang) : t("weak", lang)}
                    </span>
                  </div>
                )}
              </div>
              <Button type="submit" className="w-full brand-gradient border-0 text-white btn-shine" disabled={busy}>
                {busy ? "..." : t("register", lang)}
              </Button>
              <p className="text-sm text-center text-muted-foreground">
                <button type="button" className="text-primary hover:underline font-medium" onClick={() => setMode("login")}>
                  {t("have_account", lang)}
                </button>
              </p>
            </form>
          )}

          {mode === "2fa" && (
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                handle2fa();
              }}
            >
              <div className="text-center space-y-1">
                <h2 className="text-xl font-bold">{t("two_factor_title", lang)}</h2>
                <p className="text-sm text-muted-foreground">{t("two_factor_sub", lang)}</p>
              </div>
              <Input
                inputMode="numeric"
                dir="ltr"
                className="text-center text-2xl tracking-[0.4em] font-semibold h-14"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                maxLength={6}
                required
              />
              <Button type="submit" className="w-full" disabled={busy || code.length < 6}>
                {busy ? "..." : t("verify", lang)}
              </Button>
              <Button type="button" variant="ghost" className="w-full" onClick={() => setMode("login")}>
                {t("back", lang)}
              </Button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

interface PublicLike {
  id: string;
  username: string;
  name: string;
  accountType: string;
  isVerified: boolean;
  avatarUrl?: string | null;
  coverUrl?: string | null;
  bio?: string | null;
  role?: string;
  email?: string;
}
