"use client";
/**
 * YEM360 — Stories bar, story viewer, story creator, notes.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, uploadFileWithProgress, validateMediaFile, timeAgo } from "@/lib/api-client";
import type { StoryGroup, PublicUser } from "@/lib/types";
import { AvatarX, EmptyState, Spinner } from "./ui";
import { Plus, Eye, Trash2, Loader2, Pencil, X, Play, Pause, Volume2, VolumeX } from "lucide-react";

const BG_COLORS = [
  { key: "teal", css: "linear-gradient(135deg,#0F766E,#14B8A6)" },
  { key: "navy", css: "linear-gradient(135deg,#101A38,#27407E)" },
  { key: "gold", css: "linear-gradient(135deg,#A88420,#E9CE7A)" },
  { key: "amber", css: "linear-gradient(135deg,#B45309,#F59E0B)" },
  { key: "slate", css: "linear-gradient(135deg,#1E293B,#475569)" },
  { key: "rose", css: "linear-gradient(135deg,#9F1239,#FB7185)" },
];

/* ─────────────── stories bar ─────────────── */

export function StoriesBar({ onOpenCreate }: { onOpenCreate: () => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const navigate = useApp((s) => s.navigate);
  const [groups, setGroups] = useState<StoryGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewIdx, setViewIdx] = useState<number | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await api.get<{ groups: StoryGroup[] }>("/api/stories");
      setGroups(res.groups);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const iv = setInterval(load, 120_000);
    return () => clearInterval(iv);
  }, [load]);

  return (
    <div className="flex gap-3 overflow-x-auto yem-scroll pb-2 mb-1">
      {/* my story */}
      <div className="flex flex-col items-center gap-1 shrink-0 w-16">
        <button className="relative" onClick={onOpenCreate} aria-label={t("add_story", lang)}>
          <AvatarX user={me} size={56} />
          <span className="absolute -bottom-0.5 -end-0.5 w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center border-2 border-background">
            <Plus size={12} />
          </span>
        </button>
        <span className="text-[11px] text-muted-foreground truncate w-full text-center">{t("stories", lang)}</span>
      </div>

      {groups.map((g, i) => (
        <div key={g.user.id} className="flex flex-col items-center gap-1 shrink-0 w-16">
          <button onClick={() => setViewIdx(i)} className={g.hasUnseen ? "story-ring" : ""} aria-label={g.user.name}>
            <div className="p-0.5 bg-background rounded-full">
              <AvatarX user={g.user} size={54} />
            </div>
          </button>
          <span className="text-[11px] truncate w-full text-center text-foreground/80">@{g.user.username}</span>
        </div>
      ))}

      {loading && groups.length === 0 && (
        <div className="py-4"><Spinner /></div>
      )}

      {viewIdx !== null && groups[viewIdx] && (
        <StoryViewer
          group={groups[viewIdx]}
          onClose={() => {
            setViewIdx(null);
            load();
          }}
        />
      )}
    </div>
  );
}

/* ─────────────── story viewer ─────────────── */

function StoryViewer({ group, onClose }: { group: StoryGroup; onClose: () => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const navigate = useApp((s) => s.navigate);
  const [idx, setIdx] = useState(0);
  const [viewersOpen, setViewersOpen] = useState(false);
  const [viewers, setViewers] = useState<PublicUser[]>([]);
  const progressRef = useRef<HTMLDivElement>(null);
  const vidRef = useRef<HTMLVideoElement>(null);
  const [vidPct, setVidPct] = useState(0);
  const [paused, setPaused] = useState(false);
  const [mutedV, setMutedV] = useState(true);
  const [vidFailed, setVidFailed] = useState(false);
  const story = group.stories[idx];
  const isMine = group.user.id === me?.id;
  const isVideo = story?.type === "VIDEO";

  const goNext = useCallback(() => {
    if (idx < group.stories.length - 1) setIdx(idx + 1);
    else onClose();
  }, [idx, group.stories.length, onClose]);

  const goPrev = useCallback(() => {
    if (idx > 0) setIdx(idx - 1);
  }, [idx]);

  useEffect(() => {
    if (!story || isMine) return;
    api.post(`/api/stories/${story.id}/view`).catch(() => null);
  }, [story, isMine]);

  // reset per-story state
  useEffect(() => {
    setVidPct(0);
    setPaused(false);
    setVidFailed(false);
  }, [idx]);

  // IMAGE / TEXT (or failed video): fixed 5s/12s timer drives the progress bar
  useEffect(() => {
    if (!story) return;
    if (story.type === "VIDEO" && !vidFailed) return; // video drives itself
    const duration = vidFailed ? 12000 : 5000;
    const bar = progressRef.current;
    if (bar) {
      bar.style.animation = "none";
      void bar.offsetWidth;
      bar.style.animation = `story-progress ${duration}ms linear forwards`;
    }
    const timer = setTimeout(goNext, duration);
    return () => clearTimeout(timer);
  }, [idx, story, vidFailed, goNext]);

  function toggleVideo() {
    const v = vidRef.current;
    if (!v) return;
    if (v.paused) {
      v.play().catch(() => null);
      setPaused(false);
    } else {
      v.pause();
      setPaused(true);
    }
  }

  async function showViewers() {
    try {
      const res = await api.get<{ viewers: PublicUser[] }>(`/api/stories/${story.id}/viewers`);
      setViewers(res.viewers);
      setViewersOpen(true);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function deleteStory() {
    try {
      await api.del(`/api/stories/${story.id}`);
      toast.success(lang === "ar" ? "تم الحذف" : "Deleted");
      onClose();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  if (!story) return null;

  return (
    <div className="fixed inset-0 z-[80] bg-black/95 flex flex-col">
      {/* progress */}
      <div className="flex gap-1 px-3 pt-3">
        {group.stories.map((s, i) => (
          <div key={s.id} className="h-0.5 flex-1 bg-white/25 rounded-full overflow-hidden">
            {i === idx ? (
              isVideo && !vidFailed ? (
                <div className="h-full bg-white" style={{ width: `${vidPct}%` }} />
              ) : (
                <div ref={progressRef} className="h-full bg-white" />
              )
            ) : i < idx ? <div className="h-full bg-white" /> : null}
          </div>
        ))}
      </div>
      {/* header */}
      <div className="flex items-center gap-3 px-4 py-3 text-white">
        <button onClick={() => navigate({ name: "profile", param: group.user.username })}>
          <AvatarX user={group.user} size={38} />
        </button>
        <div className="flex-1">
          <p className="text-sm font-semibold">{group.user.name}</p>
          <p className="text-xs text-white/70">{timeAgo(story.createdAt, lang)}</p>
        </div>
        {isVideo && (
          <button onClick={() => setMutedV(!mutedV)} aria-label="mute" className="text-white/80 hover:text-white">
            {mutedV ? <VolumeX size={18} /> : <Volume2 size={18} />}
          </button>
        )}
        {isMine && (
          <>
            <button onClick={showViewers} className="flex items-center gap-1 text-sm text-white/80 hover:text-white" aria-label={t("viewers", lang)}>
              <Eye size={18} /> {story.viewCount}
            </button>
            <button onClick={deleteStory} aria-label={t("delete_story", lang)}>
              <Trash2 size={18} />
            </button>
          </>
        )}
        <button onClick={onClose} aria-label="close"><X size={22} /></button>
      </div>
      {/* content */}
      <div className="flex-1 relative flex items-center justify-center p-4">
        {story.type === "TEXT" ? (
          <div
            className="max-w-md w-full aspect-[9/14] rounded-2xl flex items-center justify-center p-8 text-white text-xl font-semibold text-center"
            style={{ background: BG_COLORS.find((c) => c.key === story.bgColor)?.css || BG_COLORS[0].css }}
            onClick={goNext}
          >
            {story.text}
          </div>
        ) : story.type === "VIDEO" ? (
          <video
            ref={vidRef}
            src={story.mediaUrl || ""}
            className="max-h-full max-w-full rounded-xl"
            autoPlay
            muted={mutedV}
            playsInline
            controls={false}
            onClick={toggleVideo}
            onTimeUpdate={() => {
              const v = vidRef.current;
              if (v && v.duration) setVidPct(Math.min(100, (v.currentTime / v.duration) * 100));
            }}
            onEnded={goNext}
            onError={() => setVidFailed(true)}
          />
        ) : (
          <img src={story.mediaUrl || ""} alt="story" className="max-h-full max-w-full rounded-xl object-contain" onClick={goNext} />
        )}
        {isVideo && paused && (
          <span className="pointer-events-none absolute text-white/90" aria-hidden><Play size={64} className="fill-white/90" /></span>
        )}
        {/* side navigation zones (RTL-aware via start/end) */}
        <button className="absolute inset-y-0 start-0 w-1/4" onClick={goPrev} aria-label="previous" />
        <button className="absolute inset-y-0 end-0 w-1/4" onClick={goNext} aria-label="next" />
      </div>
      {isMine && (
        <div className="text-center text-white/60 text-xs pb-4">{t("viewers", lang)}: {story.viewCount}</div>
      )}

      <Dialog open={viewersOpen} onOpenChange={setViewersOpen}>
        <DialogContent className="max-w-xs max-h-96 overflow-y-auto yem-scroll">
          <DialogHeader><DialogTitle>{t("viewers", lang)}</DialogTitle></DialogHeader>
          {viewers.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">{t("no_viewers", lang)}</p>
          ) : (
            viewers.map((v) => (
              <div key={v.id} className="flex items-center gap-3 py-1.5">
                <AvatarX user={v} size={32} />
                <p className="text-sm font-medium">{v.name}</p>
                <span className="text-xs text-muted-foreground">@{v.username}</span>
              </div>
            ))
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/* ─────────────── story creator ─────────────── */

export function StoryCreator({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  const lang = useApp((s) => s.lang);
  const [tab, setTab] = useState<"text" | "media">("text");
  const [text, setText] = useState("");
  const [bg, setBg] = useState(BG_COLORS[0].key);
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const fileRef = useRef<HTMLInputElement | null>(null);

  // revoke blob URLs to avoid memory leaks
  useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  function pick(f: File | null) {
    if (preview) URL.revokeObjectURL(preview);
    setPreview(null);
    if (!f) { setFile(null); return; }
    const err = validateMediaFile(f, lang);
    if (err) {
      toast.error(err);
      setFile(null);
      if (fileRef.current) fileRef.current.value = "";
      return;
    }
    setFile(f);
    setPreview(URL.createObjectURL(f)); // works for both image and video previews
  }

  async function submit() {
    if (busy) return;
    if (tab === "media") {
      if (!file) {
        toast.error(lang === "ar" ? "اختر صورة أو فيديو أولاً" : "Pick a photo or video first");
        return;
      }
      setBusy(true);
      setProgress(0);
      try {
        const { media } = await uploadFileWithProgress(file, "story", setProgress);
        await api.post("/api/stories", {
          type: media.type === "VIDEO" ? "VIDEO" : "IMAGE",
          mediaUrl: media.url,
        });
        toast.success(lang === "ar" ? "تم نشر القصة (تختفي بعد 24 ساعة)" : "Story published (24h)");
        pick(null);
        onOpenChange(false);
      } catch (e) {
        toast.error((e as Error).message);
      } finally {
        setBusy(false);
        setProgress(null);
      }
    } else {
      if (!text.trim()) {
        toast.error(lang === "ar" ? "اكتب نص القصة" : "Write your story");
        return;
      }
      setBusy(true);
      try {
        await api.post("/api/stories", { type: "TEXT", text: text.trim(), bgColor: bg });
        toast.success(lang === "ar" ? "تم نشر القصة (تختفي بعد 24 ساعة)" : "Story published (24h)");
        setText("");
        onOpenChange(false);
      } catch (e) {
        toast.error((e as Error).message);
      } finally {
        setBusy(false);
      }
    }
  }

  const isVideoFile = file?.type.startsWith("video/");
  const pct = progress ?? 0;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!busy) onOpenChange(v); }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{t("add_story", lang)}</DialogTitle>
        </DialogHeader>
        <div className="flex gap-2 mb-3">
          <Button variant={tab === "text" ? "default" : "outline"} size="sm" onClick={() => !busy && setTab("text")}>
            {lang === "ar" ? "نص" : "Text"}
          </Button>
          <Button variant={tab === "media" ? "default" : "outline"} size="sm" onClick={() => !busy && setTab("media")}>
            {lang === "ar" ? "صورة / فيديو" : "Photo / Video"}
          </Button>
        </div>

        {tab === "text" ? (
          <>
            <div className="rounded-2xl aspect-[3/4] max-h-72 w-full flex items-center justify-center p-6" style={{ background: BG_COLORS.find((c) => c.key === bg)?.css }}>
              <p className="text-white text-center text-lg font-semibold">{text || t("story_text_ph", lang)}</p>
            </div>
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={t("story_text_ph", lang)}
              rows={2}
              maxLength={280}
              disabled={busy}
              className="mt-3 w-full rounded-xl border bg-transparent p-3 text-sm outline-none focus:ring-1 focus:ring-ring"
            />
            <div className="flex items-center gap-2 mt-2">
              {BG_COLORS.map((c) => (
                <button
                  key={c.key}
                  onClick={() => setBg(c.key)}
                  className={`w-8 h-8 rounded-full ${bg === c.key ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""}`}
                  style={{ background: c.css }}
                  aria-label={c.key}
                />
              ))}
              <span className="text-[11px] text-muted-foreground ms-auto">{text.length}/280</span>
            </div>
          </>
        ) : (
          <>
            <button
              className="w-full aspect-[3/4] max-h-72 rounded-2xl bg-muted flex items-center justify-center overflow-hidden"
              onClick={() => fileRef.current?.click()}
              disabled={busy}
            >
              {preview && file ? (
                isVideoFile ? (
                  <video src={preview} className="w-full h-full object-cover" muted playsInline />
                ) : (
                  <img src={preview} alt="preview" className="w-full h-full object-cover" />
                )
              ) : (
                <span className="text-muted-foreground text-sm flex flex-col items-center gap-2">
                  <Plus size={26} /> {t("upload_image", lang)}
                </span>
              )}
            </button>
            {file && (
              <p className="text-xs text-muted-foreground mt-1.5 text-center">
                {file.name} · {(file.size / 1024 / 1024).toFixed(1)}MB
              </p>
            )}
            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm"
              className="hidden"
              onChange={(e) => pick(e.target.files?.[0] ?? null)}
            />
          </>
        )}

        {busy && progress !== null && (
          <div className="space-y-1 mt-2">
            <div className="h-2 rounded-full bg-muted overflow-hidden">
              <div className="h-full bg-primary upload-progress rounded-full" style={{ width: `${pct}%` }} />
            </div>
            <p className="text-xs text-muted-foreground text-center">
              {lang === "ar" ? `جاري الرفع... ${pct}%` : `Uploading... ${pct}%`}
            </p>
          </div>
        )}

        <Button onClick={submit} disabled={busy} className="w-full mt-3">
          {busy ? (
            progress !== null ? (
              <span className="flex items-center gap-2"><Loader2 size={16} className="animate-spin" /> {pct}%</span>
            ) : (
              <Loader2 size={16} className="animate-spin" />
            )
          ) : (
            t("publish_story", lang)
          )}
        </Button>
      </DialogContent>
    </Dialog>
  );
}

/* ─────────────── note (own) ─────────────── */

export function NoteComposer({ existing, onSaved }: { existing: string | null; onSaved: (n: string | null) => void }) {
  const lang = useApp((s) => s.lang);
  const [open, setOpen] = useState(false);
  const [text, setText] = useState(existing || "");
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true);
    try {
      if (text.trim()) {
        await api.post("/api/notes", { text: text.trim() });
        onSaved(text.trim());
      }
      setOpen(false);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    try {
      await api.del("/api/notes");
      onSaved(null);
      setOpen(false);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <>
      <button onClick={() => setOpen(true)} className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-primary" aria-label={t("add_note", lang)}>
        <Pencil size={13} />
        {existing ? `"${existing.slice(0, 24)}${existing.length > 24 ? "…" : ""}"` : t("add_note", lang)}
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xs">
          <DialogHeader><DialogTitle>{t("add_note", lang)}</DialogTitle></DialogHeader>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t("note_ph", lang)}
            rows={2}
            maxLength={160}
            className="w-full rounded-xl border bg-transparent p-3 text-sm outline-none focus:ring-1 focus:ring-ring"
          />
          <div className="flex gap-2 justify-between">
            {existing ? (
              <Button variant="ghost" size="sm" className="text-destructive" onClick={remove}>
                <Trash2 size={14} />
              </Button>
            ) : <span />}
            <Button size="sm" onClick={save} disabled={busy || !text.trim()}>
              {busy ? "..." : t("save_changes", lang)}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
