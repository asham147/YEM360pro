"use client";
/**
 * YEM360 — Broadcast channels: list, create, channel view, broadcast composer.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, timeAgo, fmtNumber } from "@/lib/api-client";
import { onSocketEvent } from "@/lib/socket";
import type { ChannelDTO, ChannelMessageDTO } from "@/lib/types";
import { AvatarX, EmptyState, Spinner, ImagePickButton } from "./ui";
import { Radio, Plus, Send, Loader2, Users } from "lucide-react";

export default function ChannelsView({ initialChannel }: { initialChannel?: string }) {
  const lang = useApp((s) => s.lang);
  const navigate = useApp((s) => s.navigate);
  const [owned, setOwned] = useState<ChannelDTO[]>([]);
  const [subscribed, setSubscribed] = useState<ChannelDTO[]>([]);
  const [discover, setDiscover] = useState<ChannelDTO[]>([]);
  const [active, setActive] = useState<ChannelDTO | null>(null);
  const [messages, setMessages] = useState<ChannelMessageDTO[]>([]);
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);

  const load = useCallback(async () => {
    try {
      const res = await api.get<{ owned: ChannelDTO[]; subscribed: ChannelDTO[]; discover: ChannelDTO[] }>("/api/channels");
      setOwned(res.owned);
      setSubscribed(res.subscribed);
      setDiscover(res.discover);
      if (initialChannel) {
        const c = [...res.owned, ...res.subscribed, ...res.discover].find((x) => x.id === initialChannel);
        if (c) openChannel(c);
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [initialChannel]);

  useEffect(() => {
    load();
    const off = onSocketEvent("channel:new", (data) => {
      const d = data as { channelId: string };
      if (d.channelId === active?.id) loadMessages(active.id);
      load();
    });
    return off;
  }, [load, active?.id]);

  const loadMessages = useCallback(async (channelId: string) => {
    try {
      const res = await api.get<{ channel: ChannelDTO; isSubscribed: boolean; messages: ChannelMessageDTO[] }>(`/api/channels/${channelId}`);
      setActive(res.channel);
      setIsSubscribed(res.isSubscribed);
      setMessages(res.messages);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }, []);

  function openChannel(c: ChannelDTO) {
    loadMessages(c.id);
  }

  async function subscribeToggle(channel: ChannelDTO) {
    try {
      if (isSubscribed) {
        await api.del(`/api/channels/${channel.id}/subscribe`);
        setIsSubscribed(false);
      } else {
        await api.post(`/api/channels/${channel.id}/subscribe`);
        setIsSubscribed(true);
        toast.success(t("subscribe", lang));
      }
      loadMessages(channel.id);
      load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  const ChannelRow = ({ c, showSub }: { c: ChannelDTO; showSub?: boolean }) => (
    <button
      onClick={() => openChannel(c)}
      className={`w-full flex items-center gap-3 p-3 rounded-xl text-start hover:bg-muted ${active?.id === c.id ? "bg-accent" : ""}`}
    >
      <span className="w-11 h-11 rounded-full brand-gradient text-white flex items-center justify-center shrink-0"><Radio size={20} /></span>
      <span className="flex-1 min-w-0">
        <span className="block font-semibold text-sm truncate">{c.name}</span>
        <span className="block text-xs text-muted-foreground truncate">@{c.handle} · {fmtNumber(c.subscriberCount)} {t("subscribers", lang)}</span>
      </span>
      {showSub && !c.isOwner && (
        <Button size="sm" variant="outline" onClick={(e) => { e.stopPropagation(); subscribeToggle(c); }}>{t("subscribe", lang)}</Button>
      )}
    </button>
  );

  return (
    <div className="flex h-[calc(100vh-3.5rem)]">
      <div className={`w-full md:w-80 border-e flex flex-col overflow-hidden ${active ? "hidden md:flex" : "flex"}`}>
        <div className="p-3 border-b flex items-center justify-between">
          <h1 className="font-bold flex items-center gap-2"><Radio size={18} className="text-primary" /> {t("channels", lang)}</h1>
          <Button size="icon" variant="ghost" onClick={() => setCreateOpen(true)} aria-label={t("create_channel", lang)}><Plus size={18} /></Button>
        </div>
        <div className="flex-1 overflow-y-auto yem-scroll p-2">
          {loading ? (
            <div className="py-10 flex justify-center"><Spinner /></div>
          ) : (
            <>
              {owned.length > 0 && <p className="text-xs font-semibold text-muted-foreground px-2 pt-2 pb-1">{t("my_channels", lang)}</p>}
              {owned.map((c) => <ChannelRow key={c.id} c={c} />)}
              {subscribed.length > 0 && <p className="text-xs font-semibold text-muted-foreground px-2 pt-3 pb-1">{t("subscribed_channels", lang)}</p>}
              {subscribed.map((c) => <ChannelRow key={c.id} c={c} />)}
              {discover.length > 0 && <p className="text-xs font-semibold text-muted-foreground px-2 pt-3 pb-1">{t("discover_channels", lang)}</p>}
              {discover.map((c) => <ChannelRow key={c.id} c={c} showSub />)}
              {owned.length + subscribed.length + discover.length === 0 && (
                <EmptyState icon={<Radio size={22} />} title={t("no_channels", lang)} />
              )}
            </>
          )}
        </div>
      </div>

      <div className={`flex-1 flex-col ${active ? "flex" : "hidden md:flex"}`}>
        {active ? (
          <ChannelView
            channel={active}
            messages={messages}
            isSubscribed={isSubscribed}
            onSubscribe={() => subscribeToggle(active)}
            onBack={() => setActive(null)}
            onReload={() => { loadMessages(active.id); load(); }}
            onNavigateProfile={(u) => navigate({ name: "profile", param: u })}
          />
        ) : (
          <EmptyState icon={<Radio size={22} />} title={t("channels", lang)} sub={lang === "ar" ? "قنوات بث باتجاه واحد من المالك للمشتركين" : "One-way broadcast channels"} />
        )}
      </div>

      <ChannelCreator open={createOpen} onOpenChange={setCreateOpen} onCreated={(id) => { setCreateOpen(false); load(); loadMessages(id); }} />
    </div>
  );
}

function ChannelView({
  channel, messages, isSubscribed, onSubscribe, onBack, onReload, onNavigateProfile,
}: {
  channel: ChannelDTO;
  messages: ChannelMessageDTO[];
  isSubscribed: boolean;
  onSubscribe: () => void;
  onBack: () => void;
  onReload: () => void;
  onNavigateProfile: (username: string) => void;
}) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const isOwner = channel.isOwner;

  useEffect(() => {
    requestAnimationFrame(() => bottomRef.current?.scrollIntoView({ behavior: "auto" }));
  }, [messages]);

  async function broadcast() {
    if (!text.trim()) return;
    setBusy(true);
    try {
      await api.post(`/api/channels/${channel.id}/messages`, { text: text.trim() });
      setText("");
      onReload();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="flex flex-col h-full">
      <header className="h-14 border-b flex items-center gap-3 px-3">
        <button onClick={onBack} className="md:hidden" aria-label="back">→</button>
        <span className="w-10 h-10 rounded-full brand-gradient text-white flex items-center justify-center"><Radio size={18} /></span>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm truncate">{channel.name}</p>
          <p className="text-xs text-muted-foreground">{fmtNumber(channel.subscriberCount)} {t("subscribers", lang)}</p>
        </div>
        {!isOwner && (
          <Button size="sm" variant={isSubscribed ? "outline" : "default"} onClick={onSubscribe}>
            {isSubscribed ? t("unsubscribe", lang) : t("subscribe", lang)}
          </Button>
        )}
      </header>

      <div className="flex-1 overflow-y-auto yem-scroll px-4 py-3 bg-muted/30">
        {messages.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground py-10">
            {lang === "ar" ? "لا بثّات بعد" : "No broadcasts yet"}
          </p>
        ) : (
          messages.map((m) => (
            <div key={m.id} className="mb-3 v8-card p-3.5 max-w-lg mx-auto">
              <button onClick={() => onNavigateProfile(m.sender.username)} className="flex items-center gap-2 mb-1">
                <AvatarX user={m.sender} size={22} />
                <span className="text-xs font-semibold">{m.sender.name}</span>
                <span className="text-[10px] text-muted-foreground">{timeAgo(m.createdAt, lang)}</span>
              </button>
              {m.mediaUrl && m.mediaUrl.match(/\.(mp4|webm)$/) ? (
                <video src={m.mediaUrl} controls className="max-h-60 rounded-lg mb-1" />
              ) : m.mediaUrl ? (
                <img src={m.mediaUrl} alt="broadcast" className="max-h-60 rounded-lg mb-1" />
              ) : null}
              <p className="text-sm whitespace-pre-wrap">{m.text}</p>
            </div>
          ))
        )}
        <div ref={bottomRef} />
      </div>

      {isOwner && (
        <div className="border-t p-2 flex items-end gap-2">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t("broadcast_ph", lang)}
            rows={1}
            maxLength={4000}
            className="flex-1 resize-none rounded-2xl"
          />
          <Button size="icon" className="h-10 w-10 rounded-full shrink-0" onClick={broadcast} disabled={busy || !text.trim()} aria-label={t("send", lang)}>
            {busy ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} className="scale-x-[-1]" />}
          </Button>
        </div>
      )}
      {!isOwner && (
        <div className="border-t p-2 text-center text-xs text-muted-foreground">
          {lang === "ar" ? "البث باتجاه واحد — من المالك فقط" : "One-way channel — owner broadcasts only"}
        </div>
      )}
    </div>
  );
}

function ChannelCreator({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (v: boolean) => void; onCreated: (id: string) => void }) {
  const lang = useApp((s) => s.lang);
  const [name, setName] = useState("");
  const [handle, setHandle] = useState("");
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);

  async function create() {
    setBusy(true);
    try {
      const res = await api.post<{ id: string }>("/api/channels", { name, handle, description: description || undefined });
      toast.success(lang === "ar" ? "تم إنشاء القناة" : "Channel created");
      setName(""); setHandle(""); setDescription("");
      onCreated(res.id);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xs">
        <DialogHeader><DialogTitle>{t("create_channel", lang)}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("channel_name", lang)} maxLength={50} />
          <Input dir="ltr" value={handle} onChange={(e) => setHandle(e.target.value.replace(/[^a-zA-Z0-9_]/g, ""))} placeholder={t("channel_handle", lang)} maxLength={20} />
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder={t("channel_desc", lang)} rows={2} maxLength={300} />
          <Button onClick={create} disabled={busy || !name || handle.length < 3} className="w-full">
            {busy ? <Loader2 size={15} className="animate-spin" /> : t("create_channel", lang)}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
