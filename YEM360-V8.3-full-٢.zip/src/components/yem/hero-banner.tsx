"use client";
/**
 * YEM360 — HeroBanner (V8.1 "المظهر المذهل"):
 * Sanaa Old City panorama (night in dark mode / day in light mode),
 * waving Yemen flag, brand tagline with gold swoosh, crowned user
 * avatar and a frosted "قصتك" story button.
 */
import { useEffect, useRef, useState } from "react";
import { useTheme } from "next-themes";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { AvatarX } from "./ui";
import { Crown, ChevronDown } from "lucide-react";

function YemenFlag({ className = "" }: { className?: string }) {
  return (
    <svg viewBox="0 0 78 56" className={className} aria-hidden>
      <defs>
        <linearGradient id="yem-pole" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#8A6D1F" />
          <stop offset="50%" stopColor="#E9CE7A" />
          <stop offset="100%" stopColor="#8A6D1F" />
        </linearGradient>
      </defs>
      {/* pole */}
      <rect x="2" y="1.5" width="2.6" height="53" rx="1.3" fill="url(#yem-pole)" />
      <circle cx="3.3" cy="1.8" r="1.6" fill="#E9CE7A" />
      {/* waving cloth — red / white / black */}
      <g className="yem-wave">
        <rect x="4.6" y="4.5" width="66" height="14.6" rx="1" fill="#CE1126" />
        <rect x="4.6" y="19.1" width="66" height="14.6" fill="#F7F7F7" />
        <rect x="4.6" y="33.7" width="66" height="14.6" rx="1" fill="#141414" />
      </g>
    </svg>
  );
}

export function HeroBanner({ onCreateStory }: { onCreateStory?: () => void }) {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const navigate = useApp((s) => s.navigate);
  const { resolvedTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);
  const dark = mounted && resolvedTheme === "dark";

  // spec §8: gentle hero parallax — the backdrop drifts at 12% of scroll speed
  const imgRef = useRef<HTMLImageElement | null>(null);
  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const el = imgRef.current;
        if (!el) return;
        const y = Math.min(window.scrollY, el.clientHeight);
        if (window.scrollY <= el.clientHeight) {
          el.style.transform = `translateY(${y * 0.12}px) scale(1.06)`;
        }
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  return (
    <section
      className="relative rounded-[1.6rem] overflow-hidden mb-4 border border-black/10 dark:border-white/10 shadow-[0_18px_50px_-20px_color-mix(in_srgb,#142B55_55%,transparent)] dark:shadow-[0_18px_50px_-20px_color-mix(in_srgb,#000_75%,transparent)]"
      aria-label={t("tagline", lang)}
    >
      {/* Sanaa scene — night for dark theme, day for light theme (parallax backdrop) */}
      <img
        ref={imgRef}
        src={dark ? "/brand/hero-night.png" : "/brand/hero-day.png"}
        alt=""
        className={`hero-parallax absolute -inset-y-4 inset-0 w-full h-[calc(100%+2rem)] object-cover transition-opacity duration-700 ${dark ? "object-[center_62%] brightness-[0.92]" : "object-top"}`}
        draggable={false}
      />
      {/* legibility scrim — gentle on the day scene, deep navy at night */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-black/5 to-transparent dark:from-[#0A1330]/85 dark:via-[#0A1330]/25 dark:to-[#0A1330]/40" />

      {/* content */}
      <div className="relative flex items-center gap-3 px-4 sm:px-6 py-5 min-h-44 sm:min-h-52">
        {/* crowned avatar (start side) + story chip */}
        <div className="flex flex-col items-center gap-2 shrink-0">
          <button
            onClick={() => navigate({ name: "profile", param: me?.username })}
            className="relative group"
            aria-label={t("profile", lang)}
          >
            <span className="block rounded-full p-[2.5px] bg-gradient-to-br from-[#E9CE7A] via-[#C9A227] to-[#8A6D1F] shadow-[0_0_18px_-2px_oklch(0.78_0.14_88/0.65)] group-hover:scale-105 transition-transform">
              <AvatarX user={me} size={58} />
            </span>
            <Crown
              size={22}
              className="absolute -top-3 left-1/2 -translate-x-1/2 text-[#E9CE7A] fill-[#C9A227]/70 drop-shadow-[0_2px_4px_oklch(0.2_0.05_265/0.6)]"
            />
            <span className="absolute bottom-0.5 end-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 border-2 border-background" aria-hidden />
          </button>
          <button onClick={onCreateStory} className="glass-chip" aria-label={t("stories", lang)}>
            {t("stories", lang)}
            <ChevronDown size={13} />
          </button>
        </div>

        {/* brand tagline (center) */}
        <div className="flex-1 text-center min-w-0 relative">
          {/* frosted backdrop for guaranteed readability */}
          <div
            aria-hidden
            className="absolute -inset-x-3 -inset-y-2.5 rounded-2xl bg-white/30 dark:bg-[#0A1330]/45 backdrop-blur-[3px]"
          />
          <p className="relative text-xl sm:text-[1.7rem] font-extrabold leading-tight text-[#0E1D45] dark:text-white drop-shadow-[0_1px_5px_oklch(1_0_0/0.55)] dark:drop-shadow-[0_2px_10px_oklch(0.15_0.05_265/0.75)]">
            {t("brand_world", lang)}
          </p>
          <p className="relative text-lg sm:text-2xl font-extrabold leading-snug gold-text gold-shimmer-text drop-shadow-[0_1px_3px_oklch(1_0_0/0.75)] dark:drop-shadow-[0_1px_6px_oklch(0.15_0.05_265/0.8)]">
            {t("brand_platform", lang)}
          </p>
          <svg viewBox="0 0 120 10" className="hero-swoosh mx-auto mt-1 w-24 sm:w-28 h-2.5" aria-hidden>
            <path
              d="M4 7 Q 60 -4 116 5"
              fill="none"
              stroke="url(#swoosh-g)"
              strokeWidth="2.6"
              strokeLinecap="round"
            />
            <defs>
              <linearGradient id="swoosh-g" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#C9A227" stopOpacity="0.1" />
                <stop offset="45%" stopColor="#E9CE7A" />
                <stop offset="100%" stopColor="#C9A227" stopOpacity="0.1" />
              </linearGradient>
            </defs>
          </svg>
        </div>

        {/* waving Yemen flag (end side) */}
        <div className="shrink-0 self-start">
          <YemenFlag className="w-12 sm:w-20 h-auto drop-shadow-[0_4px_10px_oklch(0.15_0.05_265/0.55)]" />
        </div>
      </div>
    </section>
  );
}
