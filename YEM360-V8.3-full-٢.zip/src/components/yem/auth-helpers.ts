"use client";
/** YEM360 — auth helper mapping */
import type { PublicUser } from "@/lib/types";

export function publicUserToStore(u: {
  id: string;
  username: string;
  name: string;
  accountType: string;
  isVerified: boolean;
  avatarUrl?: string | null;
  coverUrl?: string | null;
  bio?: string | null;
  role?: string;
  email?: string;
}): PublicUser {
  return {
    id: u.id,
    username: u.username,
    name: u.name,
    accountType: u.accountType,
    isVerified: u.isVerified,
    avatarUrl: u.avatarUrl ?? null,
    coverUrl: u.coverUrl ?? null,
    bio: u.bio ?? null,
    role: u.role,
    email: u.email,
  };
}
