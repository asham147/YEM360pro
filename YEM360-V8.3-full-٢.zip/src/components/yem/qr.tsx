"use client";
/**
 * 2FA QR fallback: the server generates the QR image (qrcode lib) at
 * /api/security/2fa/setup. If unavailable, we show the otpauth URL +
 * secret as copyable text (still fully functional with any authenticator).
 */
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Copy } from "lucide-react";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";

export function TwoFAFallback({ secret, otpauthUrl }: { secret: string; otpauthUrl: string }) {
  const lang = useApp((s) => s.lang);
  const [copied, setCopied] = useState<string | null>(null);

  function copy(text: string, label: string) {
    navigator.clipboard?.writeText(text).then(() => {
      setCopied(label);
      toast.success(t("link_copied", lang));
      window.setTimeout(() => setCopied(null), 1500);
    });
  }

  return (
    <div className="space-y-2 text-start">
      <div className="bg-muted rounded-xl p-3">
        <p className="text-[11px] text-muted-foreground mb-1">{lang === "ar" ? "الرابط (otpauth):" : "otpauth URL:"}</p>
        <code dir="ltr" className="text-[10px] break-all leading-relaxed block max-h-20 overflow-y-auto yem-scroll">{otpauthUrl}</code>
        <Button size="sm" variant="outline" className="mt-2 h-7 text-xs" onClick={() => copy(otpauthUrl, "url")}>
          <Copy size={12} /> {copied === "url" ? "✓" : lang === "ar" ? "نسخ الرابط" : "Copy URL"}
        </Button>
      </div>
      <div className="bg-muted rounded-xl p-3">
        <p className="text-[11px] text-muted-foreground mb-1">{lang === "ar" ? "المفتاح يدوياً (Base32):" : "Manual key (Base32):"}</p>
        <code dir="ltr" className="text-sm font-mono tracking-wider">{secret}</code>
        <Button size="sm" variant="outline" className="mt-2 h-7 text-xs" onClick={() => copy(secret, "secret")}>
          <Copy size={12} /> {copied === "secret" ? "✓" : lang === "ar" ? "نسخ المفتاح" : "Copy key"}
        </Button>
      </div>
    </div>
  );
}
