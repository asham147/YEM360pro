"use client";
/**
 * YEM360 — Settings: account, privacy, security (2FA + sessions + activity),
 * notifications, preferences, blocked users.
 */
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api } from "@/lib/api-client";
import type { SettingsDTO, PrivacyDTO, SessionDTO, SecurityEventDTO, PublicUser } from "@/lib/types";
import { UserRow, Spinner } from "./ui";
import { TwoFAFallback } from "./qr";
import {
  ShieldCheck, KeyRound, LogOut, Smartphone, Activity, Ban, Globe, Bell, Palette, Languages, MonitorSmartphone, Copy, Sparkles,
} from "lucide-react";
import { APP_VERSION, APP_VERSION_LABEL } from "@/lib/version";

function Section({ title, icon, children }: { title: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="v8-card p-4 mb-3">
      <p className="font-semibold text-sm mb-3 flex items-center gap-2">{icon}{title}</p>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Row({ label, desc, children }: { label: string; desc?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="min-w-0">
        <p className="text-sm font-medium">{label}</p>
        {desc && <p className="text-xs text-muted-foreground">{desc}</p>}
      </div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}

export default function SettingsView() {
  const lang = useApp((s) => s.lang);
  const setLang = useApp((s) => s.setLang);
  const setSession = useApp((s) => s.setSession);
  const me = useApp((s) => s.user);
  const settings = useApp((s) => s.settings);
  const privacy = useApp((s) => s.privacy);
  const [sessions, setSessions] = useState<SessionDTO[]>([]);
  const [events, setEvents] = useState<SecurityEventDTO[]>([]);
  const [twoFA, setTwoFA] = useState(me ? false : false);
  const [blocked, setBlocked] = useState<PublicUser[]>([]);
  const [passwordForm, setPasswordForm] = useState({ currentPassword: "", newPassword: "" });
  const [setup, setSetup] = useState<{ qrDataUrl: string; secret: string; otpauthUrl?: string } | null>(null);
  const [code, setCode] = useState("");
  const [disablePassword, setDisablePassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);

  const loadSecurity = useCallback(async () => {
    try {
      const [sec, sess] = await Promise.all([
        api.get<{ twoFactorEnabled: boolean; events: SecurityEventDTO[] }>("/api/security/events"),
        api.get<{ sessions: SessionDTO[] }>("/api/auth/sessions"),
      ]);
      setTwoFA(sec.twoFactorEnabled);
      setEvents(sec.events);
      setSessions(sess.sessions);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }, []);

  useEffect(() => {
    loadSecurity();
    api.get<{ blocked: { user: PublicUser }[] }>("/api/blocks")
      .then((r) => setBlocked(r.blocked.map((b) => b.user)))
      .catch(() => null);
  }, [loadSecurity]);

  async function patchSettings(patch: Record<string, unknown>) {
    try {
      const res = await api.patch<{ settings: SettingsDTO; privacy: PrivacyDTO }>("/api/settings", patch);
      setSession({ settings: res.settings, privacy: res.privacy });
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function changePassword() {
    if (!passwordForm.currentPassword || !passwordForm.newPassword) return;
    setBusy(true);
    try {
      await api.post("/api/auth/password", passwordForm);
      toast.success(lang === "ar" ? "تم تغيير كلمة المرور وإلغاء الجلسات الأخرى" : "Password changed, other sessions revoked");
      setPasswordForm({ currentPassword: "", newPassword: "" });
      loadSecurity();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function start2FA() {
    try {
      const res = await api.post<{ otpauthUrl: string; secret: string; qrDataUrl: string }>("/api/security/2fa/setup");
      setSetup({ qrDataUrl: res.qrDataUrl, secret: res.secret, otpauthUrl: res.otpauthUrl });
      setQrOpen(true);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function enable2FA() {
    try {
      await api.post("/api/security/2fa/enable", { code });
      toast.success(lang === "ar" ? "تم تفعيل التحقق الثنائي" : "2FA enabled");
      setQrOpen(false);
      setCode("");
      setSetup(null);
      loadSecurity();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function disable2FA() {
    if (!disablePassword) return;
    try {
      await api.post("/api/security/2fa/disable", { password: disablePassword });
      toast.success(lang === "ar" ? "تم إيقاف التحقق الثنائي" : "2FA disabled");
      setDisablePassword("");
      loadSecurity();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function revokeSession(id: string) {
    try {
      await api.del(`/api/auth/sessions/${id}`);
      loadSecurity();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function unblock(userId: string) {
    try {
      await api.del(`/api/blocks?userId=${userId}`);
      setBlocked((prev) => prev.filter((u) => u.id !== userId));
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div className="mx-auto max-w-2xl px-3 py-4">
      <h1 className="text-xl font-bold mb-4">{t("settings", lang)}</h1>

      <Tabs defaultValue="account">
        <TabsList className="w-full flex-wrap h-auto">
          <TabsTrigger value="account"><MonitorSmartphone size={14} className="ms-1" /> {t("account_settings", lang)}</TabsTrigger>
          <TabsTrigger value="privacy"><Globe size={14} className="ms-1" /> {t("privacy_settings", lang)}</TabsTrigger>
          <TabsTrigger value="security"><ShieldCheck size={14} className="ms-1" /> {t("security_settings", lang)}</TabsTrigger>
          <TabsTrigger value="notifications"><Bell size={14} className="ms-1" /></TabsTrigger>
          <TabsTrigger value="preferences"><Palette size={14} className="ms-1" /></TabsTrigger>
        </TabsList>

        {/* account */}
        <TabsContent value="account" className="mt-4">
          <Section title={t("change_password", lang)} icon={<KeyRound size={16} className="text-primary" />}>
            <div className="space-y-2">
              <Input type="password" dir="ltr" placeholder={t("current_password", lang)} value={passwordForm.currentPassword} onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })} />
              <Input type="password" dir="ltr" placeholder={t("new_password", lang)} value={passwordForm.newPassword} onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })} />
              <Button onClick={changePassword} disabled={busy || !passwordForm.currentPassword || !passwordForm.newPassword} className="w-full sm:w-auto">
                {t("change_password", lang)}
              </Button>
            </div>
          </Section>
          <Section title={t("email", lang)} icon={<Globe size={16} className="text-primary" />}>
            <Row label={me?.email || ""} desc={lang === "ar" ? "بريدك مسجّل ومشفّر في النظام" : "Your email is registered and hashed in logs"}>
              <Button variant="ghost" size="sm" onClick={() => { navigator.clipboard?.writeText(me?.email || ""); toast.success(t("link_copied", lang)); }}>
                <Copy size={14} />
              </Button>
            </Row>
          </Section>
        </TabsContent>

        {/* privacy */}
        <TabsContent value="privacy" className="mt-4">
          <Section title={t("privacy_settings", lang)} icon={<Globe size={16} className="text-primary" />}>
            <Row label={t("private_account", lang)} desc={t("private_account_desc", lang)}>
              <Switch checked={privacy?.privateAccount ?? false} onCheckedChange={(v) => patchSettings({ privateAccount: v })} />
            </Row>
            <Row label={t("show_online_status", lang)}>
              <Switch checked={privacy?.showOnlineStatus ?? true} onCheckedChange={(v) => patchSettings({ showOnlineStatus: v })} />
            </Row>
            <Row label={t("who_can_message", lang)}>
              <Select value={privacy?.whoCanMessage ?? "EVERYONE"} onValueChange={(v) => patchSettings({ whoCanMessage: v })}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="EVERYONE">{t("everyone", lang)}</SelectItem>
                  <SelectItem value="FOLLOWERS">{t("followers_only", lang)}</SelectItem>
                  <SelectItem value="NONE">{t("nobody", lang)}</SelectItem>
                </SelectContent>
              </Select>
            </Row>
            <Row label={t("story_privacy", lang)}>
              <Select value={privacy?.storyPrivacy ?? "FOLLOWERS"} onValueChange={(v) => patchSettings({ storyPrivacy: v })}>
                <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">{t("everyone", lang)}</SelectItem>
                  <SelectItem value="FOLLOWERS">{t("followers_only", lang)}</SelectItem>
                  <SelectItem value="NONE">{t("nobody", lang)}</SelectItem>
                </SelectContent>
              </Select>
            </Row>
          </Section>
          <Section title={t("blocked_users", lang)} icon={<Ban size={16} className="text-destructive" />}>
            {blocked.length === 0 ? (
              <p className="text-sm text-muted-foreground">{t("no_blocked", lang)}</p>
            ) : (
              blocked.map((u) => (
                <UserRow key={u.id} user={u} action={<Button size="sm" variant="outline" onClick={() => unblock(u.id)}>{t("unblock", lang)}</Button>} />
              ))
            )}
          </Section>
        </TabsContent>

        {/* security */}
        <TabsContent value="security" className="mt-4">
          <Section title={t("two_factor_auth", lang)} icon={<ShieldCheck size={16} className="text-primary" />}>
            <Row label={t("two_factor_auth", lang)} desc={t("two_factor_desc", lang)}>
              {twoFA ? (
                <div className="flex items-center gap-2">
                  <Input type="password" dir="ltr" placeholder={t("current_password", lang)} value={disablePassword} onChange={(e) => setDisablePassword(e.target.value)} className="w-36 h-8 text-xs" />
                  <Button size="sm" variant="destructive" onClick={disable2FA} disabled={!disablePassword}>{t("disable_2fa", lang)}</Button>
                </div>
              ) : (
                <Button size="sm" onClick={start2FA}>{t("enable_2fa", lang)}</Button>
              )}
            </Row>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <ShieldCheck size={12} className="text-primary" />
              {twoFA ? (lang === "ar" ? "حسابك محمي بطبقة التحقق الثنائي ✔" : "Your account is protected ✔") : (lang === "ar" ? "فعّل التحقق الثنائي لحماية أعلى" : "Enable 2FA for stronger protection")}
            </p>
          </Section>

          <Section title={t("active_sessions", lang)} icon={<Smartphone size={16} className="text-primary" />}>
            {sessions.map((s) => (
              <Row
                key={s.id}
                label={`${s.device || ""} · ${s.browser || ""} · ${s.os || ""}`}
                desc={`${s.ip || ""} — ${new Date(s.lastSeenAt).toLocaleString(lang === "ar" ? "ar" : "en")}${s.isCurrent ? ` — ${t("this_device", lang)}` : ""}`}
              >
                <Button size="sm" variant="outline" onClick={() => revokeSession(s.id)} disabled={s.isCurrent}>
                  <LogOut size={13} /> {t("revoke", lang)}
                </Button>
              </Row>
            ))}
          </Section>

          <Section title={t("security_activity", lang)} icon={<Activity size={16} className="text-primary" />}>
            <div className="max-h-72 overflow-y-auto yem-scroll space-y-1.5">
              {events.map((e) => (
                <div key={e.id} className="flex items-center justify-between text-xs bg-muted/50 rounded-lg px-3 py-2">
                  <span className="font-medium">{e.type}</span>
                  <span className="text-muted-foreground">{new Date(e.createdAt).toLocaleString(lang === "ar" ? "ar" : "en")}</span>
                </div>
              ))}
              {events.length === 0 && <p className="text-sm text-muted-foreground">—</p>}
            </div>
          </Section>
        </TabsContent>

        {/* notifications */}
        <TabsContent value="notifications" className="mt-4">
          <Section title={t("notification_settings", lang)} icon={<Bell size={16} className="text-primary" />}>
            <Row label={t("email_notify", lang)}><Switch checked={settings?.emailNotify ?? true} onCheckedChange={(v) => patchSettings({ emailNotify: v })} /></Row>
            <Row label={t("push_notify", lang)}><Switch checked={settings?.pushNotify ?? true} onCheckedChange={(v) => patchSettings({ pushNotify: v })} /></Row>
            <Row label={t("notify_likes", lang)}><Switch checked={settings?.notifyLikes ?? true} onCheckedChange={(v) => patchSettings({ notifyLikes: v })} /></Row>
            <Row label={t("notify_comments", lang)}><Switch checked={settings?.notifyComments ?? true} onCheckedChange={(v) => patchSettings({ notifyComments: v })} /></Row>
            <Row label={t("notify_follows", lang)}><Switch checked={settings?.notifyFollows ?? true} onCheckedChange={(v) => patchSettings({ notifyFollows: v })} /></Row>
            <Row label={t("notify_messages", lang)}><Switch checked={settings?.notifyMessages ?? true} onCheckedChange={(v) => patchSettings({ notifyMessages: v })} /></Row>
          </Section>
        </TabsContent>

        {/* preferences */}
        <TabsContent value="preferences" className="mt-4">
          <Section title={t("preferences", lang)} icon={<Palette size={16} className="text-primary" />}>
            <Row label={t("language", lang)}>
              <Select value={lang} onValueChange={(v) => setLang(v as "ar" | "en")}>
                <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ar"><Languages size={13} className="inline me-1" /> العربية (RTL)</SelectItem>
                  <SelectItem value="en"><Languages size={13} className="inline me-1" /> English (LTR)</SelectItem>
                </SelectContent>
              </Select>
            </Row>
            <Row label={t("theme", lang)}>
              <ThemeSelect />
            </Row>
          </Section>

          {/* V8 about block */}
          <Section title={t("about_app", lang)} icon={<Sparkles size={16} className="text-gold" />}>
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl brand-gradient flex items-center justify-center logo-aura shrink-0">
                <Sparkles size={20} className="text-gold" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-extrabold gold-text leading-none">YEM360</p>
                  <span className="v8-chip">{APP_VERSION}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-1">{t("tagline", lang)}</p>
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              {t("version_label", lang)}: <span className="font-semibold text-foreground">{APP_VERSION_LABEL}</span> · © 2026 YEM360
            </p>
          </Section>
        </TabsContent>
      </Tabs>

      {/* 2FA QR dialog */}
      <Dialog open={qrOpen} onOpenChange={setQrOpen}>
        <DialogContent className="max-w-xs text-center">
          <DialogHeader><DialogTitle>{t("two_factor_auth", lang)}</DialogTitle></DialogHeader>
          <p className="text-xs text-muted-foreground">{t("scan_qr", lang)}</p>
          {setup && (
            <div className="flex flex-col items-center gap-2">
              {setup.qrDataUrl ? (
                <img src={setup.qrDataUrl} alt="2FA QR" width={190} height={190} />
              ) : (
                <TwoFAFallback secret={setup.secret} otpauthUrl={setup.otpauthUrl || ""} />
              )}
              <Input
                inputMode="numeric"
                dir="ltr"
                className="text-center tracking-[0.3em] text-lg"
                value={code}
                onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder={t("enter_code", lang)}
                maxLength={6}
              />
              <Button onClick={enable2FA} disabled={code.length < 6} className="w-full">{t("enable_2fa", lang)}</Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ThemeSelect() {
  const lang = useApp((s) => s.lang);
  const { theme, setTheme } = useThemeSafe();
  return (
    <Select value={theme ?? "system"} onValueChange={setTheme}>
      <SelectTrigger className="w-36"><SelectValue /></SelectTrigger>
      <SelectContent>
        <SelectItem value="light">{t("theme_light", lang)}</SelectItem>
        <SelectItem value="dark">{t("theme_dark", lang)}</SelectItem>
        <SelectItem value="system">{t("theme_system", lang)}</SelectItem>
      </SelectContent>
    </Select>
  );
}

function useThemeSafe() {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const mod = require("next-themes") as typeof import("next-themes");
  return mod.useTheme();
}
