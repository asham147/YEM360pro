"use client";
/**
 * YEM360 — Admin panel: dashboard, reports queue, users, ads approvals,
 * banned words, backup download.
 */
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { api, fmtNumber } from "@/lib/api-client";
import type { ReportAdminDTO, PublicUser, AdDTO } from "@/lib/types";
import { AvatarX, EmptyState, Spinner, StatusBadge, VerifiedIcon } from "./ui";
import {
  ShieldCheck, Flag, Users, Megaphone, Ban, Download, Search, Loader2, Trash2, UserCheck, UserX, BadgeCheck,
} from "lucide-react";

export default function AdminView() {
  const lang = useApp((s) => s.lang);
  const [stats, setStats] = useState<Record<string, number> | null>(null);
  const [reports, setReports] = useState<ReportAdminDTO[]>([]);
  const [users, setUsers] = useState<PublicUser[]>([]);
  const [userQuery, setUserQuery] = useState("");
  const [ads, setAds] = useState<AdDTO[]>([]);
  const [words, setWords] = useState<{ id: string; word: string }[]>([]);
  const [newWord, setNewWord] = useState("");
  const [loading, setLoading] = useState(true);
  const me = useApp((s) => s.user);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [st, rp, adRes, w] = await Promise.all([
        api.get<{ stats: Record<string, number> }>("/api/admin/stats"),
        api.get<{ reports: ReportAdminDTO[] }>("/api/admin/reports?status=ALL"),
        api.get<{ ads: AdDTO[] }>("/api/admin/ads"),
        api.get<{ words: { id: string; word: string }[] }>("/api/admin/banned-words"),
      ]);
      setStats(st.stats);
      setReports(rp.reports.filter((r) => r.status === "PENDING"));
      setAds(adRes.ads);
      setWords(w.words);
      loadUsers("");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadUsers = useCallback(async (q: string) => {
    try {
      const res = await api.get<{ users: PublicUser[] }>(`/api/admin/users?q=${encodeURIComponent(q)}`);
      setUsers(res.users as PublicUser[]);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function reportAction(report: ReportAdminDTO, action: string) {
    try {
      await api.patch("/api/admin/reports", { reportId: report.id, action });
      toast.success(lang === "ar" ? "تم تنفيذ الإجراء" : "Done");
      load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function userAction(userId: string, action: string) {
    try {
      await api.patch("/api/admin/users", { userId, action });
      toast.success(lang === "ar" ? "تم تنفيذ الإجراء" : "Done");
      loadUsers(userQuery);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function adAction(adId: string, action: string) {
    try {
      await api.patch("/api/admin/ads", { adId, action });
      load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function addWord() {
    if (!newWord.trim()) return;
    try {
      await api.post("/api/admin/banned-words", { word: newWord.trim() });
      setNewWord("");
      const w = await api.get<{ words: { id: string; word: string }[] }>("/api/admin/banned-words");
      setWords(w.words);
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function removeWord(word: string) {
    try {
      await api.del(`/api/admin/banned-words?word=${encodeURIComponent(word)}`);
      setWords((prev) => prev.filter((w) => w.word !== word));
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  if (loading) return <div className="py-16 flex justify-center"><Spinner /></div>;

  const KPI = ({ label, value, icon }: { label: string; value: number; icon: React.ReactNode }) => (
    <div className="v8-card p-4">
      <p className="text-xs text-muted-foreground flex items-center gap-1.5">{icon} {label}</p>
      <p className="text-2xl font-bold mt-1">{fmtNumber(value)}</p>
    </div>
  );

  return (
    <div className="mx-auto max-w-3xl px-3 py-4">
      <h1 className="text-xl font-bold flex items-center gap-2 mb-4">
        <ShieldCheck size={20} className="text-primary" /> {t("dashboard", lang)}
      </h1>

      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          <KPI label={t("total_users", lang)} value={stats.users} icon={<Users size={13} />} />
          <KPI label={t("total_posts", lang)} value={stats.posts} icon={<Flag size={13} />} />
          <KPI label={t("total_messages_today", lang)} value={stats.messagesToday} icon={<Megaphone size={13} />} />
          <KPI label={t("pending_reports", lang)} value={stats.reportsPending} icon={<Flag size={13} />} />
        </div>
      )}

      <Tabs defaultValue="reports">
        <TabsList className="w-full flex-wrap h-auto">
          <TabsTrigger value="reports">{t("reports_queue", lang)} {reports.length ? `(${reports.length})` : ""}</TabsTrigger>
          <TabsTrigger value="users">{t("users_management", lang)}</TabsTrigger>
          <TabsTrigger value="ads">{t("ads_approvals", lang)}</TabsTrigger>
          <TabsTrigger value="words">{t("banned_words_mgmt", lang)}</TabsTrigger>
        </TabsList>

        <TabsContent value="reports" className="mt-4 space-y-3">
          {reports.length === 0 ? (
            <EmptyState icon={<Flag size={22} />} title={t("pending_reports", lang)} sub={lang === "ar" ? "لا بلاغات معلقة" : "Nothing pending"} />
          ) : (
            reports.map((r) => (
              <div key={r.id} className="v8-card p-4">
                <div className="flex items-center gap-2 flex-wrap mb-2">
                  <Badge variant="destructive">{r.reason}</Badge>
                  <Badge variant="outline">{r.targetType}</Badge>
                  <span className="text-xs text-muted-foreground">@{r.reporter?.username}</span>
                  <span className="text-xs text-muted-foreground">{new Date(r.createdAt).toLocaleString(lang === "ar" ? "ar" : "en")}</span>
                </div>
                <div className="bg-muted rounded-lg p-2.5 text-xs whitespace-pre-wrap max-h-24 overflow-y-auto yem-scroll">
                  {JSON.stringify(r.target, null, 1)?.slice(0, 400)}
                </div>
                {r.details && <p className="text-xs text-muted-foreground mt-1">{r.details}</p>}
                <div className="flex gap-2 mt-3 flex-wrap">
                  <Button size="sm" variant="outline" onClick={() => reportAction(r, "DISMISS")}>{t("dismiss", lang)}</Button>
                  <Button size="sm" variant="secondary" onClick={() => reportAction(r, "DELETE_CONTENT")}>{t("delete_content", lang)}</Button>
                  <Button size="sm" variant="destructive" onClick={() => reportAction(r, "BAN_USER")}>{t("ban_owner", lang)}</Button>
                </div>
              </div>
            ))
          )}
        </TabsContent>

        <TabsContent value="users" className="mt-4">
          <div className="relative mb-3">
            <Search size={15} className="absolute start-3 top-2.5 text-muted-foreground" />
            <Input value={userQuery} onChange={(e) => { setUserQuery(e.target.value); loadUsers(e.target.value); }} placeholder={t("search_ph", lang)} className="ps-9" />
          </div>
          <div className="space-y-2">
            {users.map((u) => {
              const u2 = u as PublicUser & { isActive?: boolean; banReason?: string };
              return (
                <div key={u.id} className="bg-card border rounded-xl p-3 flex items-center gap-3">
                  <AvatarX user={u} size={40} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold flex items-center gap-1">
                      {u.name} <VerifiedIcon show={u.isVerified} />
                      {u2.isActive === false && <Badge variant="destructive">{t("ban_user", lang)}</Badge>}
                      {u.role === "ADMIN" && <Badge variant="outline">ADMIN</Badge>}
                      {u.role === "MODERATOR" && <Badge variant="outline">MOD</Badge>}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">@{u.username} · {u.email}</p>
                  </div>
                  <div className="flex gap-1.5 flex-wrap">
                    {u2.isActive === false ? (
                      <Button size="sm" variant="outline" onClick={() => userAction(u.id, "UNBAN")}><UserCheck size={13} /></Button>
                    ) : (
                      <Button size="sm" variant="destructive" onClick={() => userAction(u.id, "BAN")}><UserX size={13} /></Button>
                    )}
                    {me?.role === "ADMIN" && (
                      <>
                        <Button size="sm" variant="outline" onClick={() => userAction(u.id, u.isVerified ? "UNVERIFY" : "VERIFY")}><BadgeCheck size={13} /></Button>
                        <Button size="sm" variant="outline" onClick={() => userAction(u.id, u.role === "MODERATOR" ? "REMOVE_MOD" : "MAKE_MOD")}>
                          {u.role === "MODERATOR" ? "−MOD" : "+MOD"}
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="ads" className="mt-4 space-y-3">
          {ads.length === 0 ? (
            <EmptyState icon={<Megaphone size={22} />} title={t("ads_approvals", lang)} />
          ) : (
            ads.map((ad) => (
              <div key={ad.id} className="bg-card border rounded-xl p-3 flex items-center gap-3">
                {ad.imageUrl ? <img src={ad.imageUrl} alt={ad.title} className="w-12 h-12 rounded-lg object-cover" /> : <span className="w-12 h-12 rounded-lg brand-gradient flex items-center justify-center text-white"><Megaphone size={18} /></span>}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{ad.title}</p>
                  <p className="text-xs text-muted-foreground truncate">@{ad.advertiser?.username} · {fmtNumber(ad.impressionCount || 0)} {t("impressions", lang)}</p>
                </div>
                <StatusBadge status={ad.status || "PENDING"} lang={lang} />
                <div className="flex gap-1.5">
                  {ad.status === "PENDING" && (
                    <>
                      <Button size="sm" onClick={() => adAction(ad.id, "APPROVE")}>{t("approve", lang)}</Button>
                      <Button size="sm" variant="destructive" onClick={() => adAction(ad.id, "REJECT")}>{t("reject_ad", lang)}</Button>
                    </>
                  )}
                  {ad.status === "ACTIVE" && (
                    <Button size="sm" variant="outline" onClick={() => adAction(ad.id, "END")}>{t("status_ENDED", lang)}</Button>
                  )}
                </div>
              </div>
            ))
          )}
        </TabsContent>

        <TabsContent value="words" className="mt-4">
          {me?.role !== "ADMIN" ? (
            <p className="text-sm text-muted-foreground">{lang === "ar" ? "عرض فقط — التعديل للمدير" : "Read-only — admin only"}</p>
          ) : (
            <div className="flex gap-2 mb-3">
              <Input value={newWord} onChange={(e) => setNewWord(e.target.value)} placeholder={t("add_word", lang)} maxLength={40} />
              <Button onClick={addWord} disabled={!newWord.trim()}>{lang === "ar" ? "إضافة" : "Add"}</Button>
            </div>
          )}
          <div className="flex flex-wrap gap-2">
            {words.map((w) => (
              <span key={w.id} className="flex items-center gap-1 bg-muted rounded-full px-3 py-1.5 text-sm">
                {w.word}
                {me?.role === "ADMIN" && (
                  <button onClick={() => removeWord(w.word)} className="text-destructive" aria-label="remove"><Trash2 size={12} /></button>
                )}
              </span>
            ))}
            {words.length === 0 && <p className="text-sm text-muted-foreground">—</p>}
          </div>
          {me?.role === "ADMIN" && (
            <Button
              variant="outline"
              className="mt-5 gap-2"
              onClick={() => window.open("/api/admin/backup", "_blank")}
            >
              <Download size={15} /> {t("backup_download", lang)}
            </Button>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
