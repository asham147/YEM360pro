"use client";
/**
 * YEM360 — Market: product listing, create, detail + order, my orders/sales.
 */
import { useCallback, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { useApp } from "@/lib/store";
import { t, PRODUCT_CATEGORIES } from "@/lib/i18n";
import { api, uploadFile, timeAgo, fmtNumber } from "@/lib/api-client";
import type { ProductDTO, OrderDTO } from "@/lib/types";
import { AvatarX, EmptyState, Spinner, ImagePickButton, StatusBadge, UserRow } from "./ui";
import { Package, Plus, ShoppingCart, Store, Loader2, Eye, MessageCircle, Trash2 } from "lucide-react";

export default function MarketView() {
  const lang = useApp((s) => s.lang);
  const me = useApp((s) => s.user);
  const navigate = useApp((s) => s.navigate);
  const [tab, setTab] = useState<"browse" | "mine" | "orders">("browse");
  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [mine, setMine] = useState<ProductDTO[]>([]);
  const [orders, setOrders] = useState<OrderDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [category, setCategory] = useState("ALL");
  const [createOpen, setCreateOpen] = useState(false);
  const [detail, setDetail] = useState<ProductDTO | null>(null);
  const [orderOpen, setOrderOpen] = useState(false);
  const [orderForm, setOrderForm] = useState({ quantity: 1, address: "", phone: "", note: "" });
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (q.trim()) params.set("q", q.trim());
      if (category !== "ALL") params.set("category", category);
      const [browseRes, mineRes, ordersRes] = await Promise.all([
        api.get<{ products: ProductDTO[] }>(`/api/products?${params.toString()}`),
        api.get<{ products: ProductDTO[] }>("/api/products?mine=1"),
        api.get<{ orders: OrderDTO[] }>("/api/orders?type=bought"),
      ]);
      setProducts(browseRes.products);
      setMine(mineRes.products);
      setOrders(ordersRes.orders);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [q, category]);

  useEffect(() => {
    const timer = setTimeout(load, 250);
    return () => clearTimeout(timer);
  }, [load]);

  async function placeOrder() {
    if (!detail) return;
    setBusy(true);
    try {
      await api.post("/api/orders", { productId: detail.id, ...orderForm });
      toast.success(lang === "ar" ? "تم إنشاء الطلب — الدفع عند الاستلام" : "Order placed — cash on delivery");
      setOrderOpen(false);
      setDetail(null);
      load();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  async function updateOrderStatus(order: OrderDTO, status: string) {
    try {
      await api.patch(`/api/orders/${order.id}`, { status });
      load();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  function ProductCard({ p }: { p: ProductDTO }) {
    return (
      <button
        onClick={async () => {
          const res = await api.get<{ product: ProductDTO }>(`/api/products/${p.id}`);
          setDetail(res.product);
        }}
        className="v8-card overflow-hidden text-start"
      >
        {p.images[0] ? (
          <img src={p.images[0]} alt={p.title} className="w-full aspect-square object-cover" loading="lazy" />
        ) : (
          <div className="w-full aspect-square bg-muted flex items-center justify-center text-muted-foreground"><Package size={30} /></div>
        )}
        <div className="p-3">
          <p className="font-semibold text-sm truncate">{p.title}</p>
          <p className="text-primary font-bold text-sm mt-0.5">{fmtNumber(p.price)} {p.currency}</p>
          <div className="flex items-center gap-1.5 mt-1.5">
            <AvatarX user={p.seller} size={18} />
            <span className="text-xs text-muted-foreground truncate">@{p.seller.username}</span>
            {p.isMine && <StatusBadge status={p.status} lang={lang} />}
          </div>
        </div>
      </button>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-3 py-4">
      <div className="flex items-center justify-between mb-3">
        <h1 className="text-xl font-bold flex items-center gap-2"><Store size={20} className="text-primary" /> {t("market", lang)}</h1>
        <Button size="sm" onClick={() => setCreateOpen(true)}><Plus size={15} /> {t("add_product", lang)}</Button>
      </div>

      <div className="flex gap-2 mb-4">
        <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search", lang)} className="flex-1" />
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">{lang === "ar" ? "كل التصنيفات" : "All categories"}</SelectItem>
            {PRODUCT_CATEGORIES.map((c) => (
              <SelectItem key={c.key} value={c.key}>{c[lang]}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
        <TabsList className="w-full">
          <TabsTrigger value="browse" className="flex-1">{t("market", lang)}</TabsTrigger>
          <TabsTrigger value="mine" className="flex-1">{t("my_products", lang)}</TabsTrigger>
          <TabsTrigger value="orders" className="flex-1">{t("orders", lang)}</TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="mt-4">
          {loading && products.length === 0 ? (
            <div className="py-12 flex justify-center"><Spinner /></div>
          ) : products.length === 0 ? (
            <EmptyState icon={<Package size={22} />} title={t("empty_market", lang)} />
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {products.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="mine" className="mt-4">
          {mine.length === 0 ? (
            <EmptyState icon={<Store size={22} />} title={t("my_products", lang)} sub={lang === "ar" ? "أضف أول منتج للبيع" : "List your first product"} />
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {mine.map((p) => <ProductCard key={p.id} p={p} />)}
            </div>
          )}
        </TabsContent>

        <TabsContent value="orders" className="mt-4">
          {orders.length === 0 ? (
            <EmptyState icon={<ShoppingCart size={22} />} title={t("my_orders", lang)} />
          ) : (
            <div className="space-y-2">
              {orders.map((o) => (
                <div key={o.id} className="bg-card border rounded-xl p-3 flex items-center gap-3">
                  {o.product.image ? <img src={o.product.image} alt={o.product.title} className="w-12 h-12 rounded-lg object-cover" /> : <span className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center"><Package size={18} /></span>}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold truncate">{o.product.title}</p>
                    <p className="text-xs text-muted-foreground">
                      {o.quantity} × {fmtNumber(o.product.price)} {o.product.currency} = <b className="text-foreground">{fmtNumber(o.totalPrice)} {o.product.currency}</b> · {timeAgo(o.createdAt, lang)}
                    </p>
                    <p className="text-xs text-muted-foreground">@{o.counterpart.username}</p>
                  </div>
                  <StatusBadge status={o.status} lang={lang} />
                </div>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* product detail */}
      <Dialog open={!!detail} onOpenChange={(v) => !v && setDetail(null)}>
        <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto yem-scroll">
          {detail && (
            <>
              <DialogHeader>
                <DialogTitle>{detail.title}</DialogTitle>
              </DialogHeader>
              <div className="flex gap-2 overflow-x-auto yem-scroll">
                {(detail.images.length ? detail.images : [null]).map((img, i) => (
                  <div key={i} className="w-40 h-40 rounded-xl bg-muted overflow-hidden shrink-0">
                    {img ? <img src={img} alt={`${detail.title}-${i}`} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-muted-foreground"><Package size={26} /></div>}
                  </div>
                ))}
              </div>
              <p className="text-primary font-bold text-lg">{fmtNumber(detail.price)} {detail.currency} · <span className="text-xs text-muted-foreground font-normal">{t("cod_note", lang)}</span></p>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{detail.description}</p>
              <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><Eye size={12} /> {fmtNumber(detail.viewCount)}</span>
                <span>{t("category", lang)}: {PRODUCT_CATEGORIES.find((c) => c.key === detail.category)?.[lang] || "—"}</span>
                <span>{t("stock", lang)}: {detail.stock}</span>
                <span>{timeAgo(detail.createdAt, lang)}</span>
              </div>
              <UserRow
                user={detail.seller}
                onClick={() => navigate({ name: "profile", param: detail.seller.username })}
                action={
                  <Button size="sm" variant="outline" onClick={async () => {
                    const res = await api.post<{ conversationId: string }>("/api/messages/conversations", { type: "DIRECT", userId: detail.seller.id });
                    navigate({ name: "messages", param: res.conversationId });
                  }}>
                    <MessageCircle size={14} />
                  </Button>
                }
              />
              {!detail.isMine && detail.status === "AVAILABLE" && detail.stock > 0 && (
                <Button onClick={() => setOrderOpen(true)} className="w-full"><ShoppingCart size={15} /> {t("buy_now", lang)}</Button>
              )}
              {detail.isMine && (
                <Button
                  variant="destructive"
                  className="w-full"
                  onClick={async () => {
                    await api.del(`/api/products/${detail.id}`);
                    setDetail(null);
                    load();
                  }}
                >
                  <Trash2 size={15} /> {t("delete", lang)}
                </Button>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* order form */}
      <Dialog open={orderOpen} onOpenChange={setOrderOpen}>
        <DialogContent className="max-w-xs">
          <DialogHeader><DialogTitle>{t("confirm_order", lang)}</DialogTitle></DialogHeader>
          {detail && (
            <div className="space-y-3">
              <p className="text-sm">{detail.title} — <b>{fmtNumber(detail.price * orderForm.quantity)} {detail.currency}</b></p>
              <Input type="number" min={1} max={detail.stock} value={orderForm.quantity} onChange={(e) => setOrderForm({ ...orderForm, quantity: Math.max(1, Math.min(Number(e.target.value) || 1, detail.stock)) })} placeholder={t("quantity", lang)} />
              <Input value={orderForm.address} onChange={(e) => setOrderForm({ ...orderForm, address: e.target.value })} placeholder={t("address", lang)} maxLength={300} />
              <Input dir="ltr" value={orderForm.phone} onChange={(e) => setOrderForm({ ...orderForm, phone: e.target.value })} placeholder={t("phone", lang)} maxLength={20} />
              <Textarea value={orderForm.note} onChange={(e) => setOrderForm({ ...orderForm, note: e.target.value })} placeholder={t("order_note", lang)} rows={2} maxLength={300} />
              <Button onClick={placeOrder} disabled={busy || !orderForm.address || !orderForm.phone} className="w-full">
                {busy ? <Loader2 size={15} className="animate-spin" /> : t("confirm_order", lang)}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <ProductCreator open={createOpen} onOpenChange={setCreateOpen} onCreated={load} />
    </div>
  );
}

function ProductCreator({ open, onOpenChange, onCreated }: { open: boolean; onOpenChange: (v: boolean) => void; onCreated: () => void }) {
  const lang = useApp((s) => s.lang);
  const [form, setForm] = useState({ title: "", description: "", price: "", currency: "YER", category: "GENERAL", stock: "1" });
  const [images, setImages] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    try {
      await api.post("/api/products", {
        title: form.title,
        description: form.description,
        price: Number(form.price),
        currency: form.currency,
        category: form.category,
        stock: Number(form.stock),
        imageUrls: images,
      });
      toast.success(lang === "ar" ? "تم نشر المنتج" : "Product listed");
      setForm({ title: "", description: "", price: "", currency: "YER", category: "GENERAL", stock: "1" });
      setImages([]);
      onOpenChange(false);
      onCreated();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[85vh] overflow-y-auto yem-scroll">
        <DialogHeader><DialogTitle>{t("add_product", lang)}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder={t("product_title", lang)} maxLength={100} />
          <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder={t("product_desc", lang)} rows={3} maxLength={2000} />
          <div className="grid grid-cols-3 gap-2">
            <Input type="number" min={0} value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder={t("price", lang)} />
            <Select value={form.currency} onValueChange={(v) => setForm({ ...form, currency: v })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="YER">YER</SelectItem>
                <SelectItem value="USD">USD</SelectItem>
                <SelectItem value="SAR">SAR</SelectItem>
              </SelectContent>
            </Select>
            <Input type="number" min={0} value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} placeholder={t("stock", lang)} />
          </div>
          <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {PRODUCT_CATEGORIES.map((c) => <SelectItem key={c.key} value={c.key}>{c[lang]}</SelectItem>)}
            </SelectContent>
          </Select>
          <div className="flex flex-wrap gap-2 items-center">
            {images.map((url) => (
              <div key={url} className="relative w-16 h-16 rounded-lg overflow-hidden bg-muted">
                <img src={url} alt="upload" className="w-full h-full object-cover" />
                <button className="absolute top-0.5 end-0.5 bg-black/60 text-white rounded-full w-4 h-4 text-[10px]" onClick={() => setImages((p) => p.filter((u) => u !== url))}>✕</button>
              </div>
            ))}
            {images.length < 4 && (
              <ImagePickButton kind="product" label={t("add_photos", lang)} onUploaded={(url) => setImages((p) => [...p, url])} />
            )}
          </div>
          <Button onClick={submit} disabled={busy || !form.title || !form.description || !form.price} className="w-full">
            {busy ? <Loader2 size={15} className="animate-spin" /> : t("add_product", lang)}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
