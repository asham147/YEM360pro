import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { postCreateSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { canViewPrivateContent } from "@/lib/privacy";
import { syncPostHashtags, removePostHashtags } from "@/lib/hashtags";
import { serializePost, type PostWithRelations } from "@/lib/serialize-posts";
import { deleteMediaFile } from "@/lib/media";
import { z } from "zod";

const include = {
  author: { include: { profile: true } },
  media: true,
  hashtags: { include: { hashtag: true } },
  likes: { select: { userId: true } },
  saves: { select: { userId: true } },
  reposts: { select: { authorId: true } },
  _count: { select: { likes: true, comments: true, reposts: true } },
  repostOf: {
    include: {
      author: { include: { profile: true } },
      media: true,
      hashtags: { include: { hashtag: true } },
    },
  },
} satisfies Prisma.PostInclude;

export const GET = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g = await authGuard();
    const viewerId = g.ctx?.user.id ?? null;
    const { id } = await params;

    const post = await db.post.findUnique({
      where: { id },
      include: { ...include, author: { include: { profile: true, privacySetting: true } } },
    });
    if (!post || post.deletedAt) return fail(404, "NOT_FOUND", "المنشور غير موجود");

    const allowed = await canViewPrivateContent(viewerId, post.author);
    if (!allowed) return fail(403, "PRIVATE", "هذا الحساب خاص — تابع صاحبه لعرض منشوراته");

    return ok({ post: serializePost(post as PostWithRelations, viewerId) });
  }
);

const patchSchema = postCreateSchema.pick({ privacy: true, locationName: true, latitude: true, longitude: true }).extend({
  content: z.string().max(5000).optional(),
});

export const PATCH = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    const post = await db.post.findUnique({ where: { id } });
    if (!post || post.deletedAt) return fail(404, "NOT_FOUND", "المنشور غير موجود");
    if (post.authorId !== ctx.user.id) return fail(403, "FORBIDDEN", "يمكنك تعديل منشوراتك فقط");
    if (post.repostOfId) return fail(400, "BAD_REQUEST", "لا يمكن تعديل إعادة نشر");

    const parsed = await readJson(req, patchSchema);
    if (parsed.error) return parsed.error;
    const data = parsed.data;

    if (data.content !== undefined && data.content.trim()) {
      const blocked = await checkText(data.content);
      if (blocked.length) return fail(422, "CONTENT_BLOCKED", "المنشور يحتوي على كلمات غير مسموحة");
    }

    await db.post.update({
      where: { id },
      data: {
        content: data.content !== undefined ? data.content.trim() : undefined,
        privacy: data.privacy,
        locationName: data.locationName,
        latitude: data.latitude,
        longitude: data.longitude,
      },
    });
    if (data.content !== undefined) {
      await removePostHashtags(id);
      await syncPostHashtags(id, data.content);
    }
    return ok({ message: "تم تحديث المنشور" });
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    const post = await db.post.findUnique({ where: { id }, include: { media: true } });
    if (!post || post.deletedAt) return fail(404, "NOT_FOUND", "المنشور غير موجود");
    const isStaff = ctx.user.role === "ADMIN" || ctx.user.role === "MODERATOR";
    if (post.authorId !== ctx.user.id && !isStaff) {
      return fail(403, "FORBIDDEN", "يمكنك حذف منشوراتك فقط");
    }

    await db.$transaction([
      db.post.update({ where: { id }, data: { deletedAt: new Date() } }),
      // also remove repost rows pointing to it
      db.post.updateMany({ where: { repostOfId: id }, data: { deletedAt: new Date() } }),
    ]);
    for (const m of post.media) await deleteMediaFile(m.url);
    await removePostHashtags(id);
    return ok({ message: "تم حذف المنشور" });
  }
);
