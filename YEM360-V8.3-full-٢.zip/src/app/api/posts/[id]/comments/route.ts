import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { commentCreateSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { canViewPrivateContent, extractMentions, blockedPairIds } from "@/lib/privacy";
import { notify } from "@/lib/notify";
import { serializeComment, type CommentWithRelations } from "@/lib/serialize-posts";

const include = {
  author: { include: { profile: true } },
  likes: { select: { userId: true } },
  _count: { select: { likes: true, replies: true } },
  replies: {
    include: { author: { include: { profile: true } }, likes: { select: { userId: true } }, _count: { select: { likes: true } } },
    orderBy: { createdAt: "asc" as const },
  },
} satisfies Prisma.CommentInclude;

export const GET = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g = await authGuard();
    const viewerId = g.ctx?.user.id ?? null;
    const { id } = await params;

    const post = await db.post.findUnique({
      where: { id },
      include: { author: { include: { privacySetting: true } } },
    });
    if (!post || post.deletedAt) return fail(404, "NOT_FOUND", "المنشور غير موجود");
    if (!(await canViewPrivateContent(viewerId, post.author))) {
      return fail(403, "PRIVATE", "لا يمكنك عرض التعليقات");
    }

    const comments = await db.comment.findMany({
      where: { postId: id, parentId: null, deletedAt: null },
      include,
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return ok({ comments: comments.map((c) => serializeComment(c as CommentWithRelations, viewerId)) });
  }
);

export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const rl = rateLimit(`comment:${ctx.user.id}`, 30, 10 * 60 * 1000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "علّقت بشكل متكرر، انتظر قليلاً");
    const { id } = await params;

    const parsed = await readJson(req, commentCreateSchema);
    if (parsed.error) return parsed.error;
    const { text, parentId } = parsed.data;

    const blockedWords = await checkText(text);
    if (blockedWords.length) {
      return fail(422, "CONTENT_BLOCKED", `التعليق يحتوي على كلمات غير مسموحة: ${blockedWords.join("، ")}`);
    }

    const post = await db.post.findUnique({
      where: { id },
      include: { author: { include: { privacySetting: true } } },
    });
    if (!post || post.deletedAt) return fail(404, "NOT_FOUND", "المنشور غير موجود");
    if (!(await canViewPrivateContent(ctx.user.id, post.author))) {
      return fail(403, "PRIVATE", "لا يمكنك التعليق على هذا المنشور");
    }

    let parentAuthorId: string | null = null;
    if (parentId) {
      const parent = await db.comment.findFirst({ where: { id: parentId, postId: id, deletedAt: null } });
      if (!parent) return fail(404, "NOT_FOUND", "التعليق الأصلي غير موجود");
      parentAuthorId = parent.authorId;
    }

    const comment = await db.comment.create({
      data: { authorId: ctx.user.id, postId: id, parentId, text: text.trim() },
    });

    await notify({
      userId: post.authorId,
      actorId: ctx.user.id,
      type: "COMMENT",
      entityType: "POST",
      entityId: id,
      text: "علّق على منشورك",
    });
    if (parentAuthorId && parentAuthorId !== post.authorId) {
      await notify({
        userId: parentAuthorId,
        actorId: ctx.user.id,
        type: "COMMENT_REPLY",
        entityType: "POST",
        entityId: id,
        text: "ردّ على تعليقك",
      });
    }
    const mentioned = extractMentions(text);
    if (mentioned.length) {
      const users = await db.user.findMany({ where: { username: { in: mentioned } } });
      const blockedSet = new Set(await blockedPairIds(ctx.user.id));
      for (const u of users) {
        if (blockedSet.has(u.id) || u.id === post.authorId || u.id === parentAuthorId) continue;
        await notify({
          userId: u.id,
          actorId: ctx.user.id,
          type: "MENTION",
          entityType: "POST",
          entityId: id,
          text: "أشار إليك في تعليق",
        });
      }
    }

    const fresh = (await db.comment.findUnique({
      where: { id: comment.id },
      include,
    })) as CommentWithRelations;
    return ok({ comment: serializeComment(fresh, ctx.user.id) }, 201);
  }
);
