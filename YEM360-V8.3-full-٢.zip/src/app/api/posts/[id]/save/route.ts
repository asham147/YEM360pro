import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";

export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    const post = await db.post.findUnique({ where: { id } });
    if (!post || post.deletedAt) return fail(404, "NOT_FOUND", "المنشور غير موجود");

    await db.savedPost.upsert({
      where: { userId_postId: { userId: ctx.user.id, postId: id } },
      update: {},
      create: { userId: ctx.user.id, postId: id },
    });
    return ok({ saved: true }, 201);
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    await db.savedPost.deleteMany({ where: { userId: ctx.user.id, postId: id } });
    return ok({ saved: false });
  }
);
