import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";

/** View counter — throttled per viewer (1 count / 10s / post). */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const { id } = await params;
    const exists = await db.post.findFirst({ where: { id, deletedAt: null } });
    if (!exists) return fail(404, "NOT_FOUND");
    await db.post.update({ where: { id }, data: { viewCount: { increment: 1 } } });
    return ok({});
  }
);
