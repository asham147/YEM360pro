import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { notify } from "@/lib/notify";

async function loadPost(id: string) {
  return db.post.findUnique({ where: { id }, include: { author: true } });
}

export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const rl = rateLimit(`like:${ctx.user.id}`, 120, 60_000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "بطء شديد");
    const { id } = await params;

    const post = await loadPost(id);
    if (!post || post.deletedAt) return fail(404, "NOT_FOUND", "المنشور غير موجود");

    const existing = await db.like.findFirst({
      where: { userId: ctx.user.id, postId: id },
    });
    if (existing) return ok({ liked: true, alreadyLiked: true });

    await db.like.create({ data: { userId: ctx.user.id, postId: id } });
    await notify({
      userId: post.authorId,
      actorId: ctx.user.id,
      type: "LIKE",
      entityType: "POST",
      entityId: id,
      text: "أعجب بمنشورك",
    });
    const count = await db.like.count({ where: { postId: id } });
    return ok({ liked: true, likeCount: count }, 201);
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    const res = await db.like.deleteMany({ where: { userId: ctx.user.id, postId: id } });
    const count = await db.like.count({ where: { postId: id } });
    return ok({ liked: false, unliked: res.count > 0, likeCount: count });
  }
);
