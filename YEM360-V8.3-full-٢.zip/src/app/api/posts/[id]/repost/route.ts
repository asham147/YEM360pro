import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";

/** Repost: creates a reference post (content empty + repostOfId). */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const rl = rateLimit(`repost:${ctx.user.id}`, 20, 10 * 60 * 1000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "أعدت النشر بشكل متكرر");
    const { id } = await params;

    const original = await db.post.findUnique({ where: { id } });
    if (!original || original.deletedAt) return fail(404, "NOT_FOUND", "المنشور غير موجود");
    if (original.authorId === ctx.user.id && false) return fail(400, "BAD_REQUEST");
    if (original.repostOfId) return fail(400, "BAD_REQUEST", "لا يمكن إعادة نشر إعادة نشر");

    const existing = await db.post.findFirst({
      where: { authorId: ctx.user.id, repostOfId: id, deletedAt: null },
    });
    if (existing) return ok({ reposted: true, alreadyReposted: true });

    await db.post.create({
      data: { authorId: ctx.user.id, content: "", privacy: "PUBLIC", repostOfId: id },
    });
    return ok({ reposted: true }, 201);
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    const res = await db.post.updateMany({
      where: { authorId: ctx.user.id, repostOfId: id, deletedAt: null },
      data: { deletedAt: new Date() },
    });
    return ok({ reposted: false, removed: res.count > 0 });
  }
);
