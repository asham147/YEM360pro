import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { postCreateSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { visiblePostsWhere, extractMentions, blockedPairIds } from "@/lib/privacy";
import { syncPostHashtags } from "@/lib/hashtags";
import { notify } from "@/lib/notify";
import { serializePost, serializePosts, type PostWithRelations } from "@/lib/serialize-posts";

const include = {
  author: { include: { profile: true } },
  media: true,
  hashtags: { include: { hashtag: true } },
  likes: { select: { userId: true } },
  saves: { select: { userId: true } },
  reposts: { select: { authorId: true } },
  _count: { select: { likes: true, comments: true, reposts: true } },
  repostOf: {
    include: {
      author: { include: { profile: true } },
      media: true,
      hashtags: { include: { hashtag: true } },
      likes: { select: { userId: true } },
      saves: { select: { userId: true } },
      reposts: { select: { authorId: true } },
      _count: { select: { likes: true, comments: true, reposts: true } },
    },
  },
} satisfies Prisma.PostInclude;

/** GET /api/posts — home feed (following + public), cursor pagination. */
export const GET = handler(async (req: NextRequest) => {
  const g = await authGuard();
  const viewerId = g.ctx?.user.id ?? null;

  const cursor = req.nextUrl.searchParams.get("cursor");
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") || 10), 20);
  const where = visiblePostsWhere(viewerId) as Prisma.PostWhereInput;
  if (cursor) {
    where.createdAt = { lt: new Date(cursor) };
  }

  const posts = await db.post.findMany({
    where,
    include,
    orderBy: [{ createdAt: "desc" }],
    take: limit + 1,
  });
  const hasMore = posts.length > limit;
  const page = posts.slice(0, limit) as PostWithRelations[];

  return ok({
    posts: serializePosts(page, viewerId),
    nextCursor: hasMore && page.length ? page[page.length - 1].createdAt.toISOString() : null,
  });
});

/** POST /api/posts — create a post (or a repost when repostOfId is provided). */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const gPost = await authGuard();
  if (!gPost.ctx) return gPost.resp;
  const { ctx } = gPost;
  const rl = rateLimit(`post:create:${ctx.user.id}`, 15, 10 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "نشرت منشورات كثيرة خلال وقت قصير");

  const parsed = await readJson(req, postCreateSchema);
  if (parsed.error) return parsed.error;
  const data = parsed.data;

  // ── validation before anything is written ──
  if (data.repostOfId) {
    const original = await db.post.findUnique({
      where: { id: data.repostOfId },
      include: { author: { include: { privacySetting: true } } },
    });
    if (!original || original.deletedAt) return fail(404, "NOT_FOUND", "المنشور الأصلي غير موجود");
    if (original.repostOfId) return fail(400, "BAD_REQUEST", "لا يمكن إعادة نشر إعادة نشر");
    if (original.authorId !== ctx.user.id && original.author.privacySetting?.privateAccount) {
      const following = await db.follow.findFirst({
        where: { followerId: ctx.user.id, followingId: original.authorId, status: "ACCEPTED" },
      });
      if (!following) return fail(403, "FORBIDDEN", "لا يمكنك إعادة نشر منشورات حساب خاص");
    }
  } else {
    if (!data.content.trim() && data.mediaUrls.length === 0) {
      return fail(422, "EMPTY_POST", "اكتب نصاً أو أضف صورة على الأقل");
    }
    const blocked = await checkText(data.content);
    if (blocked.length) {
      return fail(422, "CONTENT_BLOCKED", `المنشور يحتوي على كلمات غير مسموحة: ${blocked.join("، ")}`, { words: blocked });
    }
  }

  const post = await db.post.create({
    data: {
      authorId: ctx.user.id,
      content: data.repostOfId ? "" : data.content.trim(),
      privacy: data.repostOfId ? "PUBLIC" : data.privacy,
      locationName: data.locationName,
      latitude: data.latitude,
      longitude: data.longitude,
      repostOfId: data.repostOfId,
    },
  });

  if (!data.repostOfId && data.mediaUrls.length) {
    await db.postMedia.createMany({
      data: data.mediaUrls.map((url, i) => ({
        postId: post.id,
        type: /\.(mp4|webm)$/i.test(url) ? "VIDEO" : "IMAGE",
        url,
        orderIndex: i,
      })),
    });
  }

  if (!data.repostOfId) {
    await syncPostHashtags(post.id, data.content);
    const mentioned = extractMentions(data.content);
    if (mentioned.length) {
      const users = await db.user.findMany({ where: { username: { in: mentioned } } });
      const blockedSet = new Set(await blockedPairIds(ctx.user.id));
      await Promise.all(
        users
          .filter((u) => !blockedSet.has(u.id))
          .map((u) =>
            notify({
              userId: u.id,
              actorId: ctx.user.id,
              type: "MENTION",
              entityType: "POST",
              entityId: post.id,
              text: "أشار إليك في منشور",
            })
          )
      );
    }
  }

  const fresh = (await db.post.findUnique({ where: { id: post.id }, include })) as PostWithRelations;
  return ok({ post: serializePost(fresh, ctx.user.id) }, 201);
});
