import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { noteSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { internalEmit } from "@/lib/notify";

/** GET /api/notes — my active note. */
export const GET = handler(async (_req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const note = await db.note.findFirst({
    where: { userId: ctx.user.id, expiresAt: { gt: new Date() } },
  });
  return ok({ note });
});

/** POST /api/notes — set / replace my note (60-char note that lives 24h). */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`note:${ctx.user.id}`, 10, 60 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "تعديلات متكررة");

  const parsed = await readJson(req, noteSchema);
  if (parsed.error) return parsed.error;

  const banned = await checkText(parsed.data.text);
  if (banned.length) return fail(422, "CONTENT_BLOCKED", "النص يحتوي على كلمات غير مسموحة");

  await db.note.deleteMany({ where: { userId: ctx.user.id } });
  const note = await db.note.create({
    data: {
      userId: ctx.user.id,
      text: parsed.data.text.trim(),
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    },
  });
  await internalEmit("note:updated", { userId: ctx.user.id, text: note.text });
  return ok({ note }, 201);
});

/** DELETE /api/notes — remove my note. */
export const DELETE = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  await db.note.deleteMany({ where: { userId: ctx.user.id } });
  return ok({ message: "تم حذف الملاحظة" });
});
