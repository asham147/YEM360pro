import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { profileUpdateSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";

/** PATCH /api/profile — edit own profile (name, bio, avatar, cover, pro switch...). */
export const PATCH = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`profile:${ctx.user.id}`, 20, 10 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "تعديلات متكررة، انتظر قليلاً");

  const parsed = await readJson(req, profileUpdateSchema);
  if (parsed.error) return parsed.error;
  const d = parsed.data;

  if (d.bio) {
    const banned = await checkText(d.bio);
    if (banned.length) return fail(422, "CONTENT_BLOCKED", "النبذة تحتوي على كلمات غير مسموحة");
  }

  const { gender, accountType, professionalCategory, ...profileFields } = d;

  await db.$transaction([
    ctx.user.name !== (d.name ?? ctx.user.name) && d.name
      ? db.user.update({ where: { id: ctx.user.id }, data: { name: d.name, accountType, professionalCategory: professionalCategory ?? null } })
      : db.user.update({ where: { id: ctx.user.id }, data: { accountType, professionalCategory: professionalCategory ?? null } }),
    db.profile.update({
      where: { userId: ctx.user.id },
      data: {
        bio: d.bio ?? undefined,
        avatarUrl: d.avatarUrl ?? undefined,
        coverUrl: d.coverUrl ?? undefined,
        website: d.website ?? undefined,
        location: d.location ?? undefined,
        birthday: d.birthday ?? undefined,
        gender: gender === "" ? null : (gender ?? undefined),
      },
    }),
  ]);

  const user = await db.user.findUnique({ where: { id: ctx.user.id }, include: { profile: true } });
  return ok({ message: "تم تحديث الملف الشخصي", user: { ...user, passwordHash: undefined, twoFactorSecret: undefined } });
});
