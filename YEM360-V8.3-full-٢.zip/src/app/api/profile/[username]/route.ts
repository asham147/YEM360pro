import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { publicUser } from "@/lib/serialize";

/** GET /api/profile/[username] — full public profile + relationship state. */
export const GET = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ username: string }> }) => {
    const g = await authGuard();
    if (g.resp) return g.resp;
    const viewerId = g.ctx.user.id;
    const { username } = await params;

    const user = await db.user.findUnique({
      where: { username },
      include: { profile: true, privacySetting: true, story: true },
    });
    if (!user || !user.isActive) return fail(404, "NOT_FOUND", "الحساب غير موجود");

    const blockBetween = await db.block.findFirst({
      where: {
        OR: [
          { blockerId: viewerId, blockedId: user.id },
          { blockerId: user.id, blockedId: viewerId },
        ],
      },
    });

    const [followers, following, friendsCount, posts, reels, isFollowingRow, followsMeRow, friendship] =
      await Promise.all([
        db.follow.count({ where: { followingId: user.id, status: "ACCEPTED" } }),
        db.follow.count({ where: { followerId: user.id, status: "ACCEPTED" } }),
        db.$queryRaw<{ c: number }[]>`
          SELECT COUNT(*) as c FROM Friendships f
          WHERE f.status = 'ACCEPTED' AND (f.requesterId = ${user.id} OR f.addresseeId = ${user.id})
        `,
        db.post.count({ where: { authorId: user.id, deletedAt: null } }),
        db.reel.count({ where: { userId: user.id, deletedAt: null } }),
        db.follow.findFirst({ where: { followerId: viewerId, followingId: user.id } }),
        db.follow.findFirst({ where: { followerId: user.id, followingId: viewerId } }),
        db.friendship.findFirst({
          where: {
            OR: [
              { requesterId: viewerId, addresseeId: user.id },
              { requesterId: user.id, addresseeId: viewerId },
            ],
          },
        }),
      ]);

    const isSelf = user.id === viewerId;
    const privateAccount = user.privacySetting?.privateAccount ?? false;
    const viewerFollows = isFollowingRow?.status === "ACCEPTED";
    const canSeeContent = isSelf || (!blockBetween && (!privateAccount || viewerFollows));

    return ok({
      user: publicUser(user, user.profile, { self: isSelf }),
      note: user.story && user.story.expiresAt > new Date() ? user.story.text : null,
      counts: {
        followers,
        following,
        friends: Number(friendsCount[0]?.c ?? 0),
        posts,
        reels,
      },
      relationship: {
        isSelf,
        isFollowing: isFollowingRow?.status === "ACCEPTED",
        isPending: isFollowingRow?.status === "PENDING",
        followsMe: followsMeRow?.status === "ACCEPTED",
        friendshipStatus: friendship?.status ?? null,
        friendshipRole: friendship ? (friendship.requesterId === viewerId ? "REQUESTER" : "ADDRESSEE") : null,
        friendshipId: friendship?.id ?? null,
        isBlockedByMe: blockBetween?.blockerId === viewerId,
        privateAccount,
        canSeeContent,
      },
    });
  }
);
