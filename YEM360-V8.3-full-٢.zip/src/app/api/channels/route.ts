import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { channelSchema } from "@/lib/validators";
import { publicUser } from "@/lib/serialize";

/** GET /api/channels — my channels (owned + subscribed) + discover. */
export const GET = handler(async (_req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;

  const [owned, subscribed, discover] = await Promise.all([
    db.channel.findMany({
      where: { ownerId: ctx.user.id },
      include: { owner: { include: { profile: true } } },
      orderBy: { createdAt: "desc" },
    }),
    db.channelSubscriber.findMany({
      where: { userId: ctx.user.id },
      include: { channel: { include: { owner: { include: { profile: true } } } } },
      orderBy: { createdAt: "desc" },
    }),
    db.channel.findMany({
      where: { ownerId: { not: ctx.user.id }, subscribers: { none: { userId: ctx.user.id } } },
      include: { owner: { include: { profile: true } } },
      orderBy: { subscriberCount: "desc" },
      take: 10,
    }),
  ]);

  const map = (c: typeof owned[number]) => ({
    id: c.id, name: c.name, handle: c.handle, description: c.description,
    subscriberCount: c.subscriberCount,
    owner: publicUser(c.owner, c.owner.profile),
    isOwner: c.ownerId === ctx.user.id,
    createdAt: c.createdAt.toISOString(),
  });

  return ok({
    owned: owned.map(map),
    subscribed: subscribed.map((s) => map(s.channel)),
    discover: discover.map(map),
  });
});

/** POST /api/channels — create a broadcast channel. */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`channel:${ctx.user.id}`, 5, 24 * 60 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "أنشأت قنوات كثيرة اليوم");

  const parsed = await readJson(req, channelSchema);
  if (parsed.error) return parsed.error;
  const { name, handle, description } = parsed.data;

  const taken = await db.channel.findUnique({ where: { handle } });
  if (taken) return fail(409, "HANDLE_TAKEN", "المعرف مستخدم، اختر معرفاً آخر");

  const channel = await db.$transaction(async (tx) => {
    const c = await tx.channel.create({
      data: { name, handle, description, ownerId: ctx.user.id, subscriberCount: 1 },
    });
    await tx.channelSubscriber.create({ data: { channelId: c.id, userId: ctx.user.id } });
    return c;
  });
  return ok({ id: channel.id }, 201);
});
