import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";

/** POST subscribe / DELETE unsubscribe. */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const rl = rateLimit(`sub:${ctx.user.id}`, 30, 10 * 60 * 1000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "طلبات متكررة");
    const { id } = await params;

    const channel = await db.channel.findUnique({ where: { id } });
    if (!channel) return fail(404, "NOT_FOUND", "القناة غير موجودة");

    const existing = await db.channelSubscriber.findFirst({
      where: { channelId: id, userId: ctx.user.id },
    });
    if (existing) return ok({ subscribed: true, already: true });

    await db.$transaction([
      db.channelSubscriber.create({ data: { channelId: id, userId: ctx.user.id } }),
      db.channel.update({ where: { id }, data: { subscriberCount: { increment: 1 } } }),
    ]);
    return ok({ subscribed: true }, 201);
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const existing = await db.channelSubscriber.findFirst({
      where: { channelId: id, userId: ctx.user.id },
    });
    if (!existing) return ok({ subscribed: false });

    await db.$transaction([
      db.channelSubscriber.delete({ where: { id: existing.id } }),
      db.channel.update({ where: { id }, data: { subscriberCount: { decrement: 1 } } }),
    ]);
    return ok({ subscribed: false });
  }
);
