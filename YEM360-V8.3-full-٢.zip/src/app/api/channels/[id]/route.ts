import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { publicUser } from "@/lib/serialize";

/** GET /api/channels/[id] — channel page: messages + subscription state. */
export const GET = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g = await authGuard();
    if (!g.ctx) return g.resp;
    const { id } = await params;

    const channel = await db.channel.findUnique({
      where: { id },
      include: { owner: { include: { profile: true } } },
    });
    if (!channel) return fail(404, "NOT_FOUND", "القناة غير موجودة");

    const [messages, subscribed, lastMessages] = await Promise.all([
      db.channelMessage.count({ where: { channelId: id } }),
      db.channelSubscriber.findFirst({ where: { channelId: id, userId: g.ctx.user.id } }),
      db.channelMessage.findMany({
        where: { channelId: id },
        include: { sender: { include: { profile: true } } },
        orderBy: { createdAt: "desc" },
        take: 30,
      }),
    ]);

    return ok({
      channel: {
        id: channel.id, name: channel.name, handle: channel.handle, description: channel.description,
        subscriberCount: channel.subscriberCount,
        owner: publicUser(channel.owner, channel.owner.profile),
        isOwner: channel.ownerId === g.ctx.user.id,
        createdAt: channel.createdAt.toISOString(),
      },
      messageCount: messages,
      isSubscribed: !!subscribed,
      messages: lastMessages.reverse().map((m) => ({
        id: m.id,
        text: m.text,
        mediaUrl: m.mediaUrl,
        createdAt: m.createdAt.toISOString(),
        sender: publicUser(m.sender, m.sender.profile),
      })),
    });
  }
);
