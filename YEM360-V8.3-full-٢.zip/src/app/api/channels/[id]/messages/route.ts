import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { messageSendSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { notify, internalEmit } from "@/lib/notify";

/** POST /api/channels/[id]/messages — broadcast to all subscribers (owner only). */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const rl = rateLimit(`broadcast:${ctx.user.id}`, 15, 60 * 60 * 1000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "بثّت رسائل كثيرة، انتظر ساعة");

    const { id } = await params;
    const channel = await db.channel.findUnique({ where: { id } });
    if (!channel) return fail(404, "NOT_FOUND", "القناة غير موجودة");
    if (channel.ownerId !== ctx.user.id) {
      return fail(403, "FORBIDDEN", "النشر في القناة لمالكها فقط");
    }

    const parsed = await readJson(req, messageSendSchema);
    if (parsed.error) return parsed.error;
    const { text, mediaUrl } = parsed.data;
    if (!text?.trim() && !mediaUrl) return fail(422, "EMPTY", "الرسالة فارغة");

    if (text?.trim()) {
      const banned = await checkText(text);
      if (banned.length) return fail(422, "CONTENT_BLOCKED", "النص يحتوي على كلمات غير مسموحة");
    }

    const message = await db.channelMessage.create({
      data: { channelId: id, senderId: ctx.user.id, text: text?.trim() || null, mediaUrl },
    });

    const subs = await db.channelSubscriber.findMany({
      where: { channelId: id, userId: { not: ctx.user.id } },
      select: { userId: true },
      take: 1000,
    });

    // realtime push (best-effort) to subscribers
    await internalEmit(
      "channel:new",
      { channelId: id, message: { id: message.id, text: message.text, mediaUrl: message.mediaUrl, createdAt: message.createdAt.toISOString(), sender: ctx.user.name } },
      { userIds: subs.map((s) => s.userId) }
    );
    // notifications (capped; skip heavy inserts for very large channels — documented trade-off)
    for (const s of subs.slice(0, 200)) {
      await notify({
        userId: s.userId,
        actorId: ctx.user.id,
        type: "CHANNEL_POST",
        entityType: "CHANNEL",
        entityId: id,
        text: `قناة ${channel.name}: ${(message.text || "منشور جديد").slice(0, 60)}`,
      }).catch(() => null);
    }

    return ok({ id: message.id }, 201);
  }
);
