import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { logSecurity } from "@/lib/security";
import { z } from "zod";
import { publicUser } from "@/lib/serialize";

const blockSchema = z.object({ userId: z.string().min(1).max(40) });

/** GET /api/blocks — my blocked users list. */
export const GET = handler(async (_req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const blocks = await db.block.findMany({
    where: { blockerId: ctx.user.id },
    include: { blocked: { include: { profile: true } } },
    orderBy: { createdAt: "desc" },
  });
  return ok({
    blocked: blocks.map((b) => ({
      id: b.id,
      user: publicUser(b.blocked, b.blocked.profile),
      createdAt: b.createdAt.toISOString(),
    })),
  });
});

/** POST /api/blocks — block a user (kills follows + friendships between the two). */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`block:${ctx.user.id}`, 20, 10 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "طلبات متكررة");

  const parsed = await readJson(req, blockSchema);
  if (parsed.error) return parsed.error;
  const target = await db.user.findUnique({ where: { id: parsed.data.userId } });
  if (!target) return fail(404, "NOT_FOUND", "الحساب غير موجود");
  if (target.id === ctx.user.id) return fail(400, "SELF", "لا يمكنك حظر نفسك");

  await db.$transaction([
    db.block.upsert({
      where: { blockerId_blockedId: { blockerId: ctx.user.id, blockedId: target.id } },
      update: {},
      create: { blockerId: ctx.user.id, blockedId: target.id },
    }),
    db.follow.deleteMany({
      where: {
        OR: [
          { followerId: ctx.user.id, followingId: target.id },
          { followerId: target.id, followingId: ctx.user.id },
        ],
      },
    }),
    db.friendship.deleteMany({
      where: {
        OR: [
          { requesterId: ctx.user.id, addresseeId: target.id },
          { requesterId: target.id, addresseeId: ctx.user.id },
        ],
      },
    }),
  ]);

  await logSecurity("USER_BLOCKED", { userId: ctx.user.id, details: `blocked=${target.username}` });
  return ok({ blocked: true }, 201);
});

/** DELETE /api/blocks?userId= — unblock. */
export const DELETE = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const userId = req.nextUrl.searchParams.get("userId") || "";
  if (!userId) return fail(400, "BAD_REQUEST", "معرّف المستخدم مطلوب");
  await db.block.deleteMany({ where: { blockerId: ctx.user.id, blockedId: userId } });
  return ok({ blocked: false });
});
