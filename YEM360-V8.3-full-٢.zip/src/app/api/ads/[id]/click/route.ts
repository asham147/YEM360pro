import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";

/** POST /api/ads/[id]/click — record a click, return the destination URL. */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g = await authGuard();
    if (!g.ctx) return g.resp;
    const { id } = await params;

    const ad = await db.advertisement.findUnique({ where: { id } });
    if (!ad) return fail(404, "NOT_FOUND", "الإعلان غير موجود");

    await db.$transaction([
      db.advertisement.update({ where: { id }, data: { clickCount: { increment: 1 } } }),
      db.adEvent.create({ data: { adId: id, userId: g.ctx.user.id, type: "CLICK" } }),
    ]);
    return ok({ targetUrl: ad.targetUrl });
  }
);
