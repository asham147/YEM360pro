import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { adSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { z } from "zod";

/** GET /api/ads — my advertising campaigns with performance stats. */
export const GET = handler(async (_req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const ads = await db.advertisement.findMany({
    where: { advertiserId: ctx.user.id },
    orderBy: { createdAt: "desc" },
  });
  return ok({
    ads: ads.map((a) => ({
      id: a.id, title: a.title, body: a.body, imageUrl: a.imageUrl, targetUrl: a.targetUrl,
      status: a.status, budget: a.budget, impressionCount: a.impressionCount, clickCount: a.clickCount,
      ctr: a.impressionCount ? +((a.clickCount / a.impressionCount) * 100).toFixed(2) : 0,
      targetGender: a.targetGender, targetMinAge: a.targetMinAge, targetMaxAge: a.targetMaxAge,
      createdAt: a.createdAt.toISOString(),
    })),
  });
});

/** POST /api/ads — create a campaign (PENDING until an admin approves it). */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`ad:${ctx.user.id}`, 10, 60 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "حملات متكررة");

  const parsed = await readJson(req, adSchema);
  if (parsed.error) return parsed.error;
  const d = parsed.data;

  const banned = await checkText(`${d.title} ${d.body}`);
  if (banned.length) return fail(422, "CONTENT_BLOCKED", "المحتوى يحتوي على كلمات غير مسموحة");

  const ad = await db.advertisement.create({
    data: {
      advertiserId: ctx.user.id,
      title: d.title, body: d.body, imageUrl: d.imageUrl, targetUrl: d.targetUrl,
      budget: d.budget, targetGender: d.targetGender, targetMinAge: d.targetMinAge, targetMaxAge: d.targetMaxAge,
    },
  });
  return ok({ id: ad.id, message: "تم إرسال الحملة للمراجعة" }, 201);
});

const patchSchema = z.object({
  id: z.string().min(1).max(40),
  action: z.enum(["PAUSE", "ACTIVATE", "DELETE"]),
});

/** PATCH /api/ads — pause / resume / delete own campaign. */
export const PATCH = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const parsed = await readJson(req, patchSchema);
  if (parsed.error) return parsed.error;
  const { id, action } = parsed.data;

  const ad = await db.advertisement.findUnique({ where: { id } });
  if (!ad || ad.advertiserId !== ctx.user.id) return fail(404, "NOT_FOUND", "الحملة غير موجودة");

  if (action === "DELETE") {
    await db.advertisement.delete({ where: { id } });
    return ok({ message: "تم حذف الحملة" });
  }
  if (ad.status === "PENDING" || ad.status === "REJECTED") {
    return fail(400, "STATE", "الحملة بانتظار مراجعة الإدارة");
  }
  await db.advertisement.update({
    where: { id },
    data: { status: action === "PAUSE" ? "PAUSED" : "ACTIVE" },
  });
  return ok({ message: action === "PAUSE" ? "تم إيقاف الحملة مؤقتاً" : "تم تفعيل الحملة" });
});
