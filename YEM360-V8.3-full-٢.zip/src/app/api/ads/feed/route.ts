import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";

/**
 * GET /api/ads/feed — targeted, ACTIVE ads for the viewer (2 random).
 * Records an IMPRESSION event + counter for the advertiser dashboard.
 */
export const GET = handler(async (_req: NextRequest) => {
  const g = await authGuard();
  if (g.resp) return g.resp;
  const viewerId = g.ctx.user.id;

  const profile = await db.profile.findUnique({ where: { userId: viewerId } });
  const gender = profile?.gender === "MALE" || profile?.gender === "FEMALE" ? profile.gender : null;

  // approximate age from birthday (YYYY-MM-DD)
  let age: number | null = null;
  if (profile?.birthday) {
    const bd = new Date(profile.birthday);
    if (!isNaN(bd.getTime())) {
      age = Math.floor((Date.now() - bd.getTime()) / (365.25 * 24 * 3600 * 1000));
      if (age < 5 || age > 100) age = null;
    }
  }

  const ads = await db.advertisement.findMany({
    where: { status: "ACTIVE" },
    take: 20,
    orderBy: { createdAt: "desc" },
  });

  const eligible = ads.filter((a) => {
    if (a.targetGender !== "ALL" && gender && a.targetGender !== gender) return false;
    if (a.targetMinAge && age && age < a.targetMinAge) return false;
    if (a.targetMaxAge && age && age > a.targetMaxAge) return false;
    return true;
  });

  const picked = eligible.sort(() => Math.random() - 0.5).slice(0, 2);
  if (picked.length) {
    await db.$transaction([
      ...picked.map((a) =>
        db.advertisement.update({ where: { id: a.id }, data: { impressionCount: { increment: 1 } } })
      ),
      ...picked.map((a) => db.adEvent.create({ data: { adId: a.id, userId: viewerId, type: "IMPRESSION" } })),
    ]);
  }

  return ok({
    ads: picked.map((a) => ({
      id: a.id, title: a.title, body: a.body, imageUrl: a.imageUrl, targetUrl: a.targetUrl,
    })),
  });
});
