import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { visiblePostsWhere } from "@/lib/privacy";
import { serializePost, type PostWithRelations } from "@/lib/serialize-posts";

/** GET /api/tags/[name] — hashtag page: tag info + visible posts. */
export const GET = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ name: string }> }) => {
    const g = await authGuard();
    if (!g.ctx) return g.resp;
    const viewerId = g.ctx.user.id;
    const { name } = await params;

    const tag = await db.hashtag.findUnique({ where: { name: decodeURIComponent(name) } });
    if (!tag) return fail(404, "NOT_FOUND", "الهاشتاغ غير موجود");

    const posts = await db.post.findMany({
      where: {
        ...(visiblePostsWhere(viewerId) as Prisma.PostWhereInput),
        hashtags: { some: { hashtag: { id: tag.id } } },
      },
      include: {
        author: { include: { profile: true } },
        media: true,
        hashtags: { include: { hashtag: true } },
        likes: { select: { userId: true } },
        saves: { select: { userId: true } },
        reposts: { select: { authorId: true } },
        repostOf: { include: { author: { include: { profile: true } }, media: true, hashtags: { include: { hashtag: true } }, likes: { select: { userId: true } }, saves: { select: { userId: true } }, reposts: { select: { authorId: true } }, _count: { select: { likes: true, comments: true, reposts: true } } } },
      },
      orderBy: { createdAt: "desc" },
      take: 40,
    });

    return ok({
      tag: { name: tag.name, useCount: tag.useCount },
      posts: (posts as PostWithRelations[]).map((p) => serializePost(p, viewerId)),
    });
  }
);
