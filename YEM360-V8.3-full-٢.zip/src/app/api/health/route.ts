import { NextResponse } from "next/server";

export const GET = async () => {
  let realtime = false;
  try {
    const res = await fetch("http://127.0.0.1:3004/health", { signal: AbortSignal.timeout(700) });
    realtime = res.ok;
  } catch {
    realtime = false;
  }
  return NextResponse.json({
    ok: true,
    service: "YEM360",
    version: "1.0.0",
    realtime,
    time: new Date().toISOString(),
  });
};
