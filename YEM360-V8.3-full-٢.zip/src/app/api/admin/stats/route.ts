import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { requireRole } from "@/lib/auth";

/** GET /api/admin/stats — platform dashboard. Admins + moderators. */
export const GET = handler(async (_req: NextRequest) => {
  const g = await requireRole(["ADMIN", "MODERATOR"]);
  if (g.resp) return g.resp;

  const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

  const [users, usersToday, posts, postsToday, messagesToday, reportsPending, adsPending, products, orders, bannedUsers] =
    await Promise.all([
      db.user.count(),
      db.user.count({ where: { createdAt: { gte: dayAgo } } }),
      db.post.count({ where: { deletedAt: null } }),
      db.post.count({ where: { createdAt: { gte: dayAgo }, deletedAt: null } }),
      db.message.count({ where: { createdAt: { gte: dayAgo }, deletedAt: null } }),
      db.report.count({ where: { status: "PENDING" } }),
      db.advertisement.count({ where: { status: "PENDING" } }),
      db.product.count({ where: { deletedAt: null } }),
      db.order.count(),
      db.user.count({ where: { isActive: false } }),
    ]);

  return ok({
    stats: { users, usersToday, posts, postsToday, messagesToday, reportsPending, adsPending, products, orders, bannedUsers },
  });
});
