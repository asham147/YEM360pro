import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { requireRole } from "@/lib/auth";
import { logSecurity } from "@/lib/security";
import { z } from "zod";
import { publicUser } from "@/lib/serialize";

/** GET /api/admin/users?q= — user management list. */
export const GET = handler(async (req: NextRequest) => {
  const g = await requireRole(["ADMIN", "MODERATOR"]);
  if (g.resp) return g.resp;

  const q = req.nextUrl.searchParams.get("q")?.trim() || "";
  const users = await db.user.findMany({
    where: q ? { OR: [{ username: { contains: q } }, { name: { contains: q } }, { email: { contains: q } }] } : {},
    include: { profile: true, _count: { select: { posts: true, followers: true } } },
    orderBy: { createdAt: "desc" },
    take: 30,
  });

  return ok({
    users: users.map((u) => ({
      ...publicUser(u, u.profile, { self: true }),
      isActive: u.isActive,
      banReason: u.banReason,
      twoFactorEnabled: u.twoFactorEnabled,
      posts: u._count.posts,
      followers: u._count.followers,
      createdAt: u.createdAt.toISOString(),
    })),
  });
});

const patchSchema = z.object({
  userId: z.string().min(1).max(40),
  action: z.enum(["BAN", "UNBAN", "VERIFY", "UNVERIFY", "MAKE_MOD", "REMOVE_MOD"]),
  reason: z.string().max(200).optional(),
});

/** PATCH /api/admin/users — moderation actions. */
export const PATCH = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g = await requireRole(["ADMIN", "MODERATOR"]);
  if (g.resp) return g.resp;
  const isOnlyMod = g.ctx.user.role === "MODERATOR";

  const parsed = await readJson(req, patchSchema);
  if (parsed.error) return parsed.error;
  const { userId, action, reason } = parsed.data;

  const target = await db.user.findUnique({ where: { id: userId } });
  if (!target) return fail(404, "NOT_FOUND", "المستخدم غير موجود");
  if (target.id === g.ctx.user.id) return fail(400, "SELF", "لا يمكن تطبيق الإجراء على نفسك");
  if (target.role === "ADMIN" && isOnlyMod) return fail(403, "FORBIDDEN", "المشرف لا يمكنه تعديل المدير");

  switch (action) {
    case "BAN":
      await db.user.update({ where: { id: userId }, data: { isActive: false, banReason: reason || "مخالفة قواعد المنصة" } });
      await db.loginSession.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } });
      await logSecurity("ADMIN_BAN", { userId: g.ctx.user.id, severity: "HIGH", details: `banned=${target.username}` });
      break;
    case "UNBAN":
      await db.user.update({ where: { id: userId }, data: { isActive: true, banReason: null } });
      await logSecurity("ADMIN_UNBAN", { userId: g.ctx.user.id, details: `unbanned=${target.username}` });
      break;
    case "VERIFY":
    case "UNVERIFY":
      if (!isOnlyMod || g.ctx.user.role === "ADMIN") {
        await db.user.update({ where: { id: userId }, data: { isVerified: action === "VERIFY" } });
      } else {
        return fail(403, "FORBIDDEN", "التحقق الرسمي للمدير فقط");
      }
      break;
    case "MAKE_MOD":
    case "REMOVE_MOD":
      if (g.ctx.user.role !== "ADMIN") return fail(403, "FORBIDDEN", "المدير فقط يدير المشرفين");
      await db.user.update({
        where: { id: userId },
        data: { role: action === "MAKE_MOD" ? "MODERATOR" : "USER" },
      });
      await logSecurity("ADMIN_ROLE_CHANGE", { userId: g.ctx.user.id, severity: "HIGH", details: `${target.username} → ${action}` });
      break;
  }

  return ok({ message: "تم تنفيذ الإجراء" });
});
