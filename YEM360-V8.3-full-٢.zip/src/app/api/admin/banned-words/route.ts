import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { requireRole } from "@/lib/auth";
import { invalidateBannedWordsCache } from "@/lib/moderation";
import { z } from "zod";

/** GET — banned words list. */
export const GET = handler(async (_req: NextRequest) => {
  const g = await requireRole(["ADMIN", "MODERATOR"]);
  if (g.resp) return g.resp;

  const words = await db.bannedWord.findMany({ orderBy: { createdAt: "desc" } });
  return ok({ words: words.map((w) => ({ id: w.id, word: w.word })) });
});

const postSchema = z.object({ word: z.string().min(2).max(40) });

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g = await requireRole(["ADMIN"]);
  if (g.resp) return g.resp;

  const parsed = await readJson(req, postSchema);
  if (parsed.error) return parsed.error;
  const word = parsed.data.word.trim().toLowerCase();
  await db.bannedWord.upsert({ where: { word }, update: {}, create: { word } });
  invalidateBannedWordsCache();
  return ok({ message: "تمت إضافة الكلمة لقائمة الحظر" }, 201);
});

export const DELETE = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g = await requireRole(["ADMIN"]);
  if (g.resp) return g.resp;

  const word = req.nextUrl.searchParams.get("word") || "";
  await db.bannedWord.deleteMany({ where: { word } });
  invalidateBannedWordsCache();
  return ok({ message: "تمت إزالة الكلمة" });
});
