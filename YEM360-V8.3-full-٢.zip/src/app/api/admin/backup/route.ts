import { NextRequest, NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";
import { requireRole } from "@/lib/auth";
import { fail, handler, getIp } from "@/lib/api";
import { logSecurity } from "@/lib/security";

/** GET /api/admin/backup — download a full SQLite snapshot of the database (admin only). */
export const GET = handler(async (_req: NextRequest) => {
  const g = await requireRole(["ADMIN"]);
  if (g.resp) return g.resp;

  const dbUrl = process.env.DATABASE_URL || "";
  const fileMatch = /file:(?:\/\S*?)([^/]+\.db)$/.exec(dbUrl) || /file:(.+\.db)$/.exec(dbUrl);
  let filePath: string;
  if (fileMatch) {
    filePath = dbUrl.startsWith("file:/")
      ? dbUrl.replace("file:", "")
      : path.join(process.cwd(), "db", fileMatch[1]);
  } else {
    return fail(500, "CONFIG", "مسار قاعدة البيانات غير معروف");
  }

  try {
    const data = await fs.readFile(filePath);
    await logSecurity("ADMIN_BACKUP", { userId: g.ctx.user.id, ip: getIp(_req), details: "نسخة احتياطية لقاعدة البيانات" });
    return new NextResponse(new Uint8Array(data), {
      headers: {
        "content-type": "application/octet-stream",
        "content-disposition": `attachment; filename="yem360-backup-${new Date().toISOString().slice(0, 10)}.db"`,
      },
    });
  } catch {
    return fail(500, "IO", "فشل إنشاء النسخة الاحتياطية");
  }
});
