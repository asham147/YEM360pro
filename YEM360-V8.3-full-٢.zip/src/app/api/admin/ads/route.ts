import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { requireRole } from "@/lib/auth";
import { z } from "zod";

/** GET /api/admin/ads — all campaigns (approval queue). */
export const GET = handler(async (req: NextRequest) => {
  const g = await requireRole(["ADMIN", "MODERATOR"]);
  if (g.resp) return g.resp;

  const status = req.nextUrl.searchParams.get("status");
  const ads = await db.advertisement.findMany({
    where: status ? { status } : {},
    include: { advertiser: { include: { profile: true } } },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return ok({
    ads: ads.map((a) => ({
      id: a.id, title: a.title, body: a.body, imageUrl: a.imageUrl, targetUrl: a.targetUrl,
      status: a.status, budget: a.budget, impressionCount: a.impressionCount, clickCount: a.clickCount,
      advertiser: { username: a.advertiser.username, name: a.advertiser.name },
      createdAt: a.createdAt.toISOString(),
    })),
  });
});

const patchSchema = z.object({
  adId: z.string().min(1).max(40),
  action: z.enum(["APPROVE", "REJECT", "PAUSE", "END"]),
  note: z.string().max(200).optional(),
});

/** PATCH /api/admin/ads — approve / reject / pause campaigns. */
export const PATCH = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g = await requireRole(["ADMIN", "MODERATOR"]);
  if (g.resp) return g.resp;

  const parsed = await readJson(req, patchSchema);
  if (parsed.error) return parsed.error;
  const { adId, action, note } = parsed.data;

  const ad = await db.advertisement.findUnique({ where: { id: adId } });
  if (!ad) return fail(404, "NOT_FOUND", "الحملة غير موجودة");

  const statusMap = { APPROVE: "ACTIVE", REJECT: "REJECTED", PAUSE: "PAUSED", END: "ENDED" } as const;
  await db.advertisement.update({
    where: { id: adId },
    data: { status: statusMap[action], approvedById: g.ctx.user.id },
  });
  return ok({ message: "تم تحديث حالة الحملة" });
});
