import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { requireRole } from "@/lib/auth";
import { logSecurity } from "@/lib/security";
import { z } from "zod";

/** GET /api/admin/reports?status= — moderation queue. */
export const GET = handler(async (req: NextRequest) => {
  const g = await requireRole(["ADMIN", "MODERATOR"]);
  if (g.resp) return g.resp;

  const status = req.nextUrl.searchParams.get("status") || "PENDING";
  const reports = await db.report.findMany({
    where: status === "ALL" ? {} : { status },
    include: { reporter: { include: { profile: true } }, reviewedBy: { include: { profile: true } } },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  // attach a snapshot of the reported target
  const enriched = await Promise.all(
    reports.map(async (r) => {
      let target: unknown = null;
      try {
        switch (r.targetType) {
          case "USER": {
            const u = await db.user.findUnique({ where: { id: r.targetId }, include: { profile: true } });
            target = u ? { username: u.username, name: u.name, isActive: u.isActive } : { deleted: true };
            break;
          }
          case "POST": {
            const p = await db.post.findUnique({ where: { id: r.targetId } });
            target = p ? { content: p.content.slice(0, 300), deletedAt: p.deletedAt, authorId: p.authorId } : { deleted: true };
            break;
          }
          case "COMMENT": {
            const c = await db.comment.findUnique({ where: { id: r.targetId } });
            target = c ? { text: c.text.slice(0, 300), deletedAt: c.deletedAt, authorId: c.authorId } : { deleted: true };
            break;
          }
          case "REEL": {
            const rl = await db.reel.findUnique({ where: { id: r.targetId } });
            target = rl ? { caption: rl.caption, deletedAt: rl.deletedAt, authorId: rl.userId } : { deleted: true };
            break;
          }
          case "PRODUCT": {
            const p = await db.product.findUnique({ where: { id: r.targetId } });
            target = p ? { title: p.title, description: p.description.slice(0, 300), deletedAt: p.deletedAt, authorId: p.sellerId } : { deleted: true };
            break;
          }
          case "MESSAGE": {
            const m = await db.message.findUnique({ where: { id: r.targetId } });
            target = m ? { text: m.text?.slice(0, 300), deletedAt: m.deletedAt, authorId: m.senderId } : { deleted: true };
            break;
          }
          case "STORY": {
            const s = await db.story.findUnique({ where: { id: r.targetId } });
            target = s ? { text: s.text, deletedAt: s.expiresAt < new Date() ? s.expiresAt : null, authorId: s.userId } : { deleted: true };
            break;
          }
        }
      } catch {
        target = null;
      }
      return {
        id: r.id,
        targetType: r.targetType,
        targetId: r.targetId,
        reason: r.reason,
        details: r.details,
        status: r.status,
        action: r.action,
        createdAt: r.createdAt.toISOString(),
        reporter: r.reporter ? { username: r.reporter.username, name: r.reporter.name } : null,
        reviewedBy: r.reviewedBy ? { username: r.reviewedBy.username } : null,
        reviewedAt: r.reviewedAt?.toISOString() ?? null,
        target,
      };
    })
  );

  return ok({ reports: enriched });
});

const actionSchema = z.object({
  reportId: z.string().min(1).max(40),
  action: z.enum(["DISMISS", "DELETE_CONTENT", "BAN_USER", "MARK_REVIEWED"]),
  note: z.string().max(200).optional(),
});

/** PATCH /api/admin/reports — resolve a report. */
export const PATCH = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g = await requireRole(["ADMIN", "MODERATOR"]);
  if (g.resp) return g.resp;

  const parsed = await readJson(req, actionSchema);
  if (parsed.error) return parsed.error;
  const { reportId, action, note } = parsed.data;

  const report = await db.report.findUnique({ where: { id: reportId } });
  if (!report) return fail(404, "NOT_FOUND", "البلاغ غير موجود");

  let banUserId: string | null = null;
  if (action === "DELETE_CONTENT" || action === "BAN_USER") {
    switch (report.targetType) {
      case "POST": {
        const p = await db.post.findUnique({ where: { id: report.targetId } });
        if (p && !p.deletedAt) {
          await db.post.update({ where: { id: p.id }, data: { deletedAt: new Date() } });
          if (action === "BAN_USER") banUserId = p.authorId;
        }
        break;
      }
      case "COMMENT": {
        const c = await db.comment.findUnique({ where: { id: report.targetId } });
        if (c && !c.deletedAt) {
          await db.comment.updateMany({ where: { OR: [{ id: c.id }, { parentId: c.id }] }, data: { deletedAt: new Date() } });
          if (action === "BAN_USER") banUserId = c.authorId;
        }
        break;
      }
      case "REEL": {
        const r = await db.reel.findUnique({ where: { id: report.targetId } });
        if (r && !r.deletedAt) {
          await db.reel.update({ where: { id: r.id }, data: { deletedAt: new Date() } });
          if (action === "BAN_USER") banUserId = r.userId;
        }
        break;
      }
      case "USER": {
        if (action === "BAN_USER") banUserId = report.targetId;
        break;
      }
      case "MESSAGE": {
        const m = await db.message.findUnique({ where: { id: report.targetId } });
        if (m) await db.message.update({ where: { id: m.id }, data: { deletedAt: new Date() } });
        if (action === "BAN_USER") banUserId = m?.senderId ?? null;
        break;
      }
      case "PRODUCT": {
        const p = await db.product.findUnique({ where: { id: report.targetId } });
        if (p) await db.product.update({ where: { id: p.id }, data: { deletedAt: new Date(), status: "HIDDEN" } });
        if (action === "BAN_USER") banUserId = p?.sellerId ?? null;
        break;
      }
    }
  }

  if (banUserId) {
    const target = await db.user.findUnique({ where: { id: banUserId } });
    if (target && target.role !== "ADMIN") {
      await db.user.update({
        where: { id: banUserId },
        data: { isActive: false, banReason: note || "مخالفات متكررة بعد بلاغات موثقة" },
      });
      await db.loginSession.updateMany({ where: { userId: banUserId, revokedAt: null }, data: { revokedAt: new Date() } });
    }
  }

  await db.report.update({
    where: { id: reportId },
    data: {
      status: action === "DISMISS" ? "DISMISSED" : "ACTIONED",
      action,
      reviewedById: g.ctx.user.id,
      reviewedAt: new Date(),
    },
  });
  await logSecurity("ADMIN_REPORT_ACTION", {
    userId: g.ctx.user.id,
    severity: action === "BAN_USER" ? "HIGH" : "INFO",
    details: `${report.targetType}#${report.targetId.slice(0, 12)} → ${action}`,
  });

  return ok({ message: "تم التعامل مع البلاغ" });
});
