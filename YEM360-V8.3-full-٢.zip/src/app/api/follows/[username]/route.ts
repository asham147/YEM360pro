import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { notify } from "@/lib/notify";

/** POST /api/follows/[username] — follow (or request if the account is private). */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ username: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const rl = rateLimit(`follow:${ctx.user.id}`, 60, 10 * 60 * 1000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "متابعات متكررة، انتظر قليلاً");
    const { username } = await params;

    const target = await db.user.findUnique({ where: { username }, include: { privacySetting: true } });
    if (!target || !target.isActive) return fail(404, "NOT_FOUND", "الحساب غير موجود");
    if (target.id === ctx.user.id) return fail(400, "SELF", "لا يمكنك متابعة نفسك");

    const block = await db.block.findFirst({
      where: {
        OR: [
          { blockerId: ctx.user.id, blockedId: target.id },
          { blockerId: target.id, blockedId: ctx.user.id },
        ],
      },
    });
    if (block) return fail(403, "BLOCKED", "لا يمكن المتابعة بسبب الحظر");

    const existing = await db.follow.findFirst({
      where: { followerId: ctx.user.id, followingId: target.id },
    });
    if (existing?.status === "ACCEPTED") return ok({ status: "ACCEPTED", alreadyFollowing: true });
    if (existing?.status === "PENDING") return ok({ status: "PENDING", alreadyPending: true });

    const isPrivate = target.privacySetting?.privateAccount ?? false;
    const status = isPrivate ? "PENDING" : "ACCEPTED";
    await db.follow.upsert({
      where: { followerId_followingId: { followerId: ctx.user.id, followingId: target.id } },
      update: { status },
      create: { followerId: ctx.user.id, followingId: target.id, status },
    });

    await notify({
      userId: target.id,
      actorId: ctx.user.id,
      type: "FOLLOW",
      entityType: "USER",
      entityId: ctx.user.id,
      text: isPrivate ? "طلب متابعة حسابك" : "بدأ متابعتك",
    });

    return ok({ status }, 201);
  }
);

/** DELETE /api/follows/[username] — unfollow (also cancels a pending request). */
export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ username: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { username } = await params;

    const target = await db.user.findUnique({ where: { username } });
    if (!target) return fail(404, "NOT_FOUND", "الحساب غير موجود");

    await db.follow.deleteMany({ where: { followerId: ctx.user.id, followingId: target.id } });
    return ok({ status: null });
  }
);
