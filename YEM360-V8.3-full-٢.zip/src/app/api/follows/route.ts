import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { publicUser } from "@/lib/serialize";

/**
 * GET /api/follows?username=<u>&type=followers|following
 * Followers / following lists with per-viewer relationship flags.
 */
export const GET = handler(async (req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const username = req.nextUrl.searchParams.get("username") || ctx.user.username;
  const type = req.nextUrl.searchParams.get("type") === "following" ? "following" : "followers";

  const target = await db.user.findUnique({ where: { username } });
  if (!target) return ok({ users: [] });

  const rows = await (type === "followers"
    ? db.follow.findMany({
        where: { followingId: target.id, status: "ACCEPTED" },
        include: { follower: { include: { profile: true } } },
        orderBy: { createdAt: "desc" },
        take: 100,
      })
    : db.follow.findMany({
        where: { followerId: target.id, status: "ACCEPTED" },
        include: { following: { include: { profile: true } } },
        orderBy: { createdAt: "desc" },
        take: 100,
      }));

  const users = rows
    .map((r) => (type === "followers" ? r.follower : r.following))
    .filter((u) => u.isActive);

  // relationship flags for the viewer
  const relRows = await db.follow.findMany({
    where: { followerId: ctx.user.id, followingId: { in: users.map((u) => u.id) } },
  });
  const relMap = new Map(relRows.map((r) => [r.followingId, r.status]));

  return ok({
    users: users.map((u) => ({
      ...publicUser(u, u.profile),
      relationshipStatus: relMap.get(u.id) ?? null,
    })),
  });
});
