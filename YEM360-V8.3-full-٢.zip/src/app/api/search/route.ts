import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { visiblePostsWhere, blockedPairIds } from "@/lib/privacy";
import { publicUser } from "@/lib/serialize";
import { serializePost, serializePosts, type PostWithRelations } from "@/lib/serialize-posts";
import { rateLimit } from "@/lib/rate-limit";

/** GET /api/search?q= — users + posts + hashtags + products. */
export const GET = handler(async (req: NextRequest) => {
  const g = await authGuard();
  if (!g.ctx) return g.resp;
  const viewerId = g.ctx.user.id;
  const rl = rateLimit(`search:${viewerId}`, 60, 60_000);
  if (!rl.allowed) return ok({ users: [], posts: [], hashtags: [], products: [] });

  const q = (req.nextUrl.searchParams.get("q") || "").trim();
  if (q.length < 1) return ok({ users: [], posts: [], hashtags: [], products: [] });
  if (q.length > 50) q.slice(0, 50);

  const blocked = await blockedPairIds(viewerId);
  const userFilter = {
    isActive: true,
    id: { not: viewerId, ...(blocked.length ? { notIn: blocked } : {}) },
    OR: [{ username: { contains: q } }, { name: { contains: q } }],
  };

  const [users, posts, hashtags, products] = await Promise.all([
    db.user.findMany({
      where: userFilter,
      include: { profile: true, _count: { select: { followers: true } } },
      take: 8,
      orderBy: { lastActiveAt: "desc" },
    }),
    db.post.findMany({
      where: {
        ...(visiblePostsWhere(viewerId) as Prisma.PostWhereInput),
        content: { contains: q },
      },
      include: {
        author: { include: { profile: true } },
        media: true,
        hashtags: { include: { hashtag: true } },
        likes: { select: { userId: true } },
        saves: { select: { userId: true } },
        reposts: { select: { authorId: true } },
        _count: { select: { likes: true, comments: true, reposts: true } },
        repostOf: { include: { author: { include: { profile: true } }, media: true, hashtags: { include: { hashtag: true } }, likes: { select: { userId: true } }, saves: { select: { userId: true } }, reposts: { select: { authorId: true } }, _count: { select: { likes: true, comments: true, reposts: true } } } },
      },
      take: 10,
      orderBy: { createdAt: "desc" },
    }),
    db.hashtag.findMany({
      where: { name: { contains: q } },
      orderBy: { useCount: "desc" },
      take: 8,
    }),
    db.product.findMany({
      where: { status: "AVAILABLE", deletedAt: null, title: { contains: q } },
      include: { images: true, seller: { include: { profile: true } } },
      take: 8,
      orderBy: { createdAt: "desc" },
    }),
  ]);

  const relRows = await db.follow.findMany({
    where: { followerId: viewerId, followingId: { in: users.map((u) => u.id) } },
  });
  const relMap = new Map(relRows.map((r) => [r.followingId, r.status]));

  return ok({
    users: users.map((u) => ({ ...publicUser(u, u.profile), followerCount: u._count.followers, relationshipStatus: relMap.get(u.id) ?? null })),
    posts: serializePosts(posts as PostWithRelations[], viewerId),
    hashtags: hashtags.map((h) => ({ name: h.name, useCount: h.useCount })),
    products: products.map((p) => ({
      id: p.id, title: p.title, price: p.price, currency: p.currency,
      image: p.images[0]?.url ?? null, seller: p.seller.username,
    })),
  });
});
