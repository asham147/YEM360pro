import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";

export const GET = handler(async (_req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const events = await db.securityEvent.findMany({
    where: { userId: ctx.user.id },
    orderBy: { createdAt: "desc" },
    take: 60,
  });
  return ok({
    twoFactorEnabled: ctx.user.twoFactorEnabled,
    events: events.map((e) => ({
      id: e.id,
      type: e.type,
      severity: e.severity,
      ip: e.ip,
      details: e.details,
      createdAt: e.createdAt,
    })),
  });
});
