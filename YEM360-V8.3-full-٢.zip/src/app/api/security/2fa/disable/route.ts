import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, getIp, handler } from "@/lib/api";
import { authGuard, verifyPassword } from "@/lib/auth";
import { logSecurity } from "@/lib/security";
import { z } from "zod";

const disableSchema = z.object({ password: z.string().min(1).max(72) });

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const parsed = await readJson(req, disableSchema);
  if (parsed.error) return parsed.error;

  const valid = await verifyPassword(parsed.data.password, ctx.user.passwordHash);
  if (!valid) {
    await logSecurity("2FA_DISABLE_FAILED", { userId: ctx.user.id, severity: "WARN", ip: getIp(req) });
    return fail(401, "WRONG_PASSWORD", "كلمة المرور غير صحيحة");
  }

  await db.user.update({
    where: { id: ctx.user.id },
    data: { twoFactorEnabled: false, twoFactorSecret: null },
  });
  await logSecurity("2FA_DISABLED", { userId: ctx.user.id, severity: "HIGH", ip: getIp(req) });
  return ok({ message: "تم إيقاف التحقق الثنائي" });
});
