import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, getIp, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { decryptText, verifyTotp } from "@/lib/crypto";
import { logSecurity } from "@/lib/security";
import { twoFactorSchema } from "@/lib/validators";

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  if (!ctx.user.twoFactorSecret) return fail(400, "NO_SETUP", "ابدأ بإعداد التحقق الثنائي أولاً");

  const parsed = await readJson(req, twoFactorSchema);
  if (parsed.error) return parsed.error;

  const secret = decryptText(ctx.user.twoFactorSecret);
  if (!secret || !verifyTotp(secret, parsed.data.code)) {
    await logSecurity("2FA_ENABLE_FAILED", { userId: ctx.user.id, severity: "WARN", ip: getIp(req) });
    return fail(401, "INVALID_CODE", "الرمز غير صحيح — تأكد من تطابق وقت الجهاز");
  }

  await db.user.update({ where: { id: ctx.user.id }, data: { twoFactorEnabled: true } });
  await logSecurity("2FA_ENABLED", { userId: ctx.user.id, severity: "HIGH", ip: getIp(req) });
  return ok({ message: "تم تفعيل التحقق الثنائي بنجاح" });
});
