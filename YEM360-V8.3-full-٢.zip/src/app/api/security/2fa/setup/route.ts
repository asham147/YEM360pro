import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { generateTotpSecret, encryptText, otpauthUrl } from "@/lib/crypto";
import { rateLimit } from "@/lib/rate-limit";

/** Step 1 of enabling 2FA: returns otpauth URL + QR data-URL, secret stored encrypted but NOT enabled. */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`2fa-setup:${ctx.user.id}`, 5, 15 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "محاولات كثيرة، انتظر قليلاً");
  if (ctx.user.twoFactorEnabled) return fail(409, "ALREADY_ENABLED", "التحقق الثنائي مُفعّل مسبقاً");

  const secret = generateTotpSecret();
  await db.user.update({
    where: { id: ctx.user.id },
    data: { twoFactorSecret: encryptText(secret), twoFactorEnabled: false },
  });

  const url = otpauthUrl(ctx.user.email, secret);
  let qrDataUrl: string | null = null;
  try {
    const QRCode = (await import("qrcode")).default;
    qrDataUrl = await QRCode.toDataURL(url, { width: 220, margin: 1 });
  } catch {
    qrDataUrl = null;
  }

  return ok({ otpauthUrl: url, secret, qrDataUrl });
});
