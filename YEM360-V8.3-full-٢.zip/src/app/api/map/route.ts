import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { visiblePostsWhere } from "@/lib/privacy";
import { serializePost, type PostWithRelations } from "@/lib/serialize-posts";

/** GET /api/map — geo-tagged public posts for the map view. */
export const GET = handler(async (_req: NextRequest) => {
  const g = await authGuard();
  if (g.resp) return g.resp;
  const viewerId = g.ctx.user.id;

  const posts = await db.post.findMany({
    where: {
      ...(visiblePostsWhere(viewerId) as Prisma.PostWhereInput),
      latitude: { not: null },
      longitude: { not: null },
      createdAt: { gte: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000) },
    },
    include: {
      author: { include: { profile: true } },
      media: true,
      hashtags: { include: { hashtag: true } },
      likes: { select: { userId: true } },
      saves: { select: { userId: true } },
      reposts: { select: { authorId: true } },
        _count: { select: { likes: true, comments: true, reposts: true } },
      repostOf: { include: { author: { include: { profile: true } }, media: true, hashtags: { include: { hashtag: true } }, likes: { select: { userId: true } }, saves: { select: { userId: true } }, reposts: { select: { authorId: true } }, _count: { select: { likes: true, comments: true, reposts: true } } } },
    },
    orderBy: { createdAt: "desc" },
    take: 120,
  });

  return ok({
    posts: (posts as PostWithRelations[]).map((p) => serializePost(p, viewerId)),
  });
});
