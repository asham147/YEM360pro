import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { productSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { publicUser } from "@/lib/serialize";

/** GET /api/products — marketplace listing (search / category / my items). */
export const GET = handler(async (req: NextRequest) => {
  const g = await authGuard();
  if (!g.ctx) return g.resp;
  const mine = req.nextUrl.searchParams.get("mine") === "1";
  const q = req.nextUrl.searchParams.get("q")?.trim();
  const category = req.nextUrl.searchParams.get("category")?.trim();
  const page = Math.max(Number(req.nextUrl.searchParams.get("page") || 1), 1);
  const per = 20;

  const where = {
    deletedAt: null,
    ...(mine ? { sellerId: g.ctx.user.id } : { status: "AVAILABLE" }),
    ...(q ? { OR: [{ title: { contains: q } }, { description: { contains: q } }] } : {}),
    ...(category && category !== "ALL" ? { category } : {}),
  };

  const [products, total] = await Promise.all([
    db.product.findMany({
      where,
      include: { images: true, seller: { include: { profile: true } } },
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * per,
      take: per,
    }),
    db.product.count({ where }),
  ]);

  return ok({
    products: products.map((p) => ({
      id: p.id, title: p.title, description: p.description, price: p.price, currency: p.currency,
      category: p.category, stock: p.stock, status: p.status, viewCount: p.viewCount,
      images: p.images.map((i) => i.url),
      seller: publicUser(p.seller, p.seller.profile),
      isMine: p.sellerId === g.ctx.user.id,
      createdAt: p.createdAt.toISOString(),
    })),
    total,
    page,
    hasMore: page * per < total,
  });
});

/** POST /api/products — list a product for sale. */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`product:${ctx.user.id}`, 15, 60 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "أضفت منتجات كثيرة، انتظر قليلاً");

  const parsed = await readJson(req, productSchema);
  if (parsed.error) return parsed.error;
  const d = parsed.data;

  const banned = await checkText(`${d.title} ${d.description}`);
  if (banned.length) return fail(422, "CONTENT_BLOCKED", "المنتج يحتوي على كلمات غير مسموحة");

  const product = await db.product.create({
    data: {
      sellerId: ctx.user.id,
      title: d.title, description: d.description, price: d.price, currency: d.currency,
      category: d.category, stock: d.stock,
    },
  });
  if (d.imageUrls.length) {
    await db.productImage.createMany({
      data: d.imageUrls.map((url, i) => ({ productId: product.id, url, orderIndex: i })),
    });
  }
  return ok({ id: product.id, message: "تم نشر المنتج" }, 201);
});
