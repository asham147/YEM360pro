import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { productSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { publicUser } from "@/lib/serialize";
import { deleteMediaFile } from "@/lib/media";

export const GET = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g = await authGuard();
    if (!g.ctx) return g.resp;
    const { id } = await params;

    const product = await db.product.findUnique({
      where: { id },
      include: { images: true, seller: { include: { profile: true } } },
    });
    if (!product || product.deletedAt) return fail(404, "NOT_FOUND", "المنتج غير موجود");

    await db.product.update({ where: { id }, data: { viewCount: { increment: 1 } } }).catch(() => null);

    return ok({
      product: {
        id: product.id, title: product.title, description: product.description,
        price: product.price, currency: product.currency, category: product.category,
        stock: product.stock, status: product.status, viewCount: product.viewCount,
        images: product.images.map((i) => i.url),
        seller: publicUser(product.seller, product.seller.profile),
        isMine: product.sellerId === g.ctx.user.id,
        createdAt: product.createdAt.toISOString(),
      },
    });
  }
);

const patchSchema = productSchema.partial().omit({ imageUrls: true }).extend({
  status: z.enum(["AVAILABLE", "SOLD_OUT", "HIDDEN"]).optional(),
  addImageUrls: z.array(z.string().max(300)).max(4).optional(),
});

export const PATCH = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const product = await db.product.findUnique({ where: { id } });
    if (!product || product.deletedAt) return fail(404, "NOT_FOUND", "المنتج غير موجود");
    if (product.sellerId !== ctx.user.id) return fail(403, "FORBIDDEN", "يمكنك تعديل منتجاتك فقط");

    const parsed = await readJson(req, patchSchema);
    if (parsed.error) return parsed.error;
    const { addImageUrls, ...d } = parsed.data;

    if (d.title || d.description) {
      const banned = await checkText(`${d.title || ""} ${d.description || ""}`);
      if (banned.length) return fail(422, "CONTENT_BLOCKED", "المنتج يحتوي على كلمات غير مسموحة");
    }

    await db.product.update({ where: { id }, data: d });
    if (addImageUrls?.length) {
      const count = await db.productImage.count({ where: { productId: id } });
      await db.productImage.createMany({
        data: addImageUrls.slice(0, Math.max(0, 4 - count)).map((url, i) => ({
          productId: id, url, orderIndex: count + i,
        })),
      });
    }
    return ok({ message: "تم تحديث المنتج" });
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const product = await db.product.findUnique({ where: { id }, include: { images: true } });
    if (!product || product.deletedAt) return fail(404, "NOT_FOUND", "المنتج غير موجود");
    if (product.sellerId !== ctx.user.id) return fail(403, "FORBIDDEN", "يمكنك حذف منتجاتك فقط");

    await db.product.update({ where: { id }, data: { deletedAt: new Date(), status: "HIDDEN" } });
    return ok({ message: "تم حذف المنتج" });
  }
);
