import { NextRequest, NextResponse } from "next/server";
import fs from "fs/promises";
import path from "path";
import { handler, fail } from "@/lib/api";
import { mediaUrlToFile } from "@/lib/media";
import { rateLimit } from "@/lib/rate-limit";
import { getIp } from "@/lib/api";

const MIME: Record<string, string> = {
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png",
  webp: "image/webp", gif: "image/gif", mp4: "video/mp4", webm: "video/webm",
};

/**
 * Serves uploads from the (non-public) uploads directory.
 * Filenames are unguessable (>=96-bit random + timestamp); directory
 * traversal is impossible via the strict regex in mediaUrlToFile().
 */
export const GET = handler(
  async (req: NextRequest, { params }: { params: Promise<{ name: string[] }> }) => {
    const rl = rateLimit(`media:${getIp(req)}`, 600, 60_000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "طلبات كثيرة");

    const { name } = await params;
    if (!name || name.length !== 2) return fail(404, "NOT_FOUND");
    const filePath = mediaUrlToFile(`/api/media/${name[0]}/${name[1]}`);
    if (!filePath) return fail(404, "NOT_FOUND");

    const ext = path.extname(filePath).slice(1).toLowerCase();
    const mime = MIME[ext];
    if (!mime) return fail(404, "NOT_FOUND");

    try {
      const data = await fs.readFile(filePath);
      // ?dl=1 → force download (Content-Disposition: attachment) for reels/posts media saving.
      const headers: Record<string, string> = {
        "content-type": mime,
        "cache-control": "private, max-age=31536000, immutable",
        "x-content-type-options": "nosniff",
      };
      if (req.nextUrl.searchParams.get("dl") === "1") {
        headers["content-disposition"] = `attachment; filename="yem360_${Date.now()}.${ext}"`;
        headers["cache-control"] = "private, no-store";
      }
      return new NextResponse(new Uint8Array(data), { headers });
    } catch {
      return fail(404, "NOT_FOUND", "الملف غير موجود");
    }
  }
);
