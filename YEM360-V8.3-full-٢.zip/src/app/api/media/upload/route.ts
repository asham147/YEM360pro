/**
 * YEM360 — Media upload endpoint (POST /api/media/upload).
 *
 * The secure pipeline lives in lib/media.ts (magic-byte sniffing, sharp
 * re-encode to strip EXIF/GPS, hard size caps, unguessable filenames stored
 * outside public/). This route wires it to the client contract used by
 * uploadFileWithProgress(): FormData { file, kind } → { ok, media }.
 *
 * Kinds map 1:1 to uploads subdirectories:
 *   post | story | reel | avatar | cover | message | product | ad
 */
import { NextRequest } from "next/server";
import { handler, ok, fail, sameOrigin, getIp } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { saveUpload, deleteMediaFile, type MediaKind } from "@/lib/media";

const KINDS: MediaKind[] = ["post", "story", "reel", "avatar", "cover", "message", "product", "ad"];

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g = await authGuard();
  if (!g.ctx) return g.resp;
  const { ctx } = g;

  // generous but bounded: 40 uploads / 15 min / user (covers reels + stories bursts)
  const rl = rateLimit(`upload:${ctx.user.id}`, 40, 15 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "رفعت ملفات كثيرة، انتظر قليلاً ثم حاول مجدداً");

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail(400, "BAD_FORM", "صيغة الطلب غير صالحة");
  }

  const file = form.get("file");
  const kindRaw = form.get("kind");
  if (!(file instanceof File) || file.size === 0) {
    return fail(400, "NO_FILE", "لم يتم اختيار ملف");
  }
  const kind = String(kindRaw || "post") as MediaKind;
  if (!KINDS.includes(kind)) return fail(400, "BAD_KIND", "نوع الرفع غير معروف");

  try {
    const media = await saveUpload(file, kind, { square: kind === "avatar" });
    if (kind === "reel" && media.type !== "VIDEO") {
      await deleteMediaFile(media.url);
      return fail(400, "NOT_VIDEO", "الريل يجب أن يكون ملف فيديو (MP4 أو WEBM)");
    }
    return ok({ media }, 201);
  } catch (e) {
    const status = (e as { status?: number })?.status ?? 500;
    const msg = e instanceof Error ? e.message : "فشل الرفع";
    if (status >= 400 && status < 500) return fail(status, "UPLOAD_REJECTED", msg);
    throw e;
  }
});
