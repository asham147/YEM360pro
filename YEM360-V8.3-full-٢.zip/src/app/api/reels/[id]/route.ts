import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { serializeReel } from "@/lib/serialize-posts";
import { canViewPrivateContent } from "@/lib/privacy";
import { deleteMediaFile } from "@/lib/media";

export const GET = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g = await authGuard();
    const viewerId = g.ctx?.user.id ?? null;
    const { id } = await params;

    const reel = await db.reel.findUnique({
      where: { id },
      include: {
        user: { include: { profile: true, privacySetting: true } },
        likes: { select: { userId: true } },
        _count: { select: { likes: true, comments: true } },
      },
    });
    if (!reel || reel.deletedAt) return fail(404, "NOT_FOUND", "الريل غير موجود");
    if (!(await canViewPrivateContent(viewerId, reel.user))) {
      return fail(403, "PRIVATE", "هذا الحساب خاص");
    }

    // count a view
    await db.reel.update({ where: { id }, data: { viewCount: { increment: 1 } } }).catch(() => null);
    return ok({ reel: serializeReel(reel, viewerId) });
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    const reel = await db.reel.findUnique({ where: { id } });
    if (!reel || reel.deletedAt) return fail(404, "NOT_FOUND", "الريل غير موجود");
    const isStaff = ctx.user.role === "ADMIN" || ctx.user.role === "MODERATOR";
    if (reel.userId !== ctx.user.id && !isStaff) return fail(403, "FORBIDDEN", "يمكنك حذف ريلاتك فقط");

    await db.reel.update({ where: { id }, data: { deletedAt: new Date() } });
    await deleteMediaFile(reel.videoUrl);
    return ok({ message: "تم حذف الريل" });
  }
);
