import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { notify } from "@/lib/notify";

export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const rl = rateLimit(`reel-like:${ctx.user.id}`, 120, 60_000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "بطء شديد");
    const { id } = await params;

    const reel = await db.reel.findUnique({ where: { id } });
    if (!reel || reel.deletedAt) return fail(404, "NOT_FOUND", "الريل غير موجود");

    const existing = await db.like.findFirst({ where: { userId: ctx.user.id, reelId: id } });
    if (existing) return ok({ liked: true, alreadyLiked: true });

    await db.like.create({ data: { userId: ctx.user.id, reelId: id } });
    await notify({
      userId: reel.userId,
      actorId: ctx.user.id,
      type: "LIKE",
      entityType: "REEL",
      entityId: id,
      text: "أعجب بالريل الخاص بك",
    });
    const count = await db.like.count({ where: { reelId: id } });
    return ok({ liked: true, likeCount: count }, 201);
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    await db.like.deleteMany({ where: { userId: ctx.user.id, reelId: id } });
    const count = await db.like.count({ where: { reelId: id } });
    return ok({ liked: false, likeCount: count });
  }
);
