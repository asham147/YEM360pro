import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, getIp, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";

/**
 * POST /api/reels/[id]/view — count a view when a reel becomes visible in the
 * feed (the client calls this once per reel per session). Anonymous views are
 * counted too, but the endpoint is rate-limited per IP to prevent inflation.
 */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g = await authGuard();
    const viewerId = g.ctx?.user.id ?? null;
    const ip = getIp(req);

    const rl = rateLimit(`reel-view:${viewerId ?? ip}`, 240, 60_000);
    if (!rl.allowed) return ok({ counted: false });

    const { id } = await params;
    const reel = await db.reel.findUnique({ where: { id }, select: { id: true, deletedAt: true } });
    if (!reel || reel.deletedAt) return fail(404, "NOT_FOUND", "الريل غير موجود");

    await db.reel.update({ where: { id }, data: { viewCount: { increment: 1 } } }).catch(() => null);
    return ok({ counted: true });
  }
);
