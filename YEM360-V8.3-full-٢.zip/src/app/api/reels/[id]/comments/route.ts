import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { commentCreateSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { notify } from "@/lib/notify";
import { serializeComment, type CommentWithRelations } from "@/lib/serialize-posts";

const include = {
  author: { include: { profile: true } },
  likes: { select: { userId: true } },
  _count: { select: { likes: true, replies: true } },
  replies: {
    include: { author: { include: { profile: true } }, likes: { select: { userId: true } }, _count: { select: { likes: true } } },
    orderBy: { createdAt: "asc" as const },
  },
} satisfies Prisma.CommentInclude;

export const GET = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g = await authGuard();
    const viewerId = g.ctx?.user.id ?? null;
    const { id } = await params;

    const comments = await db.comment.findMany({
      where: { reelId: id, parentId: null, deletedAt: null },
      include,
      orderBy: { createdAt: "desc" },
      take: 50,
    });
    return ok({ comments: comments.map((c) => serializeComment(c as CommentWithRelations, viewerId)) });
  }
);

export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const rl = rateLimit(`reel-comment:${ctx.user.id}`, 30, 10 * 60 * 1000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "علّقت بشكل متكرر");
    const { id } = await params;

    const parsed = await readJson(req, commentCreateSchema);
    if (parsed.error) return parsed.error;
    const { text, parentId } = parsed.data;

    const banned = await checkText(text);
    if (banned.length) return fail(422, "CONTENT_BLOCKED", "التعليق يحتوي على كلمات غير مسموحة");

    const reel = await db.reel.findUnique({ where: { id } });
    if (!reel || reel.deletedAt) return fail(404, "NOT_FOUND", "الريل غير موجود");

    let parentAuthorId: string | null = null;
    if (parentId) {
      const parent = await db.comment.findFirst({ where: { id: parentId, reelId: id, deletedAt: null } });
      if (!parent) return fail(404, "NOT_FOUND", "التعليق الأصلي غير موجود");
      parentAuthorId = parent.authorId;
    }

    const comment = await db.comment.create({
      data: { authorId: ctx.user.id, reelId: id, parentId, text: text.trim() },
    });
    await notify({
      userId: reel.userId,
      actorId: ctx.user.id,
      type: "COMMENT",
      entityType: "REEL",
      entityId: id,
      text: "علّق على الريل الخاص بك",
    });
    if (parentAuthorId && parentAuthorId !== reel.userId) {
      await notify({
        userId: parentAuthorId,
        actorId: ctx.user.id,
        type: "COMMENT_REPLY",
        entityType: "REEL",
        entityId: id,
        text: "ردّ على تعليقك",
      });
    }

    const fresh = (await db.comment.findUnique({ where: { id: comment.id }, include })) as CommentWithRelations;
    return ok({ comment: serializeComment(fresh, ctx.user.id) }, 201);
  }
);
