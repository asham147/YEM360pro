import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { reelCreateSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { blockedPairIds } from "@/lib/privacy";
import { serializeReel, type ReelWithRelations } from "@/lib/serialize-posts";

const include = {
  user: { include: { profile: true } },
  likes: { select: { userId: true } },
  _count: { select: { likes: true, comments: true } },
} satisfies Prisma.ReelInclude;

/** GET /api/reels — vertical video feed (public reels + own), cursor pagination. */
export const GET = handler(async (req: NextRequest) => {
  const g = await authGuard();
  const viewerId = g.ctx?.user.id ?? null;
  const cursor = req.nextUrl.searchParams.get("cursor");
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") || 6), 12);

  const blocked = viewerId ? await blockedPairIds(viewerId) : [];
  const where: Prisma.ReelWhereInput = {
    deletedAt: null,
    user: { isActive: true, ...(blocked.length ? { id: { notIn: blocked } } : {}) },
  };
  if (cursor) where.createdAt = { lt: new Date(cursor) };

  const reels = await db.reel.findMany({
    where,
    include,
    orderBy: { createdAt: "desc" },
    take: limit + 1,
  });
  const hasMore = reels.length > limit;
  const page = reels.slice(0, limit) as ReelWithRelations[];
  return ok({
    reels: page.map((r) => serializeReel(r, viewerId)),
    nextCursor: hasMore && page.length ? page[page.length - 1].createdAt.toISOString() : null,
  });
});

/** POST /api/reels — publish a reel (video upload required). */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
  const rl = rateLimit(`reel:${ctx.user.id}`, 10, 30 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "نشرت ريلز كثيرة، انتظر قليلاً");

  const parsed = await readJson(req, reelCreateSchema);
  if (parsed.error) return parsed.error;
  const { caption, videoUrl, duration, musicName } = parsed.data;

  if (caption) {
    const banned = await checkText(caption);
    if (banned.length) return fail(422, "CONTENT_BLOCKED", "الوصف يحتوي على كلمات غير مسموحة");
  }

  const reel = await db.reel.create({
    data: { userId: ctx.user.id, caption: caption?.trim() || null, videoUrl, duration, musicName },
  });

  return ok({ reel: { id: reel.id } }, 201);
});
