import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { notify } from "@/lib/notify";

/** POST /api/friends/requests/[id] — accept a pending request. */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const fr = await db.friendship.findUnique({ where: { id } });
    if (!fr || fr.status !== "PENDING") return fail(404, "NOT_FOUND", "الطلب غير موجود");
    if (fr.addresseeId !== ctx.user.id) return fail(403, "FORBIDDEN", "هذا الطلب ليس موجهاً إليك");

    await db.friendship.update({ where: { id }, data: { status: "ACCEPTED" } });
    await notify({
      userId: fr.requesterId,
      actorId: ctx.user.id,
      type: "FRIEND_ACCEPT",
      entityType: "USER",
      entityId: ctx.user.id,
      text: "قبل طلب الصداقة",
    });
    return ok({ status: "ACCEPTED" });
  }
);

/** DELETE /api/friends/requests/[id] — reject a request or unfriend. */
export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const fr = await db.friendship.findUnique({ where: { id } });
    if (!fr) return fail(404, "NOT_FOUND", "غير موجود");
    if (fr.requesterId !== ctx.user.id && fr.addresseeId !== ctx.user.id) {
      return fail(403, "FORBIDDEN", "غير مسموح");
    }
    await db.friendship.delete({ where: { id } });
    return ok({ status: null });
  }
);
