import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { notify } from "@/lib/notify";
import { publicUser } from "@/lib/serialize";
import { z } from "zod";

/** GET /api/friends — accepted friends + incoming/outgoing requests. */
export const GET = handler(async (_req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const me = ctx.user.id;

  const [acceptedRows, incomingRows, outgoingRows] = await Promise.all([
    db.friendship.findMany({
      where: {
        status: "ACCEPTED",
        OR: [{ requesterId: me }, { addresseeId: me }],
      },
      include: { requester: { include: { profile: true } }, addressee: { include: { profile: true } } },
    }),
    db.friendship.findMany({
      where: { addresseeId: me, status: "PENDING" },
      include: { requester: { include: { profile: true } } },
      orderBy: { createdAt: "desc" },
    }),
    db.friendship.findMany({
      where: { requesterId: me, status: "PENDING" },
      include: { addressee: { include: { profile: true } } },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  const friendOf = (f: typeof acceptedRows[number]) =>
    f.requesterId === me ? f.addressee : f.requester;

  return ok({
    friends: acceptedRows.map((f) => ({
      id: f.id,
      user: publicUser(friendOf(f), friendOf(f).profile),
      since: f.updatedAt.toISOString(),
    })),
    incoming: incomingRows.map((f) => ({
      id: f.id,
      user: publicUser(f.requester, f.requester.profile),
      createdAt: f.createdAt.toISOString(),
    })),
    outgoing: outgoingRows.map((f) => ({
      id: f.id,
      user: publicUser(f.addressee, f.addressee.profile),
      createdAt: f.createdAt.toISOString(),
    })),
  });
});

const sendSchema = z.object({ userId: z.string().min(1).max(40) });

/** POST /api/friends — send a friend request. */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`friend:${ctx.user.id}`, 40, 10 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "طلبات متكررة");

  const parsed = await readJson(req, sendSchema);
  if (parsed.error) return parsed.error;
  const target = await db.user.findUnique({ where: { id: parsed.data.userId } });
  if (!target || !target.isActive) return fail(404, "NOT_FOUND", "الحساب غير موجود");
  if (target.id === ctx.user.id) return fail(400, "SELF", "لا يمكنك إضافة نفسك");

  const block = await db.block.findFirst({
    where: {
      OR: [
        { blockerId: ctx.user.id, blockedId: target.id },
        { blockerId: target.id, blockedId: ctx.user.id },
      ],
    },
  });
  if (block) return fail(403, "BLOCKED", "لا يمكن إرسال طلب بسبب الحظر");

  const existing = await db.friendship.findFirst({
    where: {
      OR: [
        { requesterId: ctx.user.id, addresseeId: target.id },
        { requesterId: target.id, addresseeId: ctx.user.id },
      ],
    },
  });
  if (existing) {
    if (existing.status === "ACCEPTED") return ok({ status: "ACCEPTED", alreadyFriends: true });
    if (existing.requesterId === ctx.user.id) return ok({ status: "PENDING", alreadyPending: true });
    // they already requested → accept it now
    await db.friendship.update({ where: { id: existing.id }, data: { status: "ACCEPTED" } });
    await notify({
      userId: existing.requesterId,
      actorId: ctx.user.id,
      type: "FRIEND_ACCEPT",
      entityType: "USER",
      entityId: ctx.user.id,
      text: "قبل طلب الصداقة",
    });
    return ok({ status: "ACCEPTED" });
  }

  await db.friendship.create({
    data: { requesterId: ctx.user.id, addresseeId: target.id, status: "PENDING" },
  });
  await notify({
    userId: target.id,
    actorId: ctx.user.id,
    type: "FRIEND_REQUEST",
    entityType: "USER",
    entityId: ctx.user.id,
    text: "أرسل إليك طلب صداقة",
  });
  return ok({ status: "PENDING" }, 201);
});
