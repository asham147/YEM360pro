import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { publicUser } from "@/lib/serialize";

export const GET = handler(async (req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const filter = req.nextUrl.searchParams.get("type");

  const where: { userId: string; isRead?: boolean; type?: { in: string[] } } = { userId: ctx.user.id };
  if (filter === "unread") where.isRead = false;
  if (filter === "likes") where.type = { in: ["LIKE"] };
  if (filter === "comments") where.type = { in: ["COMMENT", "COMMENT_REPLY", "MENTION"] };
  if (filter === "follows") where.type = { in: ["FOLLOW", "FRIEND_REQUEST", "FRIEND_ACCEPT"] };

  const notifications = await db.notification.findMany({
    where,
    include: { actor: { include: { profile: true } } },
    orderBy: { createdAt: "desc" },
    take: 60,
  });

  const unread = await db.notification.count({ where: { userId: ctx.user.id, isRead: false } });

  return ok({
    unread,
    notifications: notifications.map((n) => ({
      id: n.id,
      type: n.type,
      text: n.text,
      entityType: n.entityType,
      entityId: n.entityId,
      isRead: n.isRead,
      createdAt: n.createdAt.toISOString(),
      actor: n.actor ? publicUser(n.actor, n.actor.profile) : null,
    })),
  });
});
