import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { z } from "zod";

const schema = z.object({ id: z.string().max(40).optional(), all: z.boolean().optional() });

/** POST /api/notifications/read — mark one or all notifications as read. */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const parsed = await readJson(req, schema);
  if (parsed.error) return parsed.error;

  if (parsed.data.all) {
    await db.notification.updateMany({
      where: { userId: ctx.user.id, isRead: false },
      data: { isRead: true, readAt: new Date() },
    });
  } else if (parsed.data.id) {
    await db.notification.updateMany({
      where: { id: parsed.data.id, userId: ctx.user.id, isRead: false },
      data: { isRead: true, readAt: new Date() },
    });
  }
  return ok({});
});
