import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";

export const GET = handler(async (_req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const sessions = await db.loginSession.findMany({
    where: { userId: ctx.user.id, revokedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { lastSeenAt: "desc" },
  });
  return ok({
    sessions: sessions.map((s) => ({
      id: s.id,
      browser: s.browser,
      os: s.os,
      device: s.device,
      ip: s.ip,
      createdAt: s.createdAt,
      lastSeenAt: s.lastSeenAt,
      isCurrent: s.id === ctx.session.id,
    })),
  });
});
