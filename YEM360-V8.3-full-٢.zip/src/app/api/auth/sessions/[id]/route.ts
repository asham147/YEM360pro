import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, getIp, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { logSecurity } from "@/lib/security";

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const session = await db.loginSession.findUnique({ where: { id } });
    if (!session || session.userId !== ctx.user.id) {
      return fail(404, "NOT_FOUND", "الجلسة غير موجودة");
    }
    await db.loginSession.update({ where: { id }, data: { revokedAt: new Date() } });
    await logSecurity("SESSION_REVOKED", { userId: ctx.user.id, ip: getIp(req), details: `session=${id}` });
    return ok({ message: "تم إنهاء الجلسة" });
  }
);
