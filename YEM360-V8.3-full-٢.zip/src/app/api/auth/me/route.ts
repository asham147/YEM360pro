import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { publicUser } from "@/lib/serialize";

export const GET = handler(async (_req: NextRequest) => {
  const g = await authGuard();
  if (!g.ctx) return g.resp;
  const { ctx } = g;
  const [user, settings, privacy, unreadNotifications, unreadMessages] = await Promise.all([
    db.user.findUnique({ where: { id: ctx.user.id }, include: { profile: true } }),
    db.userSetting.findUnique({ where: { userId: ctx.user.id } }),
    db.privacySetting.findUnique({ where: { userId: ctx.user.id } }),
    db.notification.count({ where: { userId: ctx.user.id, isRead: false } }),
    db.$queryRaw<{ c: number }[]>`
      SELECT COUNT(*) as c FROM Messages m
      JOIN Conversation_Participants p ON m.conversationId = p.conversationId
      WHERE p.userId = ${ctx.user.id}
        AND m.senderId != ${ctx.user.id}
        AND m.deletedAt IS NULL
        AND m.createdAt > COALESCE(p.lastReadAt, 0)
    `,
  ]);

  return ok({
    user: publicUser(user!, user!.profile, { self: true }),
    settings,
    privacy,
    counts: {
      unreadNotifications,
      unreadMessages: Number(unreadMessages[0]?.c ?? 0),
    },
  });
});
