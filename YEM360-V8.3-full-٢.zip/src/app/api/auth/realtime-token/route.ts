import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { authGuard } from "@/lib/auth";
import { fail, handler } from "@/lib/api";

/**
 * GET /api/auth/realtime-token — returns the caller's own session token so the
 * socket.io client can authenticate. The value is identical to the httpOnly
 * cookie the caller already owns; it is never valid for anyone else.
 */
export const GET = handler(async () => {
  const g = await authGuard();
  if (!g.ctx) return fail(401, "UNAUTHENTICATED");
  const store = await cookies();
  const token = store.get("yem360_session")?.value;
  if (!token) return fail(401, "UNAUTHENTICATED");
  return NextResponse.json({ ok: true, token });
});
