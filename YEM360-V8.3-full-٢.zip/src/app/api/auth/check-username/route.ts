import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { handler, getIp } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";

const RESERVED = ["admin", "api", "yem360", "root", "support", "security", "official", "yem", "me", "login", "register"];

export const GET = handler(async (req: NextRequest) => {
  const rl = rateLimit(`check-username:${getIp(req)}`, 30, 60_000);
  if (!rl.allowed) return NextResponse.json({ ok: true, available: false });
  const username = req.nextUrl.searchParams.get("q")?.trim() || "";
  const valid = /^[a-zA-Z0-9_]{3,20}$/.test(username) && !RESERVED.includes(username.toLowerCase());
  if (!valid) return NextResponse.json({ ok: true, available: false, reason: "INVALID" });
  const taken = await db.user.findUnique({ where: { username } });
  return NextResponse.json({ ok: true, available: !taken });
});
