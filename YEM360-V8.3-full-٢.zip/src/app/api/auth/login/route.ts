import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, getIp, handler } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { verifyPassword, createLoginSession, setSessionCookie, createChallengeToken } from "@/lib/auth";
import { logSecurity } from "@/lib/security";
import { loginSchema } from "@/lib/validators";
import { publicUser } from "@/lib/serialize";

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const ip = getIp(req);

  const rlIp = rateLimit(`login:ip:${ip}`, 12, 10 * 60 * 1000);
  if (!rlIp.allowed) {
    await logSecurity("LOGIN_RATE_LIMITED", { severity: "WARN", ip });
    return fail(429, "RATE_LIMITED", `محاولات دخول كثيرة، انتظر ${Math.ceil(rlIp.retryAfterSec / 60)} دقيقة`);
  }

  const parsed = await readJson(req, loginSchema);
  if (parsed.error) return parsed.error;
  const identifier = parsed.data.identifier.trim();

  const rlId = rateLimit(`login:id:${identifier.toLowerCase()}`, 8, 10 * 60 * 1000);
  if (!rlId.allowed) {
    return fail(429, "RATE_LIMITED", "محاولات كثيرة لهذا الحساب، انتظر قليلاً");
  }

  const user = await db.user.findFirst({
    where: {
      OR: [
        { email: identifier.toLowerCase() },
        { username: identifier },
        { username: identifier.toLowerCase() },
      ],
    },
    include: { profile: true },
  });

  const valid = user ? await verifyPassword(parsed.data.password, user.passwordHash) : false;
  if (!user || !valid) {
    await logSecurity("LOGIN_FAILED", {
      severity: "WARN",
      ip,
      userAgent: req.headers.get("user-agent"),
      details: `identifier=${identifier.slice(0, 40)}`,
    });
    return fail(401, "INVALID_CREDENTIALS", "بيانات الدخول غير صحيحة");
  }

  if (!user.isActive) {
    await logSecurity("LOGIN_BLOCKED_BANNED", { userId: user.id, severity: "HIGH", ip });
    return fail(403, "SUSPENDED", `الحساب موقوف${user.banReason ? `: ${user.banReason}` : ""}`);
  }

  // 2FA step one: short-lived challenge instead of a session
  if (user.twoFactorEnabled && user.twoFactorSecret) {
    await logSecurity("LOGIN_2FA_CHALLENGE", { userId: user.id, ip });
    return ok({ twoFactorRequired: true, challengeToken: createChallengeToken(user.id) });
  }

  const token = await createLoginSession(user.id, req);
  await setSessionCookie(req, token);
  await logSecurity("LOGIN_SUCCESS", { userId: user.id, ip, userAgent: req.headers.get("user-agent") });
  return ok({ user: publicUser(user, user.profile, { self: true }) });
});
