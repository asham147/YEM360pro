import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, getIp, handler } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { registerSchema } from "@/lib/validators";
import { hashPassword, createLoginSession, setSessionCookie } from "@/lib/auth";
import { logSecurity } from "@/lib/security";
import { publicUser } from "@/lib/serialize";

const RESERVED = ["admin", "api", "yem360", "root", "support", "security", "official", "yem", "me", "login", "register"];

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const ip = getIp(req);
  const rl = rateLimit(`register:${ip}`, 20, 60 * 60 * 1000);
  if (!rl.allowed) {
    await logSecurity("REGISTER_RATE_LIMITED", { severity: "WARN", ip });
    return fail(429, "RATE_LIMITED", `محاولات كثيرة، حاول بعد ${Math.ceil(rl.retryAfterSec / 60)} دقيقة`);
  }

  const parsed = await readJson(req, registerSchema);
  if (parsed.error) return parsed.error;
  const { name, username, email, password } = parsed.data;

  if (RESERVED.includes(username.toLowerCase())) {
    return fail(422, "USERNAME_RESERVED", "اسم المستخدم محجوز، اختر اسماً آخر");
  }

  const [usernameTaken, emailTaken] = await Promise.all([
    db.user.findUnique({ where: { username } }),
    db.user.findUnique({ where: { email } }),
  ]);
  if (usernameTaken) return fail(409, "USERNAME_TAKEN", "اسم المستخدم مستخدم بالفعل");
  if (emailTaken) return fail(409, "EMAIL_TAKEN", "البريد الإلكتروني مسجل بالفعل");

  const passwordHash = await hashPassword(password);

  const user = await db.$transaction(async (tx) => {
    const u = await tx.user.create({
      data: { name, username, email, passwordHash, language: "AR" },
    });
    await tx.profile.create({ data: { userId: u.id } });
    await tx.userSetting.create({ data: { userId: u.id } });
    await tx.privacySetting.create({ data: { userId: u.id } });
    return u;
  });

  await logSecurity("REGISTER_SUCCESS", { userId: user.id, ip, userAgent: req.headers.get("user-agent") });

  const token = await createLoginSession(user.id, req);
  await setSessionCookie(req, token);
  const fresh = await db.user.findUnique({ where: { id: user.id }, include: { profile: true } });
  return ok({ user: publicUser(fresh ?? user, fresh?.profile, { self: true }) }, 201);
});
