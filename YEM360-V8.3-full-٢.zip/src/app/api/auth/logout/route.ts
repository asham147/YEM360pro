import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, getIp, handler } from "@/lib/api";
import { authGuard, clearSessionCookie } from "@/lib/auth";
import { logSecurity } from "@/lib/security";

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  await db.loginSession.update({
    where: { id: ctx.session.id },
    data: { revokedAt: new Date() },
  }).catch(() => null);
  await clearSessionCookie(req);
  await logSecurity("LOGOUT", { userId: ctx.user.id, ip: getIp(req) });
  return ok({});
});
