import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, getIp, handler } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { authGuard, verifyPassword, hashPassword } from "@/lib/auth";
import { logSecurity } from "@/lib/security";
import { changePasswordSchema } from "@/lib/validators";

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`pwd:${ctx.user.id}`, 5, 15 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "محاولات كثيرة، انتظر قليلاً");

  const parsed = await readJson(req, changePasswordSchema);
  if (parsed.error) return parsed.error;

  const valid = await verifyPassword(parsed.data.currentPassword, ctx.user.passwordHash);
  if (!valid) {
    await logSecurity("PASSWORD_CHANGE_FAILED", { userId: ctx.user.id, severity: "WARN", ip: getIp(req) });
    return fail(401, "WRONG_PASSWORD", "كلمة المرور الحالية غير صحيحة");
  }

  const passwordHash = await hashPassword(parsed.data.newPassword);

  await db.$transaction([
    db.user.update({ where: { id: ctx.user.id }, data: { passwordHash } }),
    // security policy: revoke every other session after a password change
    db.loginSession.updateMany({
      where: { userId: ctx.user.id, id: { not: ctx.session.id }, revokedAt: null },
      data: { revokedAt: new Date() },
    }),
  ]);

  await logSecurity("PASSWORD_CHANGE", {
    userId: ctx.user.id,
    severity: "HIGH",
    ip: getIp(req),
    details: "تم تغيير كلمة المرور وإلغاء الجلسات الأخرى",
  });
  return ok({ message: "تم تغيير كلمة المرور وإلغاء الجلسات الأخرى" });
});
