import { NextRequest } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, getIp, handler } from "@/lib/api";
import { rateLimit } from "@/lib/rate-limit";
import { verifyChallengeToken, createLoginSession, setSessionCookie } from "@/lib/auth";
import { logSecurity } from "@/lib/security";
import { decryptText, verifyTotp } from "@/lib/crypto";
import { twoFactorSchema } from "@/lib/validators";
import { publicUser } from "@/lib/serialize";

const verifySchema = twoFactorSchema.extend({ challengeToken: z.string().min(10).max(500) });

export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const ip = getIp(req);
  const rl = rateLimit(`2fa:${ip}`, 8, 10 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "محاولات كثيرة، انتظر قليلاً");

  const parsed = await readJson(req, verifySchema);
  if (parsed.error) return parsed.error;

  const userId = verifyChallengeToken(parsed.data.challengeToken);
  if (!userId) return fail(401, "CHALLENGE_EXPIRED", "انتهت صلاحية الجلسة المؤقتة، سجّل الدخول من جديد");

  const user = await db.user.findUnique({ where: { id: userId }, include: { profile: true } });
  if (!user || !user.twoFactorSecret || !user.isActive) {
    return fail(401, "CHALLENGE_EXPIRED", "الجلسة غير صالحة");
  }

  const secret = decryptText(user.twoFactorSecret);
  if (!secret || !verifyTotp(secret, parsed.data.code)) {
    await logSecurity("LOGIN_2FA_FAILED", { userId: user.id, severity: "WARN", ip });
    return fail(401, "INVALID_CODE", "رمز التحقق غير صحيح");
  }

  const token = await createLoginSession(user.id, req);
  await setSessionCookie(req, token);
  await logSecurity("LOGIN_SUCCESS_2FA", { userId: user.id, ip, userAgent: req.headers.get("user-agent") });
  return ok({ user: publicUser(user, user.profile, { self: true }) });
});
