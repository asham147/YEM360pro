import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { storyCreateSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { blockedPairIds } from "@/lib/privacy";
import { saveUpload } from "@/lib/media";
import { publicUser, type PublicUser } from "@/lib/serialize";

/** GET /api/stories — grouped active stories (self + followed + public), unseen first. */
export const GET = handler(async (_req: NextRequest) => {
  const g = await authGuard();
  if (!g.ctx) return g.resp;
  const me = g.ctx.user.id;

  const [following, blocked] = await Promise.all([
    db.follow.findMany({ where: { followerId: me, status: "ACCEPTED" }, select: { followingId: true } }),
    blockedPairIds(me),
  ]);
  const ids = [me, ...following.map((f) => f.followingId)].filter((id) => !blocked.includes(id));

  const users = await db.user.findMany({
    where: { id: { in: ids }, isActive: true },
    include: { profile: true, privacySetting: true },
  });

  const grouped: { user: PublicUser; hasUnseen: boolean; stories: unknown[] }[] = [];
  for (const u of users) {
    if (u.id !== me) {
      const privacy = u.privacySetting?.storyPrivacy ?? "FOLLOWERS";
      if (privacy === "NONE") continue;
      if (privacy === "FOLLOWERS" && u.id !== me) {
        const isFollowing = following.some((f) => f.followingId === u.id);
        if (!isFollowing) continue;
      }
      if (u.privacySetting?.privateAccount && u.id !== me) {
        if (!following.some((f) => f.followingId === u.id)) continue;
      }
    }
    const stories = await db.story.findMany({
      where: { userId: u.id, expiresAt: { gt: new Date() } },
      include: { views: { where: { userId: me } } },
      orderBy: { createdAt: "asc" },
    });
    if (!stories.length) continue;
    const hasUnseen = stories.some((s) => s.views.length === 0);
    grouped.push({
      user: publicUser(u, u.profile),
      hasUnseen,
      stories: stories.map((s) => ({
        id: s.id,
        type: s.type,
        mediaUrl: s.mediaUrl,
        text: s.text,
        bgColor: s.bgColor,
        createdAt: s.createdAt.toISOString(),
        expiresAt: s.expiresAt.toISOString(),
        viewCount: s.viewCount,
        viewedByMe: s.views.length > 0,
      })),
    });
  }

  grouped.sort((a, b) => {
    const selfFirst = (x: typeof a) => (x.user.id === me ? 0 : 1);
    if (selfFirst(a) !== selfFirst(b)) return selfFirst(a) - selfFirst(b);
    return Number(b.hasUnseen) - Number(a.hasUnseen);
  });

  return ok({ groups: grouped });
});

/** POST /api/stories — create a story (24h lifetime). */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`story:${ctx.user.id}`, 10, 30 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "أضفت قصصاً كثيرة، انتظر قليلاً");

  const contentType = req.headers.get("content-type") || "";
  const isMultipart = contentType.includes("multipart/form-data");
  const form = isMultipart ? await req.formData().catch(() => null) : null;
  if (form) {
    const file = form.get("file");
    const type = String(form.get("type") || "IMAGE");
    if (!(file instanceof File) && type !== "TEXT") return fail(400, "NO_FILE", "أضف صورة أو فيديو أو نصاً");
    const data: { type: string; mediaUrl?: string; text?: string; bgColor?: string } = {
      type,
      bgColor: String(form.get("bgColor") || "teal") || undefined,
      text: String(form.get("text") || "") || undefined,
    };
    if (file instanceof File) {
      const media = await saveUpload(file, "story");
      data.mediaUrl = media.url;
      data.type = media.type;
    }
    if (data.text) {
      const banned = await checkText(data.text);
      if (banned.length) return fail(422, "CONTENT_BLOCKED", "النص يحتوي على كلمات غير مسموحة");
      if (data.text.length > 280) return fail(422, "VALIDATION", "النص طويل جداً (280 حرفاً كحد أقصى)");
    }
    if (!data.mediaUrl && !data.text) return fail(422, "EMPTY", "القصة فارغة");

    const story = await db.story.create({
      data: {
        userId: ctx.user.id,
        type: data.type,
        mediaUrl: data.mediaUrl,
        text: data.text,
        bgColor: data.bgColor,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      },
    });
    return ok({ story: { id: story.id, type: story.type } }, 201);
  }

  // JSON body (text story)
  const parsed = await readJson(req, storyCreateSchema);
  if (parsed.error) return parsed.error;
  const { type, mediaUrl, text, bgColor } = parsed.data;
  if (type !== "TEXT" && !mediaUrl) return fail(422, "EMPTY", "القصة فارغة");
  if (text) {
    const banned = await checkText(text);
    if (banned.length) return fail(422, "CONTENT_BLOCKED", "النص يحتوي على كلمات غير مسموحة");
  }
  const story = await db.story.create({
    data: {
      userId: ctx.user.id,
      type,
      mediaUrl,
      text,
      bgColor,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
    },
  });
  return ok({ story: { id: story.id, type: story.type } }, 201);
});
