import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";

export const POST = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const story = await db.story.findUnique({ where: { id } });
    if (!story || story.expiresAt < new Date()) return fail(404, "NOT_FOUND", "القصة غير موجودة");

    await db.storyView.upsert({
      where: { storyId_userId: { storyId: id, userId: ctx.user.id } },
      update: { viewedAt: new Date() },
      create: { storyId: id, userId: ctx.user.id },
    });
    await db.story.update({ where: { id }, data: { viewCount: { increment: 1 } } }).catch(() => null);
    return ok({});
  }
);
