import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { publicUser } from "@/lib/serialize";

/** Owner-only: list who viewed a story. */
export const GET = handler(
  async (_req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const story = await db.story.findUnique({ where: { id } });
    if (!story) return fail(404, "NOT_FOUND", "القصة غير موجودة");
    if (story.userId !== ctx.user.id) return fail(403, "FORBIDDEN", "لصاحب القصة فقط");

    const views = await db.storyView.findMany({
      where: { storyId: id },
      include: { story: false },
      orderBy: { viewedAt: "desc" },
    });
    const users = await db.user.findMany({
      where: { id: { in: views.map((v) => v.userId) } },
      include: { profile: true },
    });
    const map = new Map(users.map((u) => [u.id, u]));
    return ok({
      viewers: views
        .filter((v) => map.has(v.userId))
        .map((v) => {
          const u = map.get(v.userId)!;
          return { ...publicUser(u, u.profile), viewedAt: v.viewedAt.toISOString() };
        }),
    });
  }
);
