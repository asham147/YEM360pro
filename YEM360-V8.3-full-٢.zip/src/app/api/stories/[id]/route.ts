import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { deleteMediaFile } from "@/lib/media";

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const story = await db.story.findUnique({ where: { id } });
    if (!story || story.expiresAt < new Date()) return fail(404, "NOT_FOUND", "القصة غير موجودة");
    if (story.userId !== ctx.user.id) return fail(403, "FORBIDDEN", "يمكنك حذف قصصك فقط");

    if (story.mediaUrl) await deleteMediaFile(story.mediaUrl);
    await db.story.delete({ where: { id } });
    return ok({ message: "تم حذف القصة" });
  }
);
