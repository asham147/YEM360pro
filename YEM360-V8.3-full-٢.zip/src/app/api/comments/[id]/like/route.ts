import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { notify } from "@/lib/notify";

export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const rl = rateLimit(`like-c:${ctx.user.id}`, 120, 60_000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "بطء شديد");
    const { id } = await params;

    const comment = await db.comment.findUnique({ where: { id } });
    if (!comment || comment.deletedAt) return fail(404, "NOT_FOUND", "التعليق غير موجود");

    const existing = await db.like.findFirst({ where: { userId: ctx.user.id, commentId: id } });
    if (existing) return ok({ liked: true, alreadyLiked: true });

    await db.like.create({ data: { userId: ctx.user.id, commentId: id } });
    await notify({
      userId: comment.authorId,
      actorId: ctx.user.id,
      type: "LIKE",
      entityType: "COMMENT",
      entityId: id,
      text: "أعجب بتعليقك",
    });
    const count = await db.like.count({ where: { commentId: id } });
    return ok({ liked: true, likeCount: count }, 201);
  }
);

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    await db.like.deleteMany({ where: { userId: ctx.user.id, commentId: id } });
    const count = await db.like.count({ where: { commentId: id } });
    return ok({ liked: false, likeCount: count });
  }
);
