import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";

export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const comment = await db.comment.findUnique({ where: { id } });
    if (!comment || comment.deletedAt) return fail(404, "NOT_FOUND", "التعليق غير موجود");

    let allowed = comment.authorId === ctx.user.id;
    const isStaff = ctx.user.role === "ADMIN" || ctx.user.role === "MODERATOR";
    if (!allowed && !isStaff && comment.postId) {
      const post = await db.post.findUnique({ where: { id: comment.postId } });
      allowed = post?.authorId === ctx.user.id;
    }
    if (!allowed && !isStaff && comment.reelId) {
      const reel = await db.reel.findUnique({ where: { id: comment.reelId } });
      allowed = reel?.userId === ctx.user.id;
    }
    if (!allowed) return fail(403, "FORBIDDEN", "لا يمكنك حذف هذا التعليق");

    await db.comment.updateMany({
      where: { OR: [{ id }, { parentId: id }] },
      data: { deletedAt: new Date() },
    });
    return ok({ message: "تم حذف التعليق" });
  }
);
