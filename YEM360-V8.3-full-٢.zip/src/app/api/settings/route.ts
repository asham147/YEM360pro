import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { z } from "zod";

const combinedSchema = z.object({
  theme: z.enum(["LIGHT", "DARK", "SYSTEM"]).optional(),
  emailNotify: z.boolean().optional(),
  pushNotify: z.boolean().optional(),
  notifyLikes: z.boolean().optional(),
  notifyComments: z.boolean().optional(),
  notifyFollows: z.boolean().optional(),
  notifyMessages: z.boolean().optional(),
  language: z.enum(["AR", "EN"]).optional(),
  privateAccount: z.boolean().optional(),
  showOnlineStatus: z.boolean().optional(),
  whoCanMessage: z.enum(["EVERYONE", "FOLLOWERS", "NONE"]).optional(),
  storyPrivacy: z.enum(["ALL", "FOLLOWERS", "NONE"]).optional(),
  whoCanTagMe: z.enum(["EVERYONE", "FOLLOWERS", "NONE"]).optional(),
});

/** PATCH /api/settings — update user settings + privacy settings in one call. */
export const PATCH = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;

  const parsed = await readJson(req, combinedSchema);
  if (parsed.error) return parsed.error;
  const d = parsed.data;

  const userSettingsData = {
    theme: d.theme,
    emailNotify: d.emailNotify,
    pushNotify: d.pushNotify,
    notifyLikes: d.notifyLikes,
    notifyComments: d.notifyComments,
    notifyFollows: d.notifyFollows,
    notifyMessages: d.notifyMessages,
  };
  const privacyData = {
    privateAccount: d.privateAccount,
    showOnlineStatus: d.showOnlineStatus,
    whoCanMessage: d.whoCanMessage,
    storyPrivacy: d.storyPrivacy,
    whoCanTagMe: d.whoCanTagMe,
  };
  const defined = <T extends object>(o: T) =>
    Object.fromEntries(Object.entries(o).filter(([, v]) => v !== undefined));

  const [settings, privacy] = await db.$transaction([
    db.userSetting.upsert({
      where: { userId: ctx.user.id },
      update: defined(userSettingsData),
      create: { userId: ctx.user.id },
    }),
    db.privacySetting.upsert({
      where: { userId: ctx.user.id },
      update: defined(privacyData),
      create: { userId: ctx.user.id },
    }),
  ]);

  if (d.language) {
    await db.user.update({ where: { id: ctx.user.id }, data: { language: d.language } });
  }

  return ok({ settings, privacy });
});
