import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { orderSchema } from "@/lib/validators";
import { notify } from "@/lib/notify";

/** GET /api/orders?type=bought|sold — order history for buyer or seller. */
export const GET = handler(async (req: NextRequest) => {
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const type = req.nextUrl.searchParams.get("type") === "sold" ? "sold" : "bought";

  const orders = await db.order.findMany({
    where: type === "bought" ? { buyerId: ctx.user.id } : { sellerId: ctx.user.id },
    include: {
      product: { include: { images: true } },
      buyer: { include: { profile: true } },
      seller: { include: { profile: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return ok({
    orders: orders.map((o) => ({
      id: o.id,
      quantity: o.quantity,
      totalPrice: o.totalPrice,
      status: o.status,
      address: o.address,
      phone: o.phone,
      note: o.note,
      createdAt: o.createdAt.toISOString(),
      product: {
        id: o.product.id, title: o.product.title, price: o.product.price,
        currency: o.product.currency, image: o.product.images[0]?.url ?? null,
      },
      counterpart: type === "bought"
        ? { username: o.seller.username, name: o.seller.name, avatarUrl: o.seller.profile?.avatarUrl }
        : { username: o.buyer.username, name: o.buyer.name, avatarUrl: o.buyer.profile?.avatarUrl },
      role: type === "bought" ? "BUYER" : "SELLER",
    })),
  });
});

/** POST /api/orders — place an order (cash-on-delivery marketplace). */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
  const rl = rateLimit(`order:${ctx.user.id}`, 10, 10 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "طلبات كثيرة، انتظر قليلاً");

  const parsed = await readJson(req, orderSchema);
  if (parsed.error) return parsed.error;
  const { productId, quantity, address, phone, note } = parsed.data;

  const product = await db.product.findUnique({ where: { id: productId } });
  if (!product || product.deletedAt || product.status !== "AVAILABLE") {
    return fail(404, "NOT_FOUND", "المنتج غير متاح للشراء");
  }
  if (product.sellerId === ctx.user.id) return fail(400, "SELF", "لا يمكنك شراء منتجك الخاص");
  if (product.stock < quantity) return fail(400, "STOCK", `المتوفر في المخزون: ${product.stock} فقط`);

  const created = await db.order.create({
    data: {
      productId,
      buyerId: ctx.user.id,
      sellerId: product.sellerId,
      quantity,
      totalPrice: product.price * quantity,
      address, phone, note,
    },
  });
  await db.product.update({
    where: { id: productId },
    data: {
      stock: { decrement: quantity },
      status: product.stock - quantity <= 0 ? "SOLD_OUT" : "AVAILABLE",
    },
  });

  await Promise.all([
    notify({
      userId: product.sellerId,
      actorId: ctx.user.id,
      type: "ORDER",
      entityType: "PRODUCT",
      entityId: productId,
      text: `طلب شراء منتجك: ${product.title} (كمية ${quantity})`,
    }),
    notify({
      userId: ctx.user.id,
      type: "ORDER",
      entityType: "PRODUCT",
      entityId: productId,
      text: `تم إنشاء طلبك: ${product.title}`,
    }),
  ]);

  return ok({ id: created.id, message: "تم إنشاء الطلب بنجاح" }, 201);
});
