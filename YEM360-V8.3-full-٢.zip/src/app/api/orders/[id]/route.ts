import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { notify } from "@/lib/notify";
import { z } from "zod";

const patchSchema = z.object({
  status: z.enum(["PENDING", "CONFIRMED", "SHIPPED", "DELIVERED", "CANCELLED"]),
});

const ALLOWED_SELLER: Record<string, string[]> = {
  PENDING: ["CONFIRMED", "CANCELLED"],
  CONFIRMED: ["SHIPPED", "CANCELLED"],
  SHIPPED: ["DELIVERED", "CANCELLED"],
  DELIVERED: [],
  CANCELLED: [],
};

/** PATCH /api/orders/[id] — update order status (seller transitions / buyer cancel while pending). */
export const PATCH = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ctx = await authGuard();
  if (!g_ctx.ctx) return g_ctx.resp;
  const { ctx } = g_ctx;
    const { id } = await params;

    const order = await db.order.findUnique({ where: { id }, include: { product: true } });
    if (!order) return fail(404, "NOT_FOUND", "الطلب غير موجود");

    const isSeller = order.sellerId === ctx.user.id;
    const isBuyer = order.buyerId === ctx.user.id;
    if (!isSeller && !isBuyer) return fail(403, "FORBIDDEN", "غير مصرح");

    const parsed = await readJson(req, patchSchema);
    if (parsed.error) return parsed.error;
    const { status } = parsed.data;

    if (isBuyer && !isSeller) {
      if (status !== "CANCELLED") return fail(403, "FORBIDDEN", "يمكن للمشتري الإلغاء فقط");
      if (order.status !== "PENDING") return fail(400, "STATE", "لا يمكن الإلغاء بعد تأكيد الطلب");
    } else if (isSeller) {
      if (!ALLOWED_SELLER[order.status]?.includes(status)) {
        return fail(400, "STATE", `لا يمكن الانتقال من ${order.status} إلى ${status}`);
      }
    }

    await db.order.update({ where: { id }, data: { status } });

    // restore stock on cancel
    if (status === "CANCELLED" && order.status !== "CANCELLED") {
      await db.product
        .update({
          where: { id: order.productId },
          data: { stock: { increment: order.quantity }, status: "AVAILABLE" },
        })
        .catch(() => null);
    }

    const counterpartId = isSeller ? order.buyerId : order.sellerId;
    const labels: Record<string, string> = {
      CONFIRMED: "تم تأكيد", SHIPPED: "تم شحن", DELIVERED: "تم تسليم", CANCELLED: "تم إلغاء",
    };
    if (labels[status]) {
      await notify({
        userId: counterpartId,
        actorId: ctx.user.id,
        type: "ORDER",
        entityType: "PRODUCT",
        entityId: order.productId,
        text: `${labels[status]} الطلب: ${order.product.title}`,
      });
    }

    return ok({ status, message: "تم تحديث حالة الطلب" });
  }
);
