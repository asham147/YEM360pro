import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { serializePost, type PostWithRelations } from "@/lib/serialize-posts";

/**
 * GET /api/insights — professional-account analytics.
 * Computed from real interactions: views, likes, comments, follower growth.
 */
export const GET = handler(async (_req: NextRequest) => {
  const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
  if (ctx.user.accountType === "PERSONAL") {
    return fail(403, "NOT_PROFESSIONAL", "هذه الميزة للحسابات الاحترافية — قم بالترقية من إعدادات الملف الشخصي");
  }

  const me = ctx.user.id;
  const since = new Date(Date.now() - 28 * 24 * 60 * 60 * 1000);

  const [postViews, likes28, comments28, reelsViews, followersTotal, followingTotal, postsCount, reelsCount] =
    await Promise.all([
      db.post.aggregate({ where: { authorId: me, deletedAt: null }, _sum: { viewCount: true } }),
      db.like.count({ where: { post: { authorId: me }, createdAt: { gte: since } } }),
      db.comment.count({ where: { post: { authorId: me }, createdAt: { gte: since }, deletedAt: null } }),
      db.reel.aggregate({ where: { userId: me, deletedAt: null }, _sum: { viewCount: true } }),
      db.follow.count({ where: { followingId: me, status: "ACCEPTED" } }),
      db.follow.count({ where: { followerId: me, status: "ACCEPTED" } }),
      db.post.count({ where: { authorId: me, deletedAt: null } }),
      db.reel.count({ where: { userId: me, deletedAt: null } }),
    ]);

  // daily series (last 14 days) — new followers & new likes per day
  const since14 = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
  const [newFollowers, newLikes] = await Promise.all([
    db.follow.findMany({ where: { followingId: me, createdAt: { gte: since14 } }, select: { createdAt: true } }),
    db.like.findMany({ where: { post: { authorId: me }, createdAt: { gte: since14 } }, select: { createdAt: true } }),
  ]);
  const days: { date: string; label: string; followers: number; likes: number }[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - i);
    const next = new Date(d.getTime() + 24 * 60 * 60 * 1000);
    days.push({
      date: d.toISOString().slice(0, 10),
      label: d.toLocaleDateString("ar", { day: "numeric", month: "short" }),
      followers: newFollowers.filter((f) => f.createdAt >= d && f.createdAt < next).length,
      likes: newLikes.filter((l) => l.createdAt >= d && l.createdAt < next).length,
    });
  }

  const topPosts = await db.post.findMany({
    where: { authorId: me, deletedAt: null },
    include: {
      author: { include: { profile: true } },
      media: true,
      hashtags: { include: { hashtag: true } },
      likes: { select: { userId: true } },
      saves: { select: { userId: true } },
      reposts: { select: { authorId: true } },
    },
    orderBy: { viewCount: "desc" },
    take: 5,
  });

  return ok({
    totals: {
      postViews: postViews._sum.viewCount ?? 0,
      reelViews: reelsViews._sum.viewCount ?? 0,
      likes28,
      comments28,
      followers: followersTotal,
      following: followingTotal,
      posts: postsCount,
      reels: reelsCount,
    },
    daily: days,
    topPosts: (topPosts as unknown as PostWithRelations[]).map((p) => serializePost(p, me)),
  });
});
