import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { groupCreateSchema } from "@/lib/validators";
import { canMessage, blockedPairIds } from "@/lib/privacy";
import { publicUser } from "@/lib/serialize";
import { z } from "zod";

/** GET /api/messages/conversations — inbox list with unread counts. */
export const GET = handler(async (_req: NextRequest) => {
  const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
  const me = ctx.user.id;

  const parts = await db.conversationParticipant.findMany({
    where: { userId: me },
    include: {
      conversation: {
        include: {
          participants: { include: { user: { include: { profile: true } } } },
          messages: { orderBy: { createdAt: "desc" }, take: 1, where: { deletedAt: null } },
          groupChat: true,
        },
      },
    },
  });

  const convs = parts
    .map((p) => ({ part: p, conv: p.conversation }))
    .sort((a, b) => (b.conv.lastMessageAt?.getTime() ?? b.conv.createdAt.getTime()) - (a.conv.lastMessageAt?.getTime() ?? a.conv.createdAt.getTime()))
    .slice(0, 40);

  const result: Record<string, unknown>[] = [];
  for (const { part, conv } of convs) {
    const others = conv.participants.filter((x) => x.userId !== me);
    const unread = await db.message.count({
      where: {
        conversationId: conv.id,
        senderId: { not: me },
        deletedAt: null,
        createdAt: { gt: part.lastReadAt ?? new Date(0) },
      },
    });
    result.push({
      id: conv.id,
      type: conv.type,
      title: conv.type === "GROUP" ? conv.title : others[0]?.user.name,
      avatarUrl: conv.type === "GROUP" ? conv.avatarUrl : others[0]?.user.profile?.avatarUrl,
      username: conv.type === "DIRECT" ? others[0]?.user.username : null,
      userId: conv.type === "DIRECT" ? others[0]?.user.id : null,
      isOnlineTarget: conv.type === "DIRECT" ? others[0]?.user.lastActiveAt : null,
      membersCount: conv.participants.length,
      lastMessage: conv.messages[0]
        ? {
            id: conv.messages[0].id,
            text: conv.messages[0].text,
            mediaUrl: conv.messages[0].mediaUrl,
            mediaType: conv.messages[0].mediaType,
            senderId: conv.messages[0].senderId,
            createdAt: conv.messages[0].createdAt.toISOString(),
          }
        : null,
      lastMessageAt: (conv.lastMessageAt ?? conv.createdAt).toISOString(),
      unread,
      isMuted: part.isMuted,
      role: part.role,
    });
  }
  return ok({ conversations: result });
});

const createSchema = z.union([
  z.object({ type: z.literal("DIRECT"), userId: z.string().min(1).max(40) }),
  groupCreateSchema.extend({ type: z.literal("GROUP") }),
]);

/** POST /api/messages/conversations — start a DM or create a group chat. */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
  const rl = rateLimit(`conv:${ctx.user.id}`, 20, 10 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "محاولات متكررة");

  const parsed = await readJson(req, createSchema);
  if (parsed.error) return parsed.error;
  const data = parsed.data;

  if (data.type === "DIRECT") {
    const target = await db.user.findUnique({ where: { id: data.userId }, include: { profile: true } });
    if (!target || !target.isActive) return fail(404, "NOT_FOUND", "الحساب غير موجود");
    if (target.id === ctx.user.id) return fail(400, "SELF", "لا يمكنك محادثة نفسك");
    const check = await canMessage(ctx.user.id, target.id);
    if (!check.allowed) return fail(403, "POLICY", check.reason);

    const mine = await db.conversationParticipant.findMany({
      where: { userId: ctx.user.id, conversation: { type: "DIRECT" } },
      select: { conversationId: true },
    });
    const theirs = await db.conversationParticipant.findMany({
      where: { userId: target.id, conversation: { type: "DIRECT" } },
      select: { conversationId: true },
    });
    const shared = mine.find((m) => theirs.some((t) => t.conversationId === m.conversationId));
    if (shared) return ok({ conversationId: shared.conversationId, existing: true });

    const conv = await db.$transaction(async (tx) => {
      const c = await tx.conversation.create({
        data: { type: "DIRECT", createdBy: ctx.user.id, lastMessageAt: null },
      });
      await tx.conversationParticipant.createMany({
        data: [
          { conversationId: c.id, userId: ctx.user.id, role: "OWNER" },
          { conversationId: c.id, userId: target.id },
        ],
      });
      return c;
    });
    return ok({ conversationId: conv.id }, 201);
  }

  // GROUP
  const blocked = new Set(await blockedPairIds(ctx.user.id));
  const members = await db.user.findMany({
    where: { id: { in: data.memberIds }, isActive: true },
  });
  const validMembers = members.filter((m) => m.id !== ctx.user.id && !blocked.has(m.id));

  const conv = await db.$transaction(async (tx) => {
    const c = await tx.conversation.create({
      data: { type: "GROUP", title: data.title, createdBy: ctx.user.id },
    });
    await tx.conversationParticipant.createMany({
      data: [
        { conversationId: c.id, userId: ctx.user.id, role: "OWNER" },
        ...validMembers.map((m) => ({ conversationId: c.id, userId: m.id })),
      ],
    });
    await tx.groupChat.create({
      data: { conversationId: c.id, description: data.description ?? null },
    });
    return c;
  });
  return ok({ conversationId: conv.id }, 201);
});
