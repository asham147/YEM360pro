import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { messageSendSchema } from "@/lib/validators";
import { checkText } from "@/lib/moderation";
import { notify } from "@/lib/notify";
import { internalEmit } from "@/lib/notify";

async function requireParticipant(conversationId: string, userId: string) {
  const part = await db.conversationParticipant.findUnique({
    where: { conversationId_userId: { conversationId, userId } },
    include: { conversation: true },
  });
  return part;
}

/** GET /api/messages/conversations/[id]?cursor= — message history. */
export const GET = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    const g_msg = await authGuard();
    if (!g_msg.ctx) return g_msg.resp;
    const { ctx } = g_msg;
    const { id } = await params;
    const part = await requireParticipant(id, ctx.user.id);
    if (!part) return fail(403, "FORBIDDEN", "لست عضواً في هذه المحادثة");

    const cursor = req.nextUrl.searchParams.get("cursor");
    const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") || 30), 60);
    const where: Prisma.MessageWhereInput = { conversationId: id, deletedAt: null };
    if (cursor) where.createdAt = { lt: new Date(cursor) };

    const messages = await db.message.findMany({
      where,
      include: { replyTo: { select: { id: true, text: true, senderId: true } } },
      orderBy: { createdAt: "desc" },
      take: limit + 1,
    });
    const hasMore = messages.length > limit;
    const page = messages.slice(0, limit).reverse();

    const participants = await db.conversationParticipant.findMany({
      where: { conversationId: id },
      include: { user: { include: { profile: true } } },
    });

    return ok({
      messages: page.map((m) => ({
        id: m.id,
        conversationId: m.conversationId,
        senderId: m.senderId,
        text: m.text,
        mediaUrl: m.mediaUrl,
        mediaType: m.mediaType,
        replyTo: m.replyTo,
        createdAt: m.createdAt.toISOString(),
        deleted: false,
      })),
      hasMore,
      nextCursor: hasMore && page.length ? page[0].createdAt.toISOString() : null,
      participants: participants.map((p) => ({
        userId: p.userId,
        role: p.role,
        name: p.user.name,
        username: p.user.username,
        avatarUrl: p.user.profile?.avatarUrl,
        lastReadAt: p.lastReadAt?.toISOString() ?? null,
      })),
    });
  }
);

/** POST /api/messages/conversations/[id] — send a message (realtime-pushed). */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_msg = await authGuard();
    if (!g_msg.ctx) return g_msg.resp;
    const { ctx } = g_msg;
    const rl = rateLimit(`msg:${ctx.user.id}`, 60, 60_000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "أرسلت رسائل كثيرة بسرعة");
    const { id } = await params;

    const part = await requireParticipant(id, ctx.user.id);
    if (!part) return fail(403, "FORBIDDEN", "لست عضواً في هذه المحادثة");

    const parsed = await readJson(req, messageSendSchema);
    if (parsed.error) return parsed.error;
    const { text, mediaUrl, mediaType, replyToId } = parsed.data;
    if (!text?.trim() && !mediaUrl) return fail(422, "EMPTY", "الرسالة فارغة");

    if (text?.trim()) {
      const banned = await checkText(text);
      if (banned.length) return fail(422, "CONTENT_BLOCKED", `الرسالة تحتوي على كلمات غير مسموحة: ${banned.join("، ")}`);
    }

    let validReply: string | null = null;
    if (replyToId) {
      const r = await db.message.findFirst({ where: { id: replyToId, conversationId: id } });
      if (!r) return fail(404, "NOT_FOUND", "الرسالة المرجعية غير موجودة");
      validReply = r.id;
    }

    const message = await db.message.create({
      data: {
        conversationId: id,
        senderId: ctx.user.id,
        text: text?.trim() || null,
        mediaUrl,
        mediaType,
        replyToId: validReply,
      },
      include: { replyTo: { select: { id: true, text: true, senderId: true } } },
    });

    await Promise.all([
      db.conversation.update({ where: { id }, data: { lastMessageAt: new Date() } }),
      db.conversationParticipant.update({
        where: { conversationId_userId: { conversationId: id, userId: ctx.user.id } },
        data: { lastReadAt: new Date() },
      }),
    ]);

    const payload = {
      id: message.id,
      conversationId: id,
      senderId: ctx.user.id,
      text: message.text,
      mediaUrl: message.mediaUrl,
      mediaType: message.mediaType,
      replyTo: message.replyTo,
      createdAt: message.createdAt.toISOString(),
    };

    // realtime push to all other participants
    const others = await db.conversationParticipant.findMany({
      where: { conversationId: id, userId: { not: ctx.user.id } },
      select: { userId: true },
    });
    await internalEmit("message:new", payload, { userIds: others.map((o) => o.userId) });

    // notifications (respect prefs + blocks)
    for (const o of others) {
      await notify({
        userId: o.userId,
        actorId: ctx.user.id,
        type: "MESSAGE",
        entityType: "CONVERSATION",
        entityId: id,
        text: message.text ? message.text.slice(0, 80) : "أرسل مرفقاً",
      }).catch(() => null);
    }

    return ok({ message: payload }, 201);
  }
);

/** DELETE conversation (leave). */
export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_msg = await authGuard();
    if (!g_msg.ctx) return g_msg.resp;
    const { ctx } = g_msg;
    const { id } = await params;
    const part = await requireParticipant(id, ctx.user.id);
    if (!part) return fail(403, "FORBIDDEN", "لست عضواً في هذه المحادثة");

    await db.conversationParticipant.delete({
      where: { conversationId_userId: { conversationId: id, userId: ctx.user.id } },
    });
    const remaining = await db.conversationParticipant.count({ where: { conversationId: id } });
    if (remaining === 0) await db.conversation.delete({ where: { id } });
    return ok({ message: "تمت مغادرة المحادثة" });
  }
);
