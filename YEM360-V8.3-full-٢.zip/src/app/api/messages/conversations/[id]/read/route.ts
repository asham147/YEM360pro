import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";

/** POST /api/messages/conversations/[id]/read — mark as read. */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;

    const part = await db.conversationParticipant.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: ctx.user.id } },
    });
    if (!part) return fail(403, "FORBIDDEN", "لست عضواً في هذه المحادثة");

    await db.conversationParticipant.update({
      where: { conversationId_userId: { conversationId: id, userId: ctx.user.id } },
      data: { lastReadAt: new Date() },
    });
    return ok({});
  }
);
