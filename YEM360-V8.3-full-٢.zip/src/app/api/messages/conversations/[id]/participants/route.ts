import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { internalEmit } from "@/lib/notify";
import { z } from "zod";

const addSchema = z.object({ userIds: z.array(z.string().max(40)).min(1).max(30) });

/** POST /api/messages/conversations/[id]/participants — add members (group owner/admin). */
export const POST = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const rl = rateLimit(`part:${ctx.user.id}`, 30, 10 * 60 * 1000);
    if (!rl.allowed) return fail(429, "RATE_LIMITED", "محاولات متكررة");
    const { id } = await params;

    const conv = await db.conversation.findUnique({ where: { id } });
    if (!conv || conv.type !== "GROUP") return fail(400, "BAD_REQUEST", "المجموعات فقط");
    const me = await db.conversationParticipant.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: ctx.user.id } },
    });
    if (!me || me.role === "MEMBER") return fail(403, "FORBIDDEN", "مالك/مسؤول المجموعة فقط يضيف الأعضاء");

    const parsed = await readJson(req, addSchema);
    if (parsed.error) return parsed.error;

    const users = await db.user.findMany({ where: { id: { in: parsed.data.userIds }, isActive: true } });
    const currentIds = (
      await db.conversationParticipant.findMany({ where: { conversationId: id }, select: { userId: true } })
    ).map((p) => p.userId);
    const toAdd = users.filter((u) => !currentIds.includes(u.id)).map((u) => ({
      conversationId: id,
      userId: u.id,
    }));
    if (!toAdd.length) return ok({ added: 0 });
    await db.conversationParticipant.createMany({ data: toAdd });
    await internalEmit("conversation:updated", { conversationId: id }, { userIds: toAdd.map((t) => t.userId) });
    return ok({ added: toAdd.length }, 201);
  }
);

/** DELETE /api/messages/conversations/[id]/participants?userId= — kick (owner) or mute toggle via PATCH below. */
export const DELETE = handler(
  async (req: NextRequest, { params }: { params: Promise<{ id: string }> }) => {
    if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
    const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
    const { id } = await params;
    const userId = req.nextUrl.searchParams.get("userId") || "";

    const conv = await db.conversation.findUnique({ where: { id } });
    if (!conv || conv.type !== "GROUP") return fail(400, "BAD_REQUEST", "المجموعات فقط");
    const me = await db.conversationParticipant.findUnique({
      where: { conversationId_userId: { conversationId: id, userId: ctx.user.id } },
    });
    if (!me) return fail(403, "FORBIDDEN", "لست عضواً");
    const targetId = userId || ctx.user.id;
    if (targetId !== ctx.user.id && me.role !== "OWNER") {
      return fail(403, "FORBIDDEN", "مالك المجموعة فقط يطرد الأعضاء");
    }
    if (targetId === ctx.user.id && me.role === "OWNER") {
      return fail(400, "OWNER_LEAVE", "انقل الملكية أو استخدم مغادرة المحادثة");
    }
    await db.conversationParticipant.deleteMany({ where: { conversationId: id, userId: targetId } });
    return ok({ message: "تم تنفيذ الإجراء" });
  }
);
