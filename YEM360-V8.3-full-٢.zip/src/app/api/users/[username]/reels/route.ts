import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { canViewPrivateContent } from "@/lib/privacy";
import { serializeReel } from "@/lib/serialize-posts";

/** GET /api/users/[username]/reels — profile reels tab. */
export const GET = handler(
  async (req: NextRequest, { params }: { params: Promise<{ username: string }> }) => {
    const g = await authGuard();
    if (!g.ctx) return g.resp;
    const viewerId = g.ctx.user.id;
    const { username } = await params;

    const user = await db.user.findUnique({
      where: { username },
      include: { profile: true, privacySetting: true },
    });
    if (!user || !user.isActive) return fail(404, "NOT_FOUND", "الحساب غير موجود");
    if (!(await canViewPrivateContent(viewerId, user))) return ok({ reels: [], private: true });

    const reels = await db.reel.findMany({
      where: { userId: user.id, deletedAt: null },
      include: {
        user: { include: { profile: true } },
        likes: { select: { userId: true } },
        _count: { select: { likes: true, comments: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 60,
    });
    return ok({ reels: reels.map((r) => serializeReel(r, viewerId)) });
  }
);
