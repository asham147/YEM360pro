import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, fail, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { canViewPrivateContent } from "@/lib/privacy";
import { serializePost, type PostWithRelations } from "@/lib/serialize-posts";

const include = {
  author: { include: { profile: true } },
  media: true,
  hashtags: { include: { hashtag: true } },
  likes: { select: { userId: true } },
  saves: { select: { userId: true } },
  reposts: { select: { authorId: true } },
  repostOf: false,
} as Prisma.PostInclude;

/** GET /api/users/[username]/posts — profile grid (respects privacy). */
export const GET = handler(
  async (req: NextRequest, { params }: { params: Promise<{ username: string }> }) => {
    const g = await authGuard();
    if (!g.ctx) return g.resp;
    const viewerId = g.ctx.user.id;
    const { username } = await params;

    const user = await db.user.findUnique({
      where: { username },
      include: { profile: true, privacySetting: true },
    });
    if (!user || !user.isActive) return fail(404, "NOT_FOUND", "الحساب غير موجود");
    if (!(await canViewPrivateContent(viewerId, user))) {
      return ok({ posts: [], private: true });
    }

    const posts = await db.post.findMany({
      where: { authorId: user.id, deletedAt: null, repostOfId: null },
      include: {
        author: { include: { profile: true } },
        media: true,
        hashtags: { include: { hashtag: true } },
        likes: { select: { userId: true } },
        saves: { select: { userId: true } },
        reposts: { select: { authorId: true } },
      },
      orderBy: [{ isPinned: "desc" }, { createdAt: "desc" }],
      take: 60,
    });
    return ok({ posts: posts.map((p) => serializePost(p as PostWithRelations, viewerId)) });
  }
);
