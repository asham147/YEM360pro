import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, sameOrigin, readJson, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { reportSchema } from "@/lib/validators";
import { internalEmit } from "@/lib/notify";

/** POST /api/reports — report content or a user (goes to the moderation queue). */
export const POST = handler(async (req: NextRequest) => {
  if (!sameOrigin(req)) return fail(403, "CSRF", "طلب غير موثوق");
  const g_ = await authGuard();
  if (!g_.ctx) return g_.resp;
  const { ctx } = g_;
  const rl = rateLimit(`report:${ctx.user.id}`, 10, 60 * 60 * 1000);
  if (!rl.allowed) return fail(429, "RATE_LIMITED", "أرسلت تقارير كثيرة، شكراً لتفهّمك");

  const parsed = await readJson(req, reportSchema);
  if (parsed.error) return parsed.error;
  const { targetType, targetId, reason, details } = parsed.data;

  // verify the target actually exists
  let exists = false;
  switch (targetType) {
    case "USER": exists = !!(await db.user.findUnique({ where: { id: targetId } })); break;
    case "POST": exists = !!(await db.post.findUnique({ where: { id: targetId } })); break;
    case "COMMENT": exists = !!(await db.comment.findUnique({ where: { id: targetId } })); break;
    case "REEL": exists = !!(await db.reel.findUnique({ where: { id: targetId } })); break;
    case "STORY": exists = !!(await db.story.findUnique({ where: { id: targetId } })); break;
    case "MESSAGE": exists = !!(await db.message.findUnique({ where: { id: targetId } })); break;
    case "PRODUCT": exists = !!(await db.product.findUnique({ where: { id: targetId } })); break;
  }
  if (!exists) return fail(404, "NOT_FOUND", "الهدف غير موجود");

  const report = await db.report.create({
    data: { reporterId: ctx.user.id, targetType, targetId, reason, details },
  });

  // ping online moderators (best-effort realtime)
  const mods = await db.user.findMany({
    where: { role: { in: ["ADMIN", "MODERATOR"] }, isActive: true },
    select: { id: true },
  });
  await internalEmit(
    "report:new",
    { id: report.id, targetType, reason },
    { userIds: mods.map((m) => m.id) }
  );

  return ok({ id: report.id, message: "تم إرسال البلاغ لفريق الإشراف" }, 201);
});
