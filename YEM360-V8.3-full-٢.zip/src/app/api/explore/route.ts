import { NextRequest } from "next/server";
import { Prisma } from "@prisma/client";
import { db } from "@/lib/db";
import { ok, handler } from "@/lib/api";
import { authGuard } from "@/lib/auth";
import { visiblePostsWhere, blockedPairIds } from "@/lib/privacy";
import { publicUser } from "@/lib/serialize";
import { serializePosts, type PostWithRelations } from "@/lib/serialize-posts";

/**
 * GET /api/explore — discovery engine (توصيات):
 *  - trending posts (engagement-weighted, last 7 days)
 *  - trending hashtags
 *  - suggested users (not followed, not blocked)
 */
export const GET = handler(async (req: NextRequest) => {
  const g = await authGuard();
  if (!g.ctx) return g.resp;
  const viewerId = g.ctx.user.id;
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit") || 12), 24);

  const include = {
    author: { include: { profile: true } },
    media: true,
    hashtags: { include: { hashtag: true } },
    likes: { select: { userId: true } },
    saves: { select: { userId: true } },
    reposts: { select: { authorId: true } },
    _count: { select: { likes: true, comments: true, reposts: true } },
    repostOf: {
      include: { author: { include: { profile: true } }, media: true, hashtags: { include: { hashtag: true } }, likes: { select: { userId: true } }, saves: { select: { userId: true } }, reposts: { select: { authorId: true } }, _count: { select: { likes: true, comments: true, reposts: true } } },
    },
  } satisfies Prisma.PostInclude;

  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
  const baseWhere = visiblePostsWhere(viewerId) as Prisma.PostWhereInput;

  const [candidates, hashtags, blocked, following] = await Promise.all([
    db.post.findMany({
      where: { ...baseWhere, createdAt: { gte: weekAgo }, repostOfId: null },
      include,
      orderBy: [{ viewCount: "desc" }, { createdAt: "desc" }],
      take: 60,
    }),
    db.hashtag.findMany({ orderBy: { useCount: "desc" }, take: 10, where: { useCount: { gt: 0 } } }),
    blockedPairIds(viewerId),
    db.follow.findMany({ where: { followerId: viewerId, status: "ACCEPTED" }, select: { followingId: true } }),
  ]);

  // engagement score = likes + 2×comments + 3×reposts + views/10
  const scored = candidates
    .map((p) => ({
      p,
      score: p._count.likes + p._count.comments * 2 + p._count.reposts * 3 + p.viewCount / 10,
    }))
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);

  const followSet = new Set(following.map((f) => f.followingId));
  const suggested = await db.user.findMany({
    where: {
      isActive: true,
      id: { not: viewerId, notIn: [...followSet, ...blocked] },
    },
    include: { profile: true, _count: { select: { followers: true } } },
    orderBy: { followers: { _count: "desc" } },
    take: 6,
  });

  return ok({
    trendingPosts: serializePosts(scored.map((s) => s.p as PostWithRelations), viewerId),
    trendingHashtags: hashtags.map((h) => ({ name: h.name, useCount: h.useCount })),
    suggestedUsers: suggested.map((u) => ({
      ...publicUser(u, u.profile),
      followerCount: u._count.followers,
    })),
  });
});
