/**
 * YEM360 — server bootstrap (Node runtime only).
 * Ensures the realtime socket.io mini-service is running and that upload
 * directories exist. Runs once per Next server boot.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  const g = globalThis as Record<string, unknown>;
  if (g.__yem360_booted) return;
  g.__yem360_booted = true;

  try {
    const fs = await import(/* webpackIgnore: true */ /* turbopackIgnore: true */ "fs");
    for (const dir of ["uploads", "uploads/avatars", "uploads/posts", "uploads/stories", "uploads/reels", "uploads/messages", "uploads/products", "uploads/ads"]) {
      try {
        fs.mkdirSync(dir, { recursive: true });
      } catch {
        /* exists */
      }
    }
  } catch {
    /* non-node runtime */
  }

  try {
    const res = await fetch("http://127.0.0.1:3004/health", { signal: AbortSignal.timeout(800) });
    if (res.ok) {
      console.log("[yem360] realtime service already running");
      return;
    }
  } catch {
    /* not running yet */
  }

  try {
    const { spawn } = await import(/* webpackIgnore: true */ /* turbopackIgnore: true */ "child_process");
    const child = spawn("bun", ["mini-services/yem-realtime/index.ts"], {
      cwd: process.cwd(),
      env: process.env,
      stdio: "ignore",
      detached: true,
    });
    child.unref();
    console.log("[yem360] spawned realtime service (pid", child.pid + ")");
    await new Promise((r) => setTimeout(r, 1200));
  } catch (e) {
    console.error("[yem360] failed to spawn realtime service:", e);
  }
}
