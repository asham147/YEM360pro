/**
 * YEM360 Realtime Service (socket.io mini-service)
 * ──────────────────────────────────────────────────
 * - socket.io server on port 3003, path "/" (as required by the Caddy gateway)
 * - internal HTTP control plane on port 3004 (health + server-to-server emit,
 *   protected by INTERNAL_SECRET)
 *
 * Push-only transport: the REST API (port 3000) stays the single source of
 * truth and pushes events here over the authenticated internal endpoint.
 *
 * Events (client ← server):
 *   message:new / notification:new / channel:new / conversation:typing /
 *   presence:results / presence:update / report:new / note:updated / conversation:updated
 * Events (client → server):
 *   auth {token} | conversation:typing {conversationId} | presence:query {userIds}
 */
import { createServer } from "http";
import { Server, type Socket } from "socket.io";
import crypto from "crypto";
import { PrismaClient } from "@prisma/client";

const PORT = 3003;
const CONTROL_PORT = 3004;
const JWT_SECRET = process.env.JWT_SECRET || "yem360-dev-only-change-JWT_SECRET-in-env";
const INTERNAL_SECRET = process.env.INTERNAL_SECRET || "";

const db = new PrismaClient();
const online = new Map<string, Set<string>>(); // userId → socket ids
const privacyCache = new Map<string, { show: boolean; at: number }>();
const membershipCache = new Map<string, { ok: boolean; at: number }>();

/* ───────── JWT verification (HS256, same as src/lib/crypto.ts) ───────── */

function verifyToken(token?: string): { sub: string; jti: string; typ: string; exp: number } | null {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [header, payload, sig] = parts;
  const expected = crypto
    .createHmac("sha256", JWT_SECRET)
    .update(`${header}.${payload}`)
    .digest()
    .toString("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (!parsed.exp || parsed.exp * 1000 < Date.now()) return null;
    return parsed;
  } catch {
    return null;
  }
}

const authed = new Map<string, { userId: string; name: string; username: string }>();

async function isConversationMember(conversationId: string, userId: string): Promise<boolean> {
  const key = `${conversationId}:${userId}`;
  const hit = membershipCache.get(key);
  if (hit && Date.now() - hit.at < 30_000) return hit.ok;
  const part = await db.conversationParticipant.findUnique({
    where: { conversationId_userId: { conversationId, userId } },
  });
  membershipCache.set(key, { ok: !!part, at: Date.now() });
  return !!part;
}

async function showOnlineStatus(userId: string): Promise<boolean> {
  const hit = privacyCache.get(userId);
  if (hit && Date.now() - hit.at < 60_000) return hit.show;
  const ps = await db.privacySetting.findUnique({ where: { userId }, select: { showOnlineStatus: true } });
  const show = ps?.showOnlineStatus ?? true;
  privacyCache.set(userId, { show, at: Date.now() });
  return show;
}

const socketHttpServer = createServer();
const io = new Server(socketHttpServer, {
  path: "/",
  cors: { origin: "*", methods: ["GET", "POST"] },
  pingTimeout: 60000,
  pingInterval: 25000,
});

io.on("connection", (socket: Socket) => {
  socket.on("auth", async (data: { token: string }) => {
    const payload = verifyToken(data?.token);
    if (!payload || payload.typ !== "session") {
      socket.emit("auth:error", { message: "غير مصرح" });
      return;
    }
    const user = await db.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, name: true, username: true, isActive: true },
    });
    if (!user || !user.isActive) {
      socket.emit("auth:error", { message: "الحساب غير متاح" });
      return;
    }

    const [conversations, channels] = await Promise.all([
      db.conversationParticipant.findMany({ where: { userId: user.id }, select: { conversationId: true } }),
      db.channelSubscriber.findMany({ where: { userId: user.id }, select: { channelId: true } }),
    ]);

    authed.set(socket.id, { userId: user.id, name: user.name, username: user.username });
    const sockets = online.get(user.id) ?? new Set<string>();
    const wasOffline = sockets.size === 0;
    sockets.add(socket.id);
    online.set(user.id, sockets);

    socket.join(`user:${user.id}`);
    for (const c of conversations) socket.join(`conversation:${c.conversationId}`);
    for (const c of channels) socket.join(`channel:${c.channelId}`);
    socket.emit("auth:ok", { userId: user.id });

    if (wasOffline) {
      socket.broadcast.emit("presence:update", { userId: user.id, online: true });
      await db.user.update({ where: { id: user.id }, data: { lastActiveAt: new Date() } }).catch(() => null);
    }
  });

  socket.on("conversation:typing", async (data: { conversationId: string }) => {
    const auth = authed.get(socket.id);
    if (!auth || !data?.conversationId) return;
    if (!(await isConversationMember(data.conversationId, auth.userId))) return;
    socket.to(`conversation:${data.conversationId}`).emit("conversation:typing", {
      conversationId: data.conversationId,
      userId: auth.userId,
      name: auth.name,
    });
  });

  socket.on("presence:query", async (data: { userIds: string[] }) => {
    const auth = authed.get(socket.id);
    if (!auth) return;
    const ids = (data?.userIds || []).slice(0, 50);
    const results: Record<string, boolean> = {};
    for (const id of ids) {
      const isOnline = online.has(id) && (online.get(id)?.size ?? 0) > 0;
      if (!isOnline) continue;
      if (await showOnlineStatus(id)) results[id] = true;
    }
    socket.emit("presence:results", results);
  });

  socket.on("disconnect", () => {
    const auth = authed.get(socket.id);
    authed.delete(socket.id);
    if (!auth) return;
    const sockets = online.get(auth.userId);
    if (sockets) {
      sockets.delete(socket.id);
      if (sockets.size === 0) {
        online.delete(auth.userId);
        socket.broadcast.emit("presence:update", { userId: auth.userId, online: false });
        db.user.update({ where: { id: auth.userId }, data: { lastActiveAt: new Date() } }).catch(() => null);
      }
    }
  });
});

/* ───────── internal control plane (port 3004) ───────── */

const control = createServer((req, res) => {
  const url = req.url || "";
  if (req.method === "GET" && url.startsWith("/health")) {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: true, service: "yem-realtime", online: online.size }));
    return;
  }
  if (req.method === "POST" && url.startsWith("/internal/emit")) {
    if (!INTERNAL_SECRET || req.headers["x-internal-secret"] !== INTERNAL_SECRET) {
      res.writeHead(403, { "content-type": "application/json" });
      res.end(JSON.stringify({ ok: false, error: "FORBIDDEN" }));
      return;
    }
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) req.destroy();
    });
    req.on("end", () => {
      try {
        const { event, payload, userIds, rooms } = JSON.parse(body);
        if (!event) throw new Error("missing event");
        for (const uid of userIds ?? []) io.to(`user:${uid}`).emit(event, payload);
        for (const room of rooms ?? []) io.to(room).emit(event, payload);
        res.writeHead(200, { "content-type": "application/json" });
        res.end(JSON.stringify({ ok: true }));
      } catch {
        res.writeHead(400, { "content-type": "application/json" });
        res.end(JSON.stringify({ ok: false, error: "BAD_JSON" }));
      }
    });
    return;
  }
  res.writeHead(404);
  res.end();
});

socketHttpServer.listen(PORT, () => {
  console.log(`[yem-realtime] socket.io on :${PORT} (path /)`);
});
control.listen(CONTROL_PORT, () => {
  console.log(`[yem-realtime] control plane on :${CONTROL_PORT}`);
});

process.on("SIGTERM", () => process.exit(0));
process.on("SIGINT", () => process.exit(0));
